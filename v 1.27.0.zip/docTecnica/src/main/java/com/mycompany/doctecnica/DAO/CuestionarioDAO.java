package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Pregunta;

import java.util.List;

public interface CuestionarioDAO {
    public boolean insertar(Cuestionario c);
    public List<Cuestionario> obtenerTodos(); 
    public Cuestionario obtenerPorId (int idCuestionario);
    public boolean actualizar(Cuestionario c);
    public boolean eliminar(int idCuestionario);
    public List<Pregunta> obtenerPreguntasDeCuestionario(int idCuestionario);
}
