
package com.mycompany.doctecnica.Model;


public class Usuario {
    private int ci;
    private String nombre;
    private String apellido;
    private String contrasena;
    private String rol;
   
    public Usuario(){} //constructor default
    public Usuario(int ci, String nom, String ape, String contra, String rol){
        this.ci = ci;
        this.nombre  = nom;
        this.apellido = ape;
        this.contrasena = contra;
        this.rol = rol;
    }
    
   // Getters y Setters
    public int getCi() {
        return ci;
    }

    public void setCi(int ci) {
        this.ci = ci;
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
      
    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getContrasenia() {
        return contrasena;
    }

    public void setContrasenia(String contrasena) {
        this.contrasena = contrasena;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
}
