package com.mycompany.doctecnica;

import com.mycompany.doctecnica.Controlador.ControladorVisual;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.DAO.CuestionarioDAOImp;

public class DocTecnica {
        public static void main(String[] args) {
        
            //ControladorVisual inicio = new ControladorVisual();
            //inicio.iniciarAplicacion();
            CuestionarioDAOImp cuestionarioDAO = new CuestionarioDAOImp();
    
    cuestionarioDAO.eliminar(2);
    
    }
}
