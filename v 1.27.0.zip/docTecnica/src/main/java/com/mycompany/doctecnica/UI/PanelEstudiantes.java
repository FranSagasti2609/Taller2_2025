package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.UI.Escalar;
import javax.swing.*;
import com.mycompany.doctecnica.DAO.UsuarioDAOImp;
import java.util.List;
import com.mycompany.doctecnica.Model.Usuario;
import javax.swing.table.DefaultTableModel;
import com.mycompany.doctecnica.Controlador.ControladorPrincipal;

public class PanelEstudiantes extends javax.swing.JPanel {

    Escalar escalo = new Escalar();
    private DefaultTableModel modeloTabla;
    ControladorPrincipal controlador = new ControladorPrincipal();
    
    public PanelEstudiantes() {
        
        initComponents();
        //Configuro la tabla y cargo datos. agrego decoracion
        configurarTabla();
        cargarEstudiantes();
        escalo.escalarLabel(BackGround, "imagenes/greenBack.jpg");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        BackGround = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        AddEstudianteBoton = new javax.swing.JButton();
        EliminarEstudianteBoton = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        jLabel1.setText("Listado de estudiantes del sistema");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 20, -1, -1));
        add(BackGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 60));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Cedula", "Nombre", "Apellido"
            }
        ));
        jTable1.setSelectionBackground(new java.awt.Color(153, 255, 153));
        jScrollPane1.setViewportView(jTable1);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 670, 370));

        AddEstudianteBoton.setBackground(new java.awt.Color(51, 204, 0));
        AddEstudianteBoton.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        AddEstudianteBoton.setForeground(new java.awt.Color(255, 255, 255));
        AddEstudianteBoton.setText("Registrar");
        AddEstudianteBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddEstudianteBotonActionPerformed(evt);
            }
        });
        add(AddEstudianteBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 450, -1, -1));

        EliminarEstudianteBoton.setBackground(new java.awt.Color(255, 102, 102));
        EliminarEstudianteBoton.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        EliminarEstudianteBoton.setText("Eliminar");
        EliminarEstudianteBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarEstudianteBotonActionPerformed(evt);
            }
        });
        add(EliminarEstudianteBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 450, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void AddEstudianteBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddEstudianteBotonActionPerformed
        // TODO add your handling code here:
        //Llamo a la ventana de registro.
        VentanaRegistro agregarEstVentana = new VentanaRegistro("Estudiante");
        agregarEstVentana.setVisible(true);
        // Cuando la ventana se cierre, recargamos la tabla
         agregarEstVentana.addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowClosed(java.awt.event.WindowEvent e) {
            cargarEstudiantes();
        }
    });
    }//GEN-LAST:event_AddEstudianteBotonActionPerformed

    private void EliminarEstudianteBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarEstudianteBotonActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = jTable1.getSelectedRow();
    
        if (filaSeleccionada == -1) { //sino hay fila selecciona
        JOptionPane.showMessageDialog(this, "Debe seleccionar un estudiante en la tabla");
        return;
    }

    // Obtenemos el CI de la fila seleccionada
    int ci = (int) jTable1.getValueAt(filaSeleccionada, 0);

    int confirm = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de eliminar al estudiante con CI " + ci + " de la base de datos?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION);

    if (confirm == JOptionPane.YES_OPTION) {
        UsuarioDAOImp dao = new UsuarioDAOImp();
        dao.eliminar(ci); // elimina de la BD
        JOptionPane.showMessageDialog(this, "Estudiante eliminado correctamente");
        cargarEstudiantes(); // refrescar la tabla
    }
    }//GEN-LAST:event_EliminarEstudianteBotonActionPerformed
  private void configurarTabla() {
    modeloTabla = new DefaultTableModel(
        new Object[]{"Cedula", "Nombre", "Apellido"}, 0
    ) {
        @Override public boolean isCellEditable(int row, int column) { 
            return false; // tabla solo lectura
        }
    };
    jTable1.setModel(modeloTabla);
    jTable1.setAutoCreateRowSorter(true);
}
  
   private void cargarEstudiantes() {
    DefaultTableModel modelo = (DefaultTableModel) jTable1.getModel();
    modelo.setRowCount(0); // limpia la tabla
    //Traigo los usuarios de la base de datos.
    List<Usuario> estudiantes = controlador.obtenerEstudiantes();
     
      
    if (estudiantes.isEmpty()) {
        modelo.addRow(new Object[]{"-", "No hay estudiantes", "-"});
    } else {
        for (Usuario u : estudiantes) {
            modelo.addRow(new Object[]{u.getCi(), u.getNombre(), u.getApellido()});
        }
    }
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddEstudianteBoton;
    private javax.swing.JLabel BackGround;
    private javax.swing.JButton EliminarEstudianteBoton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
