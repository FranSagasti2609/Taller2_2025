package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.DAO.PreguntaDAOImp;
import com.mycompany.doctecnica.DAO.RespuestaDAOImp;
import com.mycompany.doctecnica.Model.Respuesta;
import com.mycompany.doctecnica.Model.Pregunta;
import java.util.*;
import javax.swing.JOptionPane;

public class ControladorPreguntasRespuestas {
    PreguntaDAOImp preguntaDAO = new PreguntaDAOImp();
    RespuestaDAOImp respuestaDAO = new RespuestaDAOImp();
    
    public List<String> recuperarTemas(){
        List<String> temas = new ArrayList<>();
        temas = preguntaDAO.obtenerTemasPreguntas();
        return temas;
    } 
    
    public void eliminarRespuestas(int idPregunta){
        respuestaDAO.eliminarPorPregunta(idPregunta);
      
    }
    
    public void guardarListaRespuestas(List<Respuesta> respuestas) {
        for(Respuesta res : respuestas){
            respuestaDAO.insertar(res);
        }
        
    }
    
    public boolean eliminarPreguntaYRespuestas(int idPregunta) {
        try {
            // Primero borrar las respuestas
            respuestaDAO.eliminarPorPregunta(idPregunta);

            // Luego borrar la pregunta
            return preguntaDAO.eliminar(idPregunta);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public Pregunta recuperarPreguntaPorId(int idPregunta){
        Pregunta pregunta = preguntaDAO.obtenerPorId(idPregunta);
        return pregunta;
    }
    
    public List<Pregunta> recuperarTodasPreguntas(){
        List<Pregunta> preguntas = preguntaDAO.obtenerTodas();
        return preguntas;
    }
    /**
     * Recupera preguntas aleatorias de la base de datos para un cuestionario.
     * Si no hay suficientes preguntas, muestra un mensaje de error al usuario.
     *
     * @param cantidad número de preguntas que se necesitan
     * @param tema tema específico (puede ser null para tomar de todos los temas)
     * @return lista de preguntas o null si no se pudo completar
     */
    public List<Pregunta> recuperarPreguntasRandom(int cant, String tema){
    try {
        List<Pregunta> preguntas = preguntaDAO.obtenerPreguntasRandom(cant, tema);

        if (preguntas == null || preguntas.size() < cant) {
            JOptionPane.showMessageDialog(null,
                "No hay suficientes preguntas disponibles para cumplir con la cantidad solicitada.",
                "Advertencia",
                JOptionPane.WARNING_MESSAGE);
            return null;
        }

        return preguntas;
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null,
                "Ocurrió un error al recuperar las preguntas.\nDetalles: " + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE);
        return null;
    }
}

}
