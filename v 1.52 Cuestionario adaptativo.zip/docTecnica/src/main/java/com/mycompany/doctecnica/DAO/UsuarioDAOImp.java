package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Usuario;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAOImp extends Conexion implements UsuarioDAO {

    @Override
    public void insertar(Usuario usuario) {
        String sql = "INSERT INTO usuario (ci, nombre, apellido, contrasena, rol) VALUES (?, ?, ?, ?, ?)";
        try {
            conectar();
            ejecutarSentencia(sql,
                    usuario.getCi(),
                    usuario.getNombre(),
                    usuario.getApellido(),
                    usuario.getContrasenia(),
                    usuario.getRol()
            );
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }

    @Override
    public Usuario obtenerPorId(int ci) {
        String sql = "SELECT * FROM usuario WHERE ci = ?";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql, ci);
            if (rs.next()) {
                return new Usuario(
                        rs.getInt("ci"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("contrasena"),
                        rs.getString("rol")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return null;
    }

    @Override
    public List<Usuario> obtenerTodos() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuario";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql);
            while (rs.next()) {
                lista.add(new Usuario(
                        rs.getInt("ci"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("contrasena"),
                        rs.getString("rol")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }

    @Override
    public void actualizar(Usuario usuario) {
        String sql = "UPDATE usuario SET nombre = ?, apellido = ?, contrasena = ?, rol = ? WHERE ci = ?";
        try {
            conectar();
            ejecutarSentencia(sql,
                    usuario.getNombre(),
                    usuario.getApellido(),
                    usuario.getContrasenia(),
                    usuario.getRol(),
                    usuario.getCi()
            );
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }

    @Override
    public void eliminar(int ci) {
    try {
        conectar();
        // Eliminar relaciones en integra
        String sqlIntegra = "DELETE FROM integra WHERE ci_usuario = ?";
        ejecutarSentencia(sqlIntegra, ci);

        // Ahora sí eliminar el usuario
        String sqlUsuario = "DELETE FROM usuario WHERE ci = ?";
        ejecutarSentencia(sqlUsuario, ci);
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
}


    @Override
    public boolean existeDocente() {
        String sql = "SELECT COUNT(*) FROM usuario WHERE rol = 'Docente'";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql);
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return false;
    }

    @Override
    public List<Usuario> obtenerEstudiantes() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuario WHERE rol = 'Estudiante'";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql);
            while (rs.next()) {
                lista.add(new Usuario(
                        rs.getInt("ci"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("contrasena"),
                        rs.getString("rol")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }
}
