package com.mycompany.doctecnica.Model;

public class Grupo {
    private int id_grupo;
    private String nombre;
    private int ci_docente;
    
     // Constructor vacío
    public Grupo() {}

    // Constructor con parámetros
     public Grupo(int id_grupo, String nombre, int ci_docente) {
        this.id_grupo = id_grupo;
        this.nombre = nombre;
        this.ci_docente = ci_docente;
    }

    // Getter y Setter para id_grupo
    public int getId() {
        return id_grupo;
    }

    public void setId(int id_grupo) {
        this.id_grupo = id_grupo;
    }

    // Getter y Setter para nombre
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
     public int getCi_docente() {
        return ci_docente;
    }

    public void setCi_docente(int ci_docente) {
        this.ci_docente = ci_docente;
    }
            
}
