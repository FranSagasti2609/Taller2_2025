package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.DAO.PreguntaDAOImp;
import com.mycompany.doctecnica.DAO.RespuestaDAOImp;
import com.mycompany.doctecnica.Model.Respuesta;
import com.mycompany.doctecnica.Model.Pregunta;
import java.util.*;

public class ControladorPreguntasRespuestas {
    PreguntaDAOImp preguntaDAO = new PreguntaDAOImp();
    RespuestaDAOImp respuestaDAO = new RespuestaDAOImp();
    
    public List<String> recuperarTemas(){
        List<String> temas = new ArrayList<>();
        temas = preguntaDAO.obtenerTemasPreguntas();
        return temas;
    } 
    
    public void eliminarRespuestas(int idPregunta){
        respuestaDAO.eliminarPorPregunta(idPregunta);
      
    }
    
    public void guardarListaRespuestas(List<Respuesta> respuestas) {
        for(Respuesta res : respuestas){
            respuestaDAO.insertar(res);
        }
        
    }
    
    public boolean eliminarPreguntaYRespuestas(int idPregunta) {
        try {
            // Primero borrar las respuestas
            respuestaDAO.eliminarPorPregunta(idPregunta);

            // Luego borrar la pregunta
            return preguntaDAO.eliminar(idPregunta);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public Pregunta recuperarPreguntaPorId(int idPregunta){
        Pregunta pregunta = preguntaDAO.obtenerPorId(idPregunta);
        return pregunta;
    }
    
    public List<Pregunta> recuperarTodasPreguntas(){
        List<Pregunta> preguntas = preguntaDAO.obtenerTodas();
        return preguntas;
    }
}
