package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.TipoPregunta;
import com.mycompany.doctecnica.Model.Nivel;
import com.mycompany.doctecnica.Model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CuestionarioDAOImp extends Conexion implements CuestionarioDAO{
        
    @Override
public boolean insertar(Cuestionario c) {
    String sql = "INSERT INTO cuestionario " +
                 "(titulo, modalidad, ci_usuario, cant_intentos, cantidad_preguntas_aleatorias, retroalimentacion) " +
                 "VALUES (?, ?, ?, ?, ?, ?)";
    try {
        conectar();
        PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        stmt.setString(1, c.getTitulo());
        stmt.setString(2, c.getModalidad());
        stmt.setInt(3, c.getCiUsuario());
        stmt.setInt(4, c.getCantIntentos());
        stmt.setInt(5, c.getCantidadPreguntasAleatorias());
        stmt.setString(6, c.getRetroalimentacion());
        

        int filas = stmt.executeUpdate();
        if (filas > 0) {
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                c.setId_Cuestionario(rs.getInt(1));
            }

            // Insertar las preguntas asociadas (si vienen cargadas en el objeto)
            if (c.getPreguntas() != null) {
                for (Pregunta p : c.getPreguntas()) {
                    agregarPreguntaACuestionario(c.getId_Cuestionario(), p.getId_Pregunta());
                }
            }
            return true;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return false;
}


       @Override
    public List<Cuestionario> obtenerTodos() {
        List<Cuestionario> lista = new ArrayList<>();
        String sql = "SELECT * FROM cuestionario";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql);
            while (rs.next()) {
                lista.add(mapearCuestionario(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }

    @Override
   public Cuestionario obtenerPorId(int id) {
        String sql = "SELECT * FROM cuestionario WHERE id_cuestionario=?";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql, id);
            if (rs.next()) {
                return mapearCuestionario(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return null;
    }

   @Override
public boolean actualizar(Cuestionario c) {
    String sql = "UPDATE cuestionario SET titulo=?, modalidad=?, ci_usuario=?, cant_intentos=?, cantidad_preguntas_aleatorias=?, retroalimentacion=? WHERE id_cuestionario=?";
    try {
        conectar();
        ejecutarSentencia(sql,
            c.getTitulo(),
            c.getModalidad(),
            c.getCiUsuario(),
            c.getCantIntentos(),
            c.getCantidadPreguntasAleatorias(),
            c.getRetroalimentacion(),
            c.getId_Cuestionario()
        );
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return false;
}

    @Override
public boolean eliminar(int id) {
    try {
        // Primero elimino las relaciones en asigna
        eliminarPreguntasDeCuestionario(id);
        //Elimino de la  tabla asigna
        eliminarAsignacion(id);
        
        // Luego elimino el cuestionario
        String sql = "DELETE FROM cuestionario WHERE id_cuestionario=?";
        conectar();
        ejecutarSentencia(sql, id);
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return false;
}


    
   private Cuestionario mapearCuestionario(ResultSet rs) throws SQLException {
        Cuestionario c = new Cuestionario();
        c.setId_Cuestionario(rs.getInt("id_cuestionario"));
        c.setTitulo(rs.getString("titulo"));
        c.setModalidad(rs.getString("modalidad"));
        c.setCiUsuario(rs.getInt("ci_usuario"));
        c.setRetroalimentacion(rs.getString("retroalimentacion"));
        c.setCantIntentos(rs.getInt("cant_intentos"));
        c.setPreguntas(obtenerPreguntasDeCuestionario(c.getId_Cuestionario()));
        c.setCantidadPreguntasAleatorias(rs.getInt("cantidad_preguntas_aleatorias"));
        return c;
    }
   
   @Override
   public List<Pregunta> obtenerPreguntasDeCuestionario(int idCuestionario) {
    List<Pregunta> preguntas = new ArrayList<>();
    String sql = "SELECT p.* FROM asigna a " +
                 "JOIN pregunta p ON a.id_pregunta = p.id_pregunta " +
                 "WHERE a.id_cuestionario = ?";

    try {
        conectar();
        ResultSet rs = ejecutarConsulta(sql, idCuestionario);
        while (rs.next()) {
            Pregunta p = new Pregunta();
            p.setId_Pregunta(rs.getInt("id_pregunta"));
            p.setTema(rs.getString("tema"));
            p.setEnunciado(rs.getString("enunciado"));
            p.setTipo(TipoPregunta.fromString(rs.getString("tipo")));
            p.setNivel(Nivel.fromInt(rs.getInt("nivel")));
            p.setCantApariciones(rs.getInt("cant_apariciones"));
            p.setCantRespuestasCorrectas(rs.getInt("cant_respuestas_correctas"));

            PreguntaDAOImp pdao = new PreguntaDAOImp();
            p.setOpcionesRespuesta(pdao.obtenerOpcionesDeRespuesta(p.getId_Pregunta()));

            preguntas.add(p);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return preguntas;
}

       // Insertar relación (agregar pregunta a un cuestionario)
    public boolean agregarPreguntaACuestionario(int idCuestionario, int idPregunta) {
        String sql = "INSERT INTO asigna (id_cuestionario, id_pregunta) VALUES (?, ?)";
        try {
            conectar();
            ejecutarSentencia(sql, idCuestionario, idPregunta);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }

    // Eliminar TODAS las preguntas asociadas a un cuestionario
    public boolean eliminarPreguntasDeCuestionario(int idCuestionario) {
        String sql = "DELETE FROM asigna WHERE id_cuestionario=?";
        try {
            conectar();
            ejecutarSentencia(sql, idCuestionario);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }

    // Eliminar una sola pregunta de un cuestionario
    public boolean eliminarPreguntaDeCuestionario(int idCuestionario, int idPregunta) {
        String sql = "DELETE FROM asigna WHERE id_cuestionario=? AND id_pregunta=?";
        try {
            conectar();
            ejecutarSentencia(sql, idCuestionario, idPregunta);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
    
    //Eliminar el cuestionario de la tabla realiza *a un estudiante
    public boolean eliminarAsignacion(int idCuestionario){
        String sql = "DELETE FROM realiza WHERE id_cuestionario=?";
        try {
            conectar();
            ejecutarSentencia(sql, idCuestionario);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
    
    public boolean asignarCuestionarioVariosEst(int idCuestionario, List<Usuario> estudiantes){
        String sql = "INSERT IGNORE INTO realiza (ci_usuario, id_cuestionario) values (?, ?)";
        
        try{
            conectar();
             for (Usuario est : estudiantes) {
            ejecutarSentencia(sql, est.getCi(), idCuestionario);
             }
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
  
    };

}

