package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Respuesta;
import java.util.List;

public interface PreguntaDAO {
    void insertar(Pregunta pregunta);
    void actualizar(Pregunta pregunta);
    void eliminar(int idPregunta);
    Pregunta obtenerPorId(int idPregunta);
    List<Pregunta> obtenerTodas();
    List<Respuesta> obtenerOpcionesDeRespuesta(int Pregunta);
    List<String> obtenerTemasPreguntas(); 
   }
