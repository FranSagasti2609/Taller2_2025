package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.DAO.UsuarioDAOImp;
import com.mycompany.doctecnica.DAO.UsuarioDAO;
import com.mycompany.doctecnica.UI.VentanaRegistro;
import com.mycompany.doctecnica.UI.VentanaLogin;

public class ControladorInicial {
   
    private UsuarioDAO usuarioDAO;

    public ControladorInicial() {
        this.usuarioDAO = new UsuarioDAOImp();
    }
    
    public void iniciarAplicacion() {
        if (!usuarioDAO.existeDocente()) {
            // Si no hay docente registrado
            VentanaRegistro registroInicial = new VentanaRegistro("Docente");
            registroInicial.setVisible(true);
        } else {
            // Si ya hay docente registrado
            VentanaLogin loginInicial = new VentanaLogin();
            loginInicial.setVisible(true);
        }
    }
    
}
