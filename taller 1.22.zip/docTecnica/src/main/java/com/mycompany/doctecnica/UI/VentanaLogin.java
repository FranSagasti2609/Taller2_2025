package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.DAO.UsuarioDAO;
import com.mycompany.doctecnica.DAO.UsuarioDAOImp;
import com.mycompany.doctecnica.Model.Usuario;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Image;

public class VentanaLogin extends javax.swing.JFrame {
Escalar escalar = new Escalar();

    public VentanaLogin() {
        initComponents();
        //Colocamos los iconos a nuestro JFrame
        escalar.escalarLabel(jLabel2, "imagenes/CandadoLogin.png");
        escalar.escalarLabel(EvaluameIcon, "imagenes/logo.png");
        escalar.escalarLabel(Estadistica, "imagenes/estadisticaGreen.png");
        
        //Coloco icono personalizado a la ventana
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/logo.png")).getImage());
    }

        @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        BackGround = new javax.swing.JPanel();
        ContrasenaLabel = new javax.swing.JLabel();
        InicioSesionLabel1 = new javax.swing.JLabel();
        CedulaLabel1 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        CIField = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        EvaluameIcon = new javax.swing.JLabel();
        Estadistica = new javax.swing.JLabel();
        BotonLogin = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Ventana de inicio de sesion");
        setResizable(false);

        BackGround.setBackground(new java.awt.Color(255, 255, 255));
        BackGround.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        ContrasenaLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        ContrasenaLabel.setText("Contraseña");
        BackGround.add(ContrasenaLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 180, -1, -1));

        InicioSesionLabel1.setFont(new java.awt.Font("Dubai", 1, 18)); // NOI18N
        InicioSesionLabel1.setText("Inicio de Sesión");
        BackGround.add(InicioSesionLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 40, -1, -1));

        CedulaLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        CedulaLabel1.setText("Cedula");
        BackGround.add(CedulaLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, -1, -1));

        jPasswordField1.setBorder(null);
        jPasswordField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jPasswordField1ActionPerformed(evt);
            }
        });
        BackGround.add(jPasswordField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 220, 220, -1));

        CIField.setBorder(null);
        BackGround.add(CIField, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 140, 220, -1));

        jLabel2.setPreferredSize(new java.awt.Dimension(40, 40));
        BackGround.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 20, 70, 60));

        EvaluameIcon.setPreferredSize(new java.awt.Dimension(40, 40));
        BackGround.add(EvaluameIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, 115, 116));

        Estadistica.setPreferredSize(new java.awt.Dimension(40, 40));
        BackGround.add(Estadistica, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 0, 170, 350));

        BotonLogin.setBackground(new java.awt.Color(51, 204, 0));
        BotonLogin.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        BotonLogin.setForeground(new java.awt.Color(255, 255, 255));
        BotonLogin.setText("Iniciar sesión");
        BotonLogin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonLoginActionPerformed(evt);
            }
        });
        BackGround.add(BotonLogin, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, -1, -1));
        BackGround.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 230, -1));
        BackGround.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 240, 230, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(BackGround, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(BackGround, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jPasswordField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jPasswordField1ActionPerformed

    private void BotonLoginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonLoginActionPerformed
        
    String ciTexto = CIField.getText().trim();
    
    //Manejo de problemas comunes con los campos de entrada, verifico previo a hacer la consulta.
     // Verificar que no esté vacío
    if (ciTexto.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Por favor, ingresa tu cédula.");
        return;
    }
    
        //Verificamos que la cedula sea un numero y no tenga caracteres
    int ci;
    try {
        ci = Integer.parseInt(ciTexto);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "La cédula debe contener solo números.");
        return;
    }
    
    String password = new String( jPasswordField1.getPassword()); //campo de la contrasena
    
    UsuarioDAO dao = new UsuarioDAOImp();
    Usuario usuario = dao.obtenerPorId(ci); //traigo el usuario de la base de datos en base a su CI
     
    // Si el usuario no existe
    if (usuario == null){
        JOptionPane.showMessageDialog(this, "Usuario no encontrado.");
        return;
    }
    //Verificamos que la contraseña sea la correcta (si esta vacia lanza el mensaje)
    if (!usuario.getContrasenia().equals(password)) {
        JOptionPane.showMessageDialog(this, "Contraseña incorrecta.");
        return;
    }
             
    // Aquí inicio de sesión correcto muestro el panel correspondiente
    if(usuario.getRol().equals("Docente")){
        MenuDocente menuDoc = new MenuDocente(usuario);
        menuDoc.setVisible(true);
        //Cerramos la ventana de login.
        dispose();
    }else if(usuario.getRol().equals("Estudiante")){
        MenuEstudiante panelEst = new MenuEstudiante(usuario);
        panelEst.setVisible(true);
        //Cerramos la ventana de login.
        dispose();
      }
    }//GEN-LAST:event_BotonLoginActionPerformed

         
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel BackGround;
    private javax.swing.JButton BotonLogin;
    private javax.swing.JTextField CIField;
    private javax.swing.JLabel CedulaLabel1;
    private javax.swing.JLabel ContrasenaLabel;
    private javax.swing.JLabel Estadistica;
    private javax.swing.JLabel EvaluameIcon;
    private javax.swing.JLabel InicioSesionLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    // End of variables declaration//GEN-END:variables
}
