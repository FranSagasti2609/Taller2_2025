package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Model.Grupo;
import com.mycompany.doctecnica.DAO.GrupoDAOImp;
import com.mycompany.doctecnica.DAO.GrupoDAO;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.Image;
import javax.swing.*;
import java.util.List;

public class PanelGrupo extends javax.swing.JPanel {
    Escalar escalar = new Escalar();
   private Usuario user;
   
    public PanelGrupo(Usuario usuario) {
    this.user = usuario;
    initComponents();
    
    ImageIcon icon = new ImageIcon(getClass().getResource("/imagenes/grupo.png"));
    Image img = icon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
    GrupoIcono.setIcon(new ImageIcon(img));

    // Layout vertical para mostrar botones en el scroll
    PanelScroll.setLayout(new BoxLayout(PanelScroll, BoxLayout.Y_AXIS));

    // Mostrar los grupos desde el inicio
    mostrarGruposDelDocente();
}


       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CrearGrupoLabel = new javax.swing.JLabel();
        NombreGrupoLabel = new javax.swing.JLabel();
        NombreGrupoTextField = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        CrearBoton = new javax.swing.JButton();
        CrearGrupoLabel1 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        GrupoIcono = new javax.swing.JLabel();
        PanelScrollGrupos = new javax.swing.JScrollPane();
        PanelScroll = new javax.swing.JPanel();

        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(null);

        CrearGrupoLabel.setFont(new java.awt.Font("Dubai", 1, 18)); // NOI18N
        CrearGrupoLabel.setText("Creación de grupo");

        NombreGrupoLabel.setFont(new java.awt.Font("Dubai Light", 0, 14)); // NOI18N
        NombreGrupoLabel.setText("Nombre");

        NombreGrupoTextField.setBorder(null);

        CrearBoton.setBackground(new java.awt.Color(51, 204, 0));
        CrearBoton.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        CrearBoton.setForeground(new java.awt.Color(255, 255, 255));
        CrearBoton.setText("Crear");
        CrearBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearBotonActionPerformed(evt);
            }
        });

        CrearGrupoLabel1.setFont(new java.awt.Font("Dubai", 1, 18)); // NOI18N
        CrearGrupoLabel1.setText("Grupos del docente");

        GrupoIcono.setName(""); // NOI18N
        GrupoIcono.setPreferredSize(new java.awt.Dimension(50, 50));

        PanelScrollGrupos.setBorder(null);

        PanelScroll.setBackground(new java.awt.Color(255, 255, 255));
        PanelScroll.setLayout(new javax.swing.BoxLayout(PanelScroll, javax.swing.BoxLayout.LINE_AXIS));
        PanelScrollGrupos.setViewportView(PanelScroll);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(PanelScrollGrupos))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(267, 267, 267)
                                .addComponent(CrearGrupoLabel)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(NombreGrupoLabel)
                                .addGap(68, 68, 68)))
                        .addComponent(GrupoIcono, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 159, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(NombreGrupoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(242, 242, 242))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(CrearBoton)
                        .addGap(294, 294, 294))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(CrearGrupoLabel1)
                        .addGap(253, 253, 253))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CrearGrupoLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(NombreGrupoLabel))
                    .addComponent(GrupoIcono, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(NombreGrupoTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CrearBoton)
                .addGap(18, 18, 18)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(CrearGrupoLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PanelScrollGrupos, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void CrearBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearBotonActionPerformed
        // TODO add your handling code here:
     String nombreGrupo = NombreGrupoTextField.getText().trim();

    if (nombreGrupo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "El nombre del grupo no puede estar vacío");
        return;
    }

    int id = (int) (System.currentTimeMillis() % Integer.MAX_VALUE);
    Grupo nuevo = new Grupo(id, nombreGrupo, user.getCi());

    GrupoDAO dao = new GrupoDAOImp();
    dao.insertar(nuevo);

    NombreGrupoTextField.setText("");
    mostrarGruposDelDocente();
        
    }//GEN-LAST:event_CrearBotonActionPerformed

 private void mostrarGruposDelDocente() {
    PanelScroll.removeAll(); // limpia el panel

    GrupoDAO dao = new GrupoDAOImp();
    List<Grupo> grupos = dao.obtenerPorDocente(user.getCi());

    if (grupos.isEmpty()) {
        JLabel lbl = new JLabel("No tienes grupos creados.");
        lbl.setAlignmentX(CENTER_ALIGNMENT);
        PanelScroll.add(lbl);
    } else {
        for (Grupo g : grupos) {
            JButton btn = new JButton(g.getNombre());
            btn.setAlignmentX(CENTER_ALIGNMENT); // para centrarlo en BoxLayout
            btn.addActionListener(e -> abrirVentanaEstudiantes(g));
            //Personalizamos colores del boton
            btn.setForeground(Color.WHITE);
            btn.setBackground(new Color(51, 204, 0));
            
            PanelScroll.add(btn);
            PanelScroll.add(Box.createVerticalStrut(5)); // espacio entre botones
        }
    }

    PanelScroll.revalidate();
    PanelScroll.repaint();
}

    
    private void abrirVentanaEstudiantes(Grupo grupo) {
    JFrame ventana = new JFrame("Estudiantes del grupo: " + grupo.getNombre());
    ventana.setSize(650, 400);
    ventana.setLocationRelativeTo(this);
    ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    ventana.setResizable(false);
    ventana.setIconImage(new ImageIcon(getClass().getResource("/imagenes/logo.png")).getImage());
    // Usamos el panel con la tabla
    PanelEstudianteDeUnGrupo panel = new PanelEstudianteDeUnGrupo(grupo);
    ventana.add(panel);

    ventana.setVisible(true);
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CrearBoton;
    private javax.swing.JLabel CrearGrupoLabel;
    private javax.swing.JLabel CrearGrupoLabel1;
    private javax.swing.JLabel GrupoIcono;
    private javax.swing.JLabel NombreGrupoLabel;
    private javax.swing.JTextField NombreGrupoTextField;
    private javax.swing.JPanel PanelScroll;
    private javax.swing.JScrollPane PanelScrollGrupos;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    // End of variables declaration//GEN-END:variables
}
