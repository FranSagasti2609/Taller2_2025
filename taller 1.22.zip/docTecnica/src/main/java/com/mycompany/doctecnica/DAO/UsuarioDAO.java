package com.mycompany.doctecnica.DAO;
import com.mycompany.doctecnica.Model.Usuario;
import java.util.List;

public interface UsuarioDAO {
    void insertar(Usuario usuario);
    List<Usuario> obtenerTodos();
    Usuario obtenerPorId(int id);
    void actualizar(Usuario usuario);
    void eliminar(int id);
    List<Usuario> obtenerEstudiantes();
    boolean existeDocente();
}
