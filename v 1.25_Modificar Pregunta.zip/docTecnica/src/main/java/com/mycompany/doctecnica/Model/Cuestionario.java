package com.mycompany.doctecnica.Model;


public class Cuestionario {
    private int id_Cuestionario;
    private String titulo;
    private String modalidad;
    
    private String retroalimentacion;
    private boolean permiteIntentos;
    private int cantIntentos; //esto va solo si permiteIntentos es true
    private int cantidadPreguntasAleatorias; // solo si es random, sino va a ser cero.
    private boolean mostrarCorreccionDetallada;
    
    public Cuestionario(){}
    //Constructor completo
    public Cuestionario(int id_cuestionario, String titulo, String modalidad,
                    String retroalimentacion, boolean permiteIntentos, int cantIntentos,
                    int cantidadPreguntasAleatorias, boolean mostrarCorreccionDetallada) {
    this.id_Cuestionario = id_cuestionario;
    this.titulo = titulo;
    this.modalidad = modalidad;
    this.retroalimentacion = retroalimentacion;
    this.permiteIntentos = permiteIntentos;
    this.cantIntentos = cantIntentos;
    this.cantidadPreguntasAleatorias = cantidadPreguntasAleatorias;
    this.mostrarCorreccionDetallada = mostrarCorreccionDetallada;
}
     // Getter y Setter para id_Cuestionario
    public int getId_Cuestionario() {
        return id_Cuestionario;
    }

    public void setId_Cuestionario(int id_Cuestionario) {
        this.id_Cuestionario = id_Cuestionario;
    }

    // Getter y Setter para titulo
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Getter y Setter para modalidad
    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }
    
    public String getRetroalimentacion() {
    return retroalimentacion;
}

public void setRetroalimentacion(String retroalimentacion) {
    this.retroalimentacion = retroalimentacion;
}

public boolean isPermiteIntentos() {
    return permiteIntentos;
}

public void setPermiteIntentos(boolean permiteIntentos) {
    this.permiteIntentos = permiteIntentos;
}

public int getCantIntentos() {
    return cantIntentos;
}

public void setCantIntentos(int cantIntentos) {
    this.cantIntentos = cantIntentos;
}

public int getCantidadPreguntasAleatorias() {
    return cantidadPreguntasAleatorias;
}

public void setCantidadPreguntasAleatorias(int cantidadPreguntasAleatorias) {
    this.cantidadPreguntasAleatorias = cantidadPreguntasAleatorias;
}

public boolean isMostrarCorreccionDetallada() {
    return mostrarCorreccionDetallada;
}

public void setMostrarCorreccionDetallada(boolean mostrarCorreccionDetallada) {
    this.mostrarCorreccionDetallada = mostrarCorreccionDetallada;
}

}
