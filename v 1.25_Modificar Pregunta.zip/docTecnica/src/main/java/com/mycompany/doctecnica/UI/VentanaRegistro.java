package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.DAO.UsuarioDAO;
import com.mycompany.doctecnica.DAO.UsuarioDAOImp;
import com.mycompany.doctecnica.Model.Usuario;
import javax.swing.ImageIcon;
import com.mycompany.doctecnica.UI.Escalar;
import javax.swing.JOptionPane;

public class VentanaRegistro extends javax.swing.JFrame {
    Escalar escalar = new Escalar();
   
   public VentanaRegistro(String rol) {
        this.rol = rol;
        initComponents();
         //Coloco icono personalizado a la ventana
        setIconImage(new ImageIcon(getClass().getResource("/imagenes/logo.png")).getImage());
        escalar.escalarLabel(RegistroIcono,"imagenes/registro.png" );
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        ApellidoLabel = new javax.swing.JLabel();
        CiLabel1 = new javax.swing.JLabel();
        PassLabelConfirmar = new javax.swing.JLabel();
        NombreLabel1 = new javax.swing.JLabel();
        PassLabel2 = new javax.swing.JLabel();
        CiTextField = new javax.swing.JTextField();
        NombreField = new javax.swing.JTextField();
        ApellidoField = new javax.swing.JTextField();
        PassConfirmarField = new javax.swing.JPasswordField();
        PassField = new javax.swing.JPasswordField();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        RegistroIcono = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Ventana de registro");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(51, 204, 0));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 600, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 40));

        jButton1.setBackground(new java.awt.Color(51, 204, 0));
        jButton1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Registrar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 310, -1, -1));

        jLabel1.setFont(new java.awt.Font("Dubai", 1, 18)); // NOI18N
        jLabel1.setText("Ingresa los campos para registrarte");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 50, -1, -1));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 80, 280, 10));

        ApellidoLabel.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        ApellidoLabel.setText("Apellido");
        jPanel1.add(ApellidoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, -1, -1));

        CiLabel1.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        CiLabel1.setText("Cédula de identidad");
        jPanel1.add(CiLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 110, -1, -1));

        PassLabelConfirmar.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        PassLabelConfirmar.setText("Repite tu contraseña");
        jPanel1.add(PassLabelConfirmar, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 270, -1, -1));

        NombreLabel1.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        NombreLabel1.setText("Nombre");
        jPanel1.add(NombreLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 150, -1, -1));

        PassLabel2.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        PassLabel2.setText("Contraseña");
        jPanel1.add(PassLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 230, -1, -1));

        CiTextField.setBorder(null);
        jPanel1.add(CiTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 110, 260, -1));

        NombreField.setBorder(null);
        jPanel1.add(NombreField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 150, 260, -1));

        ApellidoField.setBorder(null);
        jPanel1.add(ApellidoField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 190, 260, -1));

        PassConfirmarField.setBorder(null);
        jPanel1.add(PassConfirmarField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 270, 260, -1));

        PassField.setBorder(null);
        PassField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PassFieldActionPerformed(evt);
            }
        });
        jPanel1.add(PassField, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, 260, -1));
        jPanel1.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 290, 260, 20));
        jPanel1.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 130, 260, 20));
        jPanel1.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 170, 260, 20));
        jPanel1.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 210, 260, 20));
        jPanel1.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 250, 260, 20));
        jPanel1.add(RegistroIcono, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 40, 50, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 359, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void PassFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PassFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PassFieldActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        //Cuando cliqueamos el boton entonces...
       try {
        int ci = Integer.parseInt(CiTextField.getText().trim());
        String ciTexto = CiTextField.getText().trim(); //para verificar si el campo esta vacio
        String nombre = NombreField.getText().trim();
        String apellido = ApellidoField.getText().trim(); 
        String pass1 = new String(PassField.getPassword()).trim();
        String pass2 = new String(PassConfirmarField.getPassword()).trim();

        // Validar que todos los campos estén completos
        if (ciTexto.isEmpty() || nombre.isEmpty() || apellido.isEmpty() || pass1.isEmpty() ||pass2.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.");
            return;
        }
        
       // Validar que las contraseñas coincidan
        if (!pass1.equals(pass2)) {
            JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden.");
            return;
        }

        // Verificar que no exista ya un usuario con ese CI
        UsuarioDAO dao = new UsuarioDAOImp();
        Usuario existente = dao.obtenerPorId(ci);
        if (existente != null) {
            JOptionPane.showMessageDialog(this, "Ya existe un usuario con esa cédula.");
            return;
        }

        // Crear nuevo usuario y registrarlo
        Usuario nuevo = new Usuario(ci, nombre, apellido, pass1, rol);
        dao.insertar(nuevo);
        if(rol.equals("Docente")){
            JOptionPane.showMessageDialog(this, "Docente registrado con éxito.");
            this.dispose(); // cerrar ventana luego del registro
        }else{
            JOptionPane.showMessageDialog(this, "Estudiante registrado con éxito.");
            this.dispose(); // cerrar ventana luego del registro
        }
        
        
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "La cédula debe ser un número válido.");
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        ex.printStackTrace();
    }
    }//GEN-LAST:event_jButton1ActionPerformed

private String rol = "Docente"; //valor default docente.
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ApellidoField;
    private javax.swing.JLabel ApellidoLabel;
    private javax.swing.JLabel CiLabel1;
    private javax.swing.JTextField CiTextField;
    private javax.swing.JTextField NombreField;
    private javax.swing.JLabel NombreLabel1;
    private javax.swing.JPasswordField PassConfirmarField;
    private javax.swing.JPasswordField PassField;
    private javax.swing.JLabel PassLabel2;
    private javax.swing.JLabel PassLabelConfirmar;
    private javax.swing.JLabel RegistroIcono;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    // End of variables declaration//GEN-END:variables
}
