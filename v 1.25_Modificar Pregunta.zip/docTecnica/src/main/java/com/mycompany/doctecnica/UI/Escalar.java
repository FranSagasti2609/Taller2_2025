package com.mycompany.doctecnica.UI;

import java.awt.Image;
import javax.swing.*;
import java.net.URL;

public class Escalar {

   public void escalarLabel(JLabel label, String rutaImagen) {
    java.net.URL imageUrl = getClass().getResource("/" + rutaImagen);
    if (imageUrl != null) {
        ImageIcon icon = new ImageIcon(imageUrl);

        // Aseguramos que se ejecute cuando el JLabel ya tenga tamaño
        SwingUtilities.invokeLater(() -> {
            int ancho = label.getWidth();
            int alto = label.getHeight();
            if (ancho > 0 && alto > 0) {
                Image img = icon.getImage().getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
                label.setIcon(new ImageIcon(img));
            }
        });
    } else {
        System.err.println("No se encontró la imagen: " + rutaImagen);
    }
}


}
