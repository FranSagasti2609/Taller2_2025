-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         11.8.2-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.10.0.7000
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para evaluame
CREATE DATABASE IF NOT EXISTS `evaluame` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci */;
USE `evaluame`;

-- Volcando estructura para tabla evaluame.asigna
CREATE TABLE IF NOT EXISTS `asigna` (
  `id_cuestionario` int(10) unsigned NOT NULL,
  `id_pregunta` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_cuestionario`,`id_pregunta`),
  KEY `FK__asig_pregunta` (`id_pregunta`),
  KEY `idx_asigna_pregunta` (`id_pregunta`),
  CONSTRAINT `FK__asig_cuestionario` FOREIGN KEY (`id_cuestionario`) REFERENCES `cuestionario` (`id_cuestionario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK__asig_pregunta` FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta` (`id_pregunta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla evaluame.cuestionario
CREATE TABLE IF NOT EXISTS `cuestionario` (
  `id_cuestionario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(50) NOT NULL DEFAULT '',
  `modalidad` varchar(50) NOT NULL DEFAULT '',
  `ci_usuario` int(10) unsigned NOT NULL DEFAULT 0,
  `cant_intentos` int(11) DEFAULT 0,
  `cantidad_preguntas_aleatorias` int(11) DEFAULT 0,
  `retroalimentacion` varchar(50) NOT NULL DEFAULT 'numerica',
  PRIMARY KEY (`id_cuestionario`),
  KEY `FK__cuest_usuario` (`ci_usuario`),
  CONSTRAINT `FK__cuest_usuario` FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla evaluame.grupo
CREATE TABLE IF NOT EXISTS `grupo` (
  `id_grupo` int(10) unsigned NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `ci_usuario` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id_grupo`),
  KEY `FK__usuario` (`ci_usuario`),
  CONSTRAINT `FK__usuario` FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla evaluame.integra
CREATE TABLE IF NOT EXISTS `integra` (
  `ci_usuario` int(10) unsigned NOT NULL,
  `id_grupo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`ci_usuario`,`id_grupo`),
  KEY `FK_integra_grupo` (`id_grupo`),
  CONSTRAINT `FK_integra_grupo` FOREIGN KEY (`id_grupo`) REFERENCES `grupo` (`id_grupo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_integra_usuario` FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla evaluame.pregunta
CREATE TABLE IF NOT EXISTS `pregunta` (
  `id_pregunta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tema` varchar(50) NOT NULL DEFAULT '',
  `enunciado` varchar(250) NOT NULL DEFAULT '',
  `tipo` varchar(50) NOT NULL DEFAULT '',
  `nivel` int(11) NOT NULL DEFAULT 0,
  `cant_apariciones` int(11) NOT NULL DEFAULT 0,
  `ci_usuario` int(10) unsigned NOT NULL DEFAULT 0,
  `cant_respuestas_correctas` int(11) DEFAULT 0,
  PRIMARY KEY (`id_pregunta`),
  KEY `FK__preg_usuario` (`ci_usuario`),
  CONSTRAINT `FK__preg_usuario` FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla evaluame.realiza
CREATE TABLE IF NOT EXISTS `realiza` (
  `ci_usuario` int(10) unsigned NOT NULL,
  `id_cuestionario` int(10) unsigned NOT NULL,
  `cant_intentos` int(10) unsigned NOT NULL,
  `estado` enum('PENDIENTE','FINALIZADO') NOT NULL DEFAULT 'PENDIENTE',
  PRIMARY KEY (`ci_usuario`,`id_cuestionario`),
  KEY `FK__realiza_cuestionario` (`id_cuestionario`),
  CONSTRAINT `FK__realiza_cuestionario` FOREIGN KEY (`id_cuestionario`) REFERENCES `cuestionario` (`id_cuestionario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK__realiza_usuario` FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla evaluame.responde
CREATE TABLE IF NOT EXISTS `responde` (
  `num_respuesta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_pregunta` int(10) unsigned NOT NULL,
  `ci_usuario` int(10) unsigned NOT NULL,
  `es_correcta` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`num_respuesta`),
  KEY `FK__responde_usuario` (`ci_usuario`),
  KEY `fk_responde_pregunta` (`id_pregunta`),
  CONSTRAINT `FK__responde_usuario` FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_responde_pregunta` FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta` (`id_pregunta`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_responde_usuario` FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla evaluame.respuesta
CREATE TABLE IF NOT EXISTS `respuesta` (
  `id_respuesta` int(11) NOT NULL AUTO_INCREMENT,
  `id_pregunta` int(10) unsigned NOT NULL,
  `enunciado` varchar(250) NOT NULL,
  `es_correcta` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_respuesta`),
  KEY `id_pregunta` (`id_pregunta`),
  CONSTRAINT `respuesta_ibfk_1` FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta` (`id_pregunta`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla evaluame.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `ci` int(10) unsigned NOT NULL,
  `nombre` varchar(50) NOT NULL DEFAULT '',
  `apellido` varchar(50) NOT NULL DEFAULT '',
  `contrasena` char(32) NOT NULL DEFAULT '',
  `rol` enum('Docente','Estudiante') NOT NULL DEFAULT 'Docente',
  PRIMARY KEY (`ci`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;

-- La exportación de datos fue deseleccionada.

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
