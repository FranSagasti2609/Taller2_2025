package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.Model.Responde;
import com.mycompany.doctecnica.DAO.RespondeDAOImp;
import java.util.List;

public class ControladorRespuestas {
    
    RespondeDAOImp dao = new RespondeDAOImp();
    
    public boolean guardarRespuesta(Responde res){
        return dao.guardarRespuesta(res);
    }
    
    public boolean borrarRespuestas(int ci, int id_cuest){
        return dao.borrarRespuestasPrevias(ci, id_cuest);
    }
    
    public boolean restarIntentosEstudiante(int ci, int id_cuest){
        return dao.restarIntento(ci, id_cuest);
    }
    
    public boolean cambiarEstadoEstudiante(int ci, int id_cuest){
        return dao.cambiarEstado(ci, id_cuest);
    }
    
    public int obtenerIntentosDisponibles(int ci, int ci_cuest){
        return dao.obtenerIntentosDisponibles(ci, ci_cuest);
    }
    
    public List<Responde> getRespuestas(int ci, int id_cuest){
        return dao.obtenerRespuestasDeCuestionario(ci, id_cuest);
    }
}
