package com.mycompany.doctecnica.UI.uc;

import com.mycompany.doctecnica.Model.Respuesta;

public interface IUcPregunta {
    public Respuesta getRespuesta();
}
