package com.mycompany.doctecnica.UI;

import javax.swing.*;
import com.mycompany.doctecnica.DAO.UsuarioDAOImp;
import java.util.List;
import com.mycompany.doctecnica.Model.Usuario;
import javax.swing.table.DefaultTableModel;
import com.mycompany.doctecnica.Controlador.ControladorPrincipal;
import java.awt.Color;

public class PanelEstudiantes extends javax.swing.JPanel {

    private DefaultTableModel modeloTabla;
    ControladorPrincipal controlador = new ControladorPrincipal();
    
    public PanelEstudiantes() {
        
        initComponents();
        //Configuro la tabla y cargo datos. agrego decoracion
       TablaEstudiantes.getTableHeader().setOpaque(false);
       TablaEstudiantes.getTableHeader().setBackground(new Color(32,136,203));
       TablaEstudiantes.getTableHeader().setForeground(new Color(255,255,255));
       TablaEstudiantes.setRowHeight(25);
        configurarTabla();
        cargarEstudiantes();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        EstIcon = new javax.swing.JLabel();
        BackGround = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaEstudiantes = new javax.swing.JTable();
        AddEstudianteBoton = new javax.swing.JButton();
        EliminarEstudianteBoton = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setRequestFocusEnabled(false);
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Dubai", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 204));
        jLabel1.setText("Listado de estudiantes del sistema");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 2, -1, -1));

        EstIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/est50x50.png"))); // NOI18N
        add(EstIcon, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 420, -1, -1));

        BackGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/greenBackSCALED.jpg"))); // NOI18N
        add(BackGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 40));

        TablaEstudiantes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Cedula", "Nombre", "Apellido"
            }
        ));
        TablaEstudiantes.setFocusable(false);
        TablaEstudiantes.setRowHeight(25);
        TablaEstudiantes.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaEstudiantes.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaEstudiantes.setShowVerticalLines(true);
        jScrollPane1.setViewportView(TablaEstudiantes);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 670, 370));

        AddEstudianteBoton.setBackground(new java.awt.Color(51, 204, 0));
        AddEstudianteBoton.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        AddEstudianteBoton.setForeground(new java.awt.Color(255, 255, 255));
        AddEstudianteBoton.setText("Registrar");
        AddEstudianteBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddEstudianteBotonActionPerformed(evt);
            }
        });
        add(AddEstudianteBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 450, -1, -1));

        EliminarEstudianteBoton.setBackground(new java.awt.Color(255, 102, 102));
        EliminarEstudianteBoton.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        EliminarEstudianteBoton.setText("Eliminar");
        EliminarEstudianteBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarEstudianteBotonActionPerformed(evt);
            }
        });
        add(EliminarEstudianteBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 450, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void AddEstudianteBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddEstudianteBotonActionPerformed
        // TODO add your handling code here:
        //Llamo a la ventana de registro.
        VentanaRegistro agregarEstVentana = new VentanaRegistro("Estudiante");
        agregarEstVentana.setVisible(true);
        // Cuando la ventana se cierre, recargamos la tabla
         agregarEstVentana.addWindowListener(new java.awt.event.WindowAdapter() {
        @Override
        public void windowClosed(java.awt.event.WindowEvent e) {
            cargarEstudiantes();
        }
    });
    }//GEN-LAST:event_AddEstudianteBotonActionPerformed

    private void EliminarEstudianteBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarEstudianteBotonActionPerformed
        // TODO add your handling code here:
        int filaSeleccionada = TablaEstudiantes.getSelectedRow();
    
        if (filaSeleccionada == -1) { //sino hay fila selecciona
        JOptionPane.showMessageDialog(this, "Debe seleccionar un estudiante en la tabla");
        return;
    }

    // Obtenemos el CI de la fila seleccionada
    int ci = (int) TablaEstudiantes.getValueAt(filaSeleccionada, 0);

    int confirm = JOptionPane.showConfirmDialog(this,
            "¿Está seguro de eliminar al estudiante con CI " + ci + " de la base de datos?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION);

    if (confirm == JOptionPane.YES_OPTION) {
        UsuarioDAOImp dao = new UsuarioDAOImp();
        dao.eliminar(ci); // elimina de la BD
        JOptionPane.showMessageDialog(this, "Estudiante eliminado correctamente");
        cargarEstudiantes(); // refrescar la tabla
    }
    }//GEN-LAST:event_EliminarEstudianteBotonActionPerformed
  private void configurarTabla() {
    modeloTabla = new DefaultTableModel(
        new Object[]{"Cedula", "Nombre", "Apellido"}, 0
    ) {
        @Override public boolean isCellEditable(int row, int column) { 
            return false; // tabla solo lectura
        }
    };
    TablaEstudiantes.setModel(modeloTabla);
    TablaEstudiantes.setAutoCreateRowSorter(true);
}
  
   private void cargarEstudiantes() {
    DefaultTableModel modelo = (DefaultTableModel) TablaEstudiantes.getModel();
    modelo.setRowCount(0); // limpia la tabla
    //Traigo los usuarios de la base de datos.
    List<Usuario> estudiantes = controlador.obtenerEstudiantes();
     
      
    if (estudiantes.isEmpty()) {
        modelo.addRow(new Object[]{"-", "No hay estudiantes", "-"});
    } else {
        for (Usuario u : estudiantes) {
            modelo.addRow(new Object[]{u.getCi(), u.getNombre(), u.getApellido()});
        }
    }
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AddEstudianteBoton;
    private javax.swing.JLabel BackGround;
    private javax.swing.JButton EliminarEstudianteBoton;
    private javax.swing.JLabel EstIcon;
    private javax.swing.JTable TablaEstudiantes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
