package com.mycompany.doctecnica.Model;

public class Responde {
    private int num_respuesta;   // Número de la respuesta elegida
    private int id_pregunta;     // Pregunta a la que pertenece esa respuesta
    private int ci_usuario;      // Estudiante que respondió
    private boolean es_correcta;  // Para guardar si fue correcta o no

    
    public Responde() {}

    public Responde(int id_pregunta, int ci_usuario,boolean esCorrecta) {
        this.id_pregunta = id_pregunta;
        this.ci_usuario = ci_usuario;
        this.es_correcta = esCorrecta;
    }

    public int getNumRespuesta() {
        return num_respuesta;
    }

    public void setNumRespuesta(int nro_respuesta) {
        this.num_respuesta = nro_respuesta;
    }

    public int getIdPregunta() {
        return id_pregunta;
    }

    public void setIdPregunta(int id_pregunta) {
        this.id_pregunta = id_pregunta;
    }

    public int getCiUsuario() {
        return ci_usuario;
    }

    public void setCiUsuario(int ci_usuario) {
        this.ci_usuario = ci_usuario;
    }

    public boolean EsCorrecta() {
        return es_correcta;
    }

    public void setEsCorrecta(boolean esCorrecta) {
        this.es_correcta = esCorrecta;
    }
    
    public boolean getEsCorrecta(){
        return this.es_correcta;
    }


}
