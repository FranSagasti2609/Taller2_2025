package com.mycompany.doctecnica.Model;

import com.mycompany.doctecnica.Model.Pregunta;
import java.util.List;

public class Cuestionario {
    private int id_Cuestionario;
    private String titulo;
    private String modalidad;
    private int ciDocente;
    
    private String retroalimentacion;
    private int cantIntentos;
    private int cantidadPreguntasAleatorias; // solo si es random, sino va a ser cero.
    private List<Pregunta> preguntas;
    
    private String temaFiltro; //variable que no se almacena en la BD, sirve para asignar el tema para los aleatorios.
        
    public Cuestionario(){}
    //Constructor completo
    public Cuestionario(String titulo, String modalidad, int ciDocente,
                    String retroalimentacion, int cantIntentos,
                    int cantidadPreguntasAleatorias) {
    this.titulo = titulo;
    this.modalidad = modalidad;
    this.ciDocente = ciDocente;
    this.retroalimentacion = retroalimentacion;
    this.cantIntentos = cantIntentos;
    this.cantidadPreguntasAleatorias = cantidadPreguntasAleatorias;
}
     // Getter y Setter para id_Cuestionario
    public int getId_Cuestionario() {
        return id_Cuestionario;
    }

    public void setId_Cuestionario(int id_Cuestionario) {
        this.id_Cuestionario = id_Cuestionario;
    }

    // Getter y Setter para titulo
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    // Getter y Setter para modalidad
    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }
    
    public String getRetroalimentacion() {
    return retroalimentacion;
}

public void setRetroalimentacion(String retroalimentacion) {
    this.retroalimentacion = retroalimentacion;
}

public int getCiUsuario() { 
    return ciDocente; 
}
public void setCiUsuario(int ciUsuario) { this.ciDocente = ciUsuario; }


public int getCantIntentos() {
    return cantIntentos;
}

public void setCantIntentos(int cantIntentos) {
    this.cantIntentos = cantIntentos;
}

public int getCantidadPreguntasAleatorias() {
    return cantidadPreguntasAleatorias;
}

public void setCantidadPreguntasAleatorias(int cantidadPreguntasAleatorias) {
    this.cantidadPreguntasAleatorias = cantidadPreguntasAleatorias;
}

public List<Pregunta> getPreguntas(){
    return preguntas;
}

public void setPreguntas(List <Pregunta> preguns){
    this.preguntas = preguns;
}

public void setTemaFiltro(String tm){
    this.temaFiltro = tm;
}

public String getTemaFiltro(){
    return this.temaFiltro;
}


}
