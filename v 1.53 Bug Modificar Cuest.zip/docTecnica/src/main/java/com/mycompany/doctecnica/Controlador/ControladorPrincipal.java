package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.DAO.GrupoDAOImp;
import com.mycompany.doctecnica.DAO.UsuarioDAOImp;
import com.mycompany.doctecnica.DAO.CuestionarioDAOImp;
import com.mycompany.doctecnica.DAO.RespondeDAOImp;
import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Model.Grupo;

import java.util.*;

public class ControladorPrincipal {
    GrupoDAOImp grupoDAO = new GrupoDAOImp();
    UsuarioDAOImp usuarioDAO = new UsuarioDAOImp();
    CuestionarioDAOImp cuestDAO = new CuestionarioDAOImp();
    RespondeDAOImp resDAO = new RespondeDAOImp();
    
    public List<Usuario>obtenerEstudiantesPorGrupo(int idGrupo){
        List<Usuario> usuariosGrupo = new ArrayList<>();
        usuariosGrupo = grupoDAO.obtenerEstudiantesPorGrupo(idGrupo);
        return usuariosGrupo;
    }
    
   public boolean eliminarEstudianteGrupo(int ci, int idGrupo){
      return grupoDAO.eliminarEstudianteDeGrupo(ci, idGrupo);
    }
   
    /**
     * Intenta agregar un estudiante a un grupo con validaciones previas.
     * @param ciUsuario CI del estudiante
     * @param idGrupo ID del grupo
     * @return mensaje con el resultado de la operación
     */
    public String agregarEstudianteAGrupo(int ciUsuario, int idGrupo) {
        try {
            // Validar existencia usando la cedula
            if (!grupoDAO.existeUsuario(ciUsuario)) {
                return "El usuario no existe en la base de datos.";
            }

            // Validar si ya está en otro grupo
            if (grupoDAO.estaEnAlgúnGrupo(ciUsuario)) {
                return "El usuario ya pertenece a otro grupo.";
            }

            // Intentar agregar
            boolean agregado = grupoDAO.agregarEstudianteAGrupo(ciUsuario, idGrupo);

            if (agregado) {
                return "OK";
            } else {
                return "No se pudo agregar el estudiante al grupo.";
            }

        } catch (Exception e) {
            e.printStackTrace();
            return "Error inesperado: " + e.getMessage();
        }
    }
    
    /**
     * Valida un inicio de sesión.
     * @param ciTexto cédula en formato String
     * @param password contraseña ingresada
     * @return objeto Usuario si es válido, null en caso contrario
     * @throws IllegalArgumentException con mensajes específicos de error
     */
    public Usuario login(String ciTexto, String password) throws IllegalArgumentException {
        // Verificar que el campo esta vacio
        if (ciTexto == null || ciTexto.trim().isEmpty()) {
            throw new IllegalArgumentException("Por favor, ingresa tu cédula.");
        }

        // Verificar que sea número y no otro tipo de dato
        int ci;
        try {
            ci = Integer.parseInt(ciTexto.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("La cédula debe contener solo números.");
        }

        // Verificar contraseña vacía
        if (password == null || password.isEmpty()) {
            throw new IllegalArgumentException("Por favor, ingresa tu contraseña.");
        }

        // Buscar usuario en BD
        Usuario usuario = usuarioDAO.obtenerPorId(ci);
        if (usuario == null) {
            throw new IllegalArgumentException("Usuario no encontrado.");
        }

        if (!usuario.getContrasenia().equals(password)) {
            throw new IllegalArgumentException("Contraseña incorrecta.");
        }

        return usuario;
    }
    
    public void registrarUsuario(String ciTexto, String nombre, String apellido, 
                                 String pass1, String pass2, String rol) throws IllegalArgumentException {
         
    // Validar que no haya campos vacíos
        if (ciTexto == null || ciTexto.trim().isEmpty() ||
            nombre == null || nombre.trim().isEmpty() ||
            apellido == null || apellido.trim().isEmpty() ||
            pass1 == null || pass1.trim().isEmpty() ||
            pass2 == null || pass2.trim().isEmpty()) {
            throw new IllegalArgumentException("Todos los campos son obligatorios.");
        }
        
    // Validar que CI sea número
        int ci;
        try {
            ci = Integer.parseInt(ciTexto.trim());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("La cédula debe ser un número válido.");
        }
        
    //Validar que las contrasenas coincidan
        if(!pass1.equals(pass2)){
        throw new IllegalArgumentException("Las contraseñas no coinciden.");
        }
    //Validar que no haya usuario con esa CI registrado ya
    Usuario userExiste = usuarioDAO.obtenerPorId(ci);
    if(userExiste != null){
        throw new IllegalArgumentException("El usuario ya esta registrado en la base de datos.");
             }
    
    //Inserto en la bd
    Usuario nuevo = new Usuario(ci, nombre, apellido, pass1, rol);
    usuarioDAO.insertar(nuevo);
    }
    
    
    public List<Usuario> obtenerEstudiantes(){
        List<Usuario> estudiantes = usuarioDAO.obtenerEstudiantes();
        return estudiantes;
        }
    
    public void agregarGrupo(Grupo gr){
        grupoDAO.insertar(gr);
    }
    
    public List<Grupo> obtenerGrupoPorCI(int ciDocente){
        List<Grupo> grupos = new ArrayList<>();
        grupos = grupoDAO.obtenerPorDocente(ciDocente);
        return grupos;
    }
    
    public int obtenerCalificacion(int ci, int id_cuestionario){
        int correctas = resDAO.contarPreguntasCorrectas(ci, id_cuestionario);
        int totales = cuestDAO.obtenerCantidadPreguntas(id_cuestionario);

             return Math.round((float) correctas * 10 / totales);

    }
    
    public Usuario getUsuario(int ci){
        return usuarioDAO.obtenerPorId(ci);
    }
}
