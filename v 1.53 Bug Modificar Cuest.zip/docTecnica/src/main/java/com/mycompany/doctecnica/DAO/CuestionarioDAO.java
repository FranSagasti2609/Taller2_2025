package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Usuario;
import java.util.List;
import java.util.Map;

public interface CuestionarioDAO {
    public boolean insertar(Cuestionario c);
    public List<Cuestionario> obtenerTodos(); 
    public Cuestionario obtenerPorId (int idCuestionario);
    public boolean actualizar(Cuestionario c);
    public boolean eliminar(int idCuestionario);
    public List<Pregunta> obtenerPreguntasDeCuestionario(int idCuestionario);
    public boolean asignarCuestionarioVariosEst(int idCuestionario, List<Usuario> estudiantes, Cuestionario cuest);
    List<Cuestionario> obtenerCuestionariosAsignados(int ciEstudiante);
    public int obtenerCantidadPreguntas(int id_cuestionario);
    public Map<Integer, List<Pregunta>> obtenerPreguntasOrdenadas (int idCuestionario);
}
