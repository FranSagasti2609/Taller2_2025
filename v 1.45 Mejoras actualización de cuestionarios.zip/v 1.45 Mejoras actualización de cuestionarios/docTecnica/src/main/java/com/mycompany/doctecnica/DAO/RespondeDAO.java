package com.mycompany.doctecnica.DAO;
import com.mycompany.doctecnica.Model.Responde;

public interface RespondeDAO {
    public boolean guardarRespuesta(Responde res);
    public boolean cambiarEstado(int ci, int id_cuestionario);
    public boolean restarIntento(int ci, int id_cuestionario);
    public int obtenerIntentosDisponibles(int ci, int id_cuestionario);
    public void agregarIntentosNuevos(int id_cuestionario, int diferencia);
}
