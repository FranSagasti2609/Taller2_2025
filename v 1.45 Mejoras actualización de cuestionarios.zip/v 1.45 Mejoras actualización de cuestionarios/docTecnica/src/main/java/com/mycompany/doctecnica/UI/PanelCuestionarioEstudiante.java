package com.mycompany.doctecnica.UI;

import javax.swing.JOptionPane;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Usuario;
import java.util.List;
import javax.swing.table.DefaultTableModel;
import com.mycompany.doctecnica.Controlador.ControladorCuestionario;
import com.mycompany.doctecnica.Controlador.ControladorRespuestas;
import java.awt.Color;
import javax.swing.JPanel;

public class PanelCuestionarioEstudiante extends javax.swing.JPanel {

    private DefaultTableModel modeloCuestionarios;
    ControladorCuestionario controladorCues = new ControladorCuestionario();
    ControladorRespuestas controladorResp = new ControladorRespuestas();
    Usuario user;
    JPanel zonaTrabajo;
    
    public PanelCuestionarioEstudiante(Usuario usuario, JPanel zonaTrabajo) {
        this.user = usuario;
        this.zonaTrabajo = zonaTrabajo;
        initComponents();
        //Configuro la tabla y cargo datos. agrego decoracion
       TablaCuestionarios.getTableHeader().setOpaque(false);
       TablaCuestionarios.getTableHeader().setBackground(new Color(32,136,203));
       TablaCuestionarios.getTableHeader().setForeground(new Color(255,255,255));
       TablaCuestionarios.setRowHeight(25);
        configurarTabla();
        cargarCuestionarios();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        BackGround = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaCuestionarios = new javax.swing.JTable();
        RealizarCuesBoton = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setRequestFocusEnabled(false);
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Dubai", 0, 20)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 204));
        jLabel1.setText("Cuestionarios asignados");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 2, -1, -1));

        BackGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/greenBackSCALED.jpg"))); // NOI18N
        add(BackGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 40));

        TablaCuestionarios.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        TablaCuestionarios.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Titulo", "Modalidad", "Intentos restantes"
            }
        ));
        TablaCuestionarios.setFocusable(false);
        TablaCuestionarios.setRowHeight(25);
        TablaCuestionarios.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaCuestionarios.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaCuestionarios.setShowVerticalLines(true);
        jScrollPane1.setViewportView(TablaCuestionarios);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 670, 370));

        RealizarCuesBoton.setBackground(new java.awt.Color(51, 204, 0));
        RealizarCuesBoton.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        RealizarCuesBoton.setForeground(new java.awt.Color(255, 255, 255));
        RealizarCuesBoton.setText("Realizar");
        RealizarCuesBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RealizarCuesBotonActionPerformed(evt);
            }
        });
        add(RealizarCuesBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 450, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void RealizarCuesBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RealizarCuesBotonActionPerformed
        // TODO add your handling code here:
        int fila = TablaCuestionarios.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona un cuestionario para comenzar.");
        return;
       }
        int idCuestionario = Integer.parseInt(TablaCuestionarios.getValueAt(fila, 0).toString());
        
       //Recuperamos el cuestionario
       Cuestionario cuest = controladorCues.obtenerCuesPorId(idCuestionario);
      
       //Verificamos intentos antes de abrir el panel...
       if(controladorResp.obtenerIntentosDisponibles(user.getCi(), cuest.getId_Cuestionario()) <1){
           JOptionPane.showMessageDialog(this, "No te quedan intentos para este cuestionario.");
    return;
       } else{
           
          PanelRealizarCuestionario panelRealizo = new PanelRealizarCuestionario(user, cuest, zonaTrabajo);
           zonaTrabajo.removeAll();
           zonaTrabajo.add(panelRealizo);
           zonaTrabajo.revalidate();
           zonaTrabajo.repaint();
       
       }

    }//GEN-LAST:event_RealizarCuesBotonActionPerformed
  
    private void configurarTabla() {
    modeloCuestionarios = new DefaultTableModel(
        new Object[]{"ID", "Título", "Modalidad", "Intentos permitidos"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    TablaCuestionarios.setModel(modeloCuestionarios);
    // Ocultar la columna ID para que el usuario no la vea
    TablaCuestionarios.getColumnModel().getColumn(0).setMinWidth(0);
    TablaCuestionarios.getColumnModel().getColumn(0).setMaxWidth(0);
    TablaCuestionarios.getColumnModel().getColumn(0).setWidth(0);
    TablaCuestionarios.setAutoCreateRowSorter(true);
}
  
   private void cargarCuestionarios() {
    modeloCuestionarios.setRowCount(0);

    List<Cuestionario> lista = controladorCues.obtenerCuestionariosEst(user.getCi());
    for (Cuestionario c : lista) {
        modeloCuestionarios.addRow(new Object[]{
            c.getId_Cuestionario(),
            c.getTitulo(),
            c.getModalidad(),
            controladorResp.obtenerIntentosDisponibles(user.getCi(), c.getId_Cuestionario())//obtengo los intentos disponibles para ese cuestionario!
        });
    }
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BackGround;
    private javax.swing.JButton RealizarCuesBoton;
    private javax.swing.JTable TablaCuestionarios;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
