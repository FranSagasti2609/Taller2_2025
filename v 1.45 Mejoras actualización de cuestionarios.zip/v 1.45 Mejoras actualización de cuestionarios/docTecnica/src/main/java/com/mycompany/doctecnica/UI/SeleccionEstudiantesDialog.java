package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Model.Grupo;
import com.mycompany.doctecnica.Controlador.ControladorPrincipal;
import java.awt.*;
import java.awt.event.*;
import java.util.List;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.*;
public class SeleccionEstudiantesDialog extends JDialog {
    
        private int idCustionario;
        private Grupo grupo;
        private List<Usuario> estSeleccionados = new ArrayList<>();
        private ControladorPrincipal controlador = new ControladorPrincipal();
        public SeleccionEstudiantesDialog(Frame parent, boolean modal, Grupo gr, int idCuest) {
        super(parent, modal);
        this.grupo = gr;
        this.idCustionario = idCuest;
        
        setTitle("Seleccionar estudiantes de: " + gr.getNombre());
        setSize(670,500);
        setLocationRelativeTo(parent);
        initComponents();
       TablaEstudiantes.getTableHeader().setOpaque(false);
       TablaEstudiantes.getTableHeader().setBackground(new Color(32,136,203));
       TablaEstudiantes.getTableHeader().setForeground(new Color(255,255,255));
       TablaEstudiantes.setRowHeight(25);
       
       //traemos los estudiantes y los cargamos
        List<Usuario> estudiantesGrupo = controlador.obtenerEstudiantesPorGrupo(grupo.getId());
        configurarTablaEstudiantes(estudiantesGrupo);
        
        //Al tocar el boton de seleccionar
        BotonSeleccionarEst.addActionListener(e -> {
        estSeleccionados.clear();
        DefaultTableModel model = (DefaultTableModel) TablaEstudiantes.getModel();

        for (int i = 0; i < model.getRowCount(); i++) {
            Boolean seleccionado = (Boolean) model.getValueAt(i, 0);
            if (seleccionado != null && seleccionado) {
                Usuario u = new Usuario();
                u.setCi((Integer) model.getValueAt(i, 1));
                u.setNombre((String) model.getValueAt(i, 2));
                u.setApellido((String) model.getValueAt(i, 3));
                estSeleccionados.add(u);
            }
        }

        if (estSeleccionados.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No seleccionaste ningún estudiante.");
            return;
        }

        JOptionPane.showMessageDialog(this, "Seleccionados: " + estSeleccionados.size());
        dispose();
        
});

        //Si el usuario marca el boton seleccionar todos..
        BotonTodos.addActionListener(e -> {
        DefaultTableModel model = (DefaultTableModel) TablaEstudiantes.getModel();
        boolean marcar = BotonTodos.getText().equals("Marcar todos");

        for (int i = 0; i < model.getRowCount(); i++) {
        model.setValueAt(marcar, i, 0);
        }

        BotonTodos.setText(marcar ? "Desmarcar todos" : "Marcar todos");
});
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPaneTabla = new javax.swing.JScrollPane();
        TablaEstudiantes = new javax.swing.JTable();
        BotonSeleccionarEst = new javax.swing.JButton();
        BotonTodos = new javax.swing.JButton();

        setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });

        jScrollPaneTabla.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N

        TablaEstudiantes.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        TablaEstudiantes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Seleccionar", "Cedula", "Nombre", "Apellido"
            }
        ));
        TablaEstudiantes.setFocusable(false);
        TablaEstudiantes.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaEstudiantes.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaEstudiantes.setShowVerticalLines(true);
        jScrollPaneTabla.setViewportView(TablaEstudiantes);

        BotonSeleccionarEst.setBackground(new java.awt.Color(51, 204, 0));
        BotonSeleccionarEst.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        BotonSeleccionarEst.setForeground(new java.awt.Color(255, 255, 255));
        BotonSeleccionarEst.setText("Seleccionar");

        BotonTodos.setBackground(new java.awt.Color(51, 204, 0));
        BotonTodos.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        BotonTodos.setForeground(new java.awt.Color(255, 255, 255));
        BotonTodos.setText("Marcar todos");
        BotonTodos.setToolTipText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPaneTabla, javax.swing.GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(BotonTodos)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BotonSeleccionarEst)
                .addGap(296, 296, 296))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jScrollPaneTabla, javax.swing.GroupLayout.PREFERRED_SIZE, 459, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BotonSeleccionarEst)
                    .addComponent(BotonTodos))
                .addGap(0, 5, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        setVisible(false);
        dispose();
    }//GEN-LAST:event_closeDialog


    private void configurarTablaEstudiantes(List<Usuario> estudiantes) {
    DefaultTableModel modelo = new DefaultTableModel(
        new Object[]{"Seleccionar", "Cédula", "Nombre", "Apellido"}, 0
    ) {
        @Override
        public Class<?> getColumnClass(int columnIndex) {
            return columnIndex == 0 ? Boolean.class : super.getColumnClass(columnIndex);
        }
        @Override
        public boolean isCellEditable(int row, int column) {
            return column == 0; // Solo el checkbox es editable
        }
    };

    for (Usuario u : estudiantes) {
        modelo.addRow(new Object[]{false, u.getCi(), u.getNombre(), u.getApellido()});
    }

    TablaEstudiantes.setModel(modelo);

    // Ajustes de estilo
    TablaEstudiantes.getColumnModel().getColumn(0).setMaxWidth(100);
}

 public List<Usuario> getEstudiantesMarcados(){
     return estSeleccionados;
 }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BotonSeleccionarEst;
    private javax.swing.JButton BotonTodos;
    private javax.swing.JTable TablaEstudiantes;
    private javax.swing.JScrollPane jScrollPaneTabla;
    // End of variables declaration//GEN-END:variables
}
