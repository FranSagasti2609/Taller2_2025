package com.mycompany.doctecnica.Model;
import java.util.List;

public class Pregunta {
    private int id_Pregunta;
    private String enunciado;
    private Nivel nivel;
    private TipoPregunta tipo;
    private List<Respuesta> opcionesRespuesta;
    private String tema;

    //métricas de trazabilidad
    private int cantApariciones;
    private int cantRespuestasCorrectas;
    
    public Pregunta(){} //Constructor default
    
    public Pregunta(int id, String enun, Nivel niv, TipoPregunta typePreg, List<Respuesta> opciones, String tema){
        this.id_Pregunta = id;
        this.enunciado = enun;
        this.nivel = niv;
        this.tipo = typePreg;
        this.opcionesRespuesta = opciones;
        this.tema = tema;
    }
    
    public Pregunta(int id, String enun){
        this.id_Pregunta=id;
        this.enunciado = enun;
    }
    
     public int getId_Pregunta() {
        return id_Pregunta;
    }

    public void setId_Pregunta(int id_Pregunta) {
        this.id_Pregunta = id_Pregunta;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public void setEnunciado(String enunciado) {
        this.enunciado = enunciado;
    }

    public Nivel getNivel() {
        return nivel;
    }

    public void setNivel(Nivel nivel) {
        this.nivel = nivel;
    }

    public TipoPregunta getTipo() {
        return tipo;
    }

    public void setTipo(TipoPregunta tipo) {
        this.tipo = tipo;
    }
   
    public List<Respuesta> getOpcionesRespuesta() {
        return opcionesRespuesta;
    }

    public void setOpcionesRespuesta(List<Respuesta> opcionesRespuesta) {
        this.opcionesRespuesta = opcionesRespuesta;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }
    
       public int getCantApariciones() {
        return cantApariciones;
    }

    public void setCantApariciones(int cantApariciones) {
        this.cantApariciones = cantApariciones;
    }

    public int getCantRespuestasCorrectas() {
        return cantRespuestasCorrectas;
    }

    public void setCantRespuestasCorrectas(int cantRespuestasCorrectas) {
        this.cantRespuestasCorrectas = cantRespuestasCorrectas;
    }
    
    public Respuesta respuestaCorrecta() {
    for (Respuesta elem : this.opcionesRespuesta) {
        if (elem.esCorrecta()) {
            return elem;
        }
    }
    return null; // si no encuentra ninguna correcta
    }
   
    // Método calculado para el porcentaje
    public double getPorcentajeAciertos() {
        if (cantApariciones == 0) return 0.0;
        return (cantRespuestasCorrectas * 100.0) / cantApariciones;
    }

}
