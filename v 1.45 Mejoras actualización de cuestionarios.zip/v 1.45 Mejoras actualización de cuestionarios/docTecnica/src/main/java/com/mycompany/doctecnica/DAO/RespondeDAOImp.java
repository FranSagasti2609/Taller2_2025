package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Responde;
import java.sql.SQLException;
import java.sql.ResultSet;

public class RespondeDAOImp extends Conexion{
    
    public boolean guardarRespuesta(Responde res){
   
        String sql = "INSERT INTO responde (id_pregunta, ci_usuario, es_correcta) VALUES (?, ?,?)";
        
       try{
           conectar();
           ejecutarSentencia(sql, res.getIdPregunta(), res.getCiUsuario(), res.getEsCorrecta());
           return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
    
    public boolean cambiarEstado(int ci, int id_cuestionario){
       String sql = "UPDATE realiza SET estado = 'FINALIZADO' WHERE ci_usuario = ? and id_cuestionario = ?";
       
       try{
           conectar();
          ejecutarSentencia(sql, ci, id_cuestionario);
          return true;
       }catch(SQLException e){
           e.printStackTrace();
           return false;
        } finally {
            desconectar();
        }
   };
   
   public boolean restarIntento(int ci, int id_cuestionario){
       String sql = "UPDATE realiza SET cant_intentos = cant_intentos -1 WHERE ci_usuario = ? and id_cuestionario = ? AND cant_intentos >0 ";
       
       try{
         conectar();
          ejecutarSentencia(sql, ci, id_cuestionario);
          return true;
       }catch(SQLException e){
           e.printStackTrace();
           return false;
        } finally {
            desconectar();
        }
   }
   
   public int obtenerIntentosDisponibles(int ci, int id_cuestionario){
       int cant_intentos = 0;
       String sql = "SELECT cant_intentos FROM realiza WHERE ci_usuario = ? and id_cuestionario = ?";
       
       try{
           conectar();
           ResultSet rs = ejecutarConsulta(sql, ci, id_cuestionario);
          if (rs.next()) {
            cant_intentos = rs.getInt("cant_intentos");
        }
       }catch(SQLException e){
           e.printStackTrace();
        } finally {
            desconectar();
        }
       return cant_intentos;
   }
   
   public void agregarIntentosNuevos(int id_cuestionario, int diferencia){
       String sql = "UPDATE realiza set cant_intentos = cant_intentos + ? WHERE id_cuestionario = ?";
       
           try{
           conectar();
           ejecutarSentencia(sql, diferencia, id_cuestionario);
       }catch(SQLException e){
           e.printStackTrace();
        } finally {
            desconectar();
        }
           
   }
  }
