package com.mycompany.doctecnica.UI;

import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.ArrayList;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Controlador.ControladorPreguntasRespuestas;

public class SeleccionPreguntas extends javax.swing.JDialog {

        ControladorPreguntasRespuestas controlador = new  ControladorPreguntasRespuestas();
        private List<Pregunta> preguntasSeleccionadas = new ArrayList<>();
        
    public SeleccionPreguntas(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        
        initComponents();
        
        //defino forma de la tabla
        DefaultTableModel model = new DefaultTableModel(new Object[]{"Seleccionar", "ID", "Enunciado", "Tema", "Dificultad"}, 0) {
    @Override
        public Class<?> getColumnClass(int columnIndex) {
        return columnIndex == 0 ? Boolean.class : super.getColumnClass(columnIndex);}
       
    @Override
    public boolean isCellEditable(int row, int column) {
        return column == 0;
    }
};
    TablaPreguntas.setModel(model);
    configurarTablaPreguntas();
    cargarTodasLasPreguntas();
    }

   
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelScroll = new javax.swing.JScrollPane();
        TablaPreguntas = new javax.swing.JTable();
        LabelPrincipal = new javax.swing.JLabel();
        SeleccionarBoton = new javax.swing.JButton();

        setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                closeDialog(evt);
            }
        });
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        PanelScroll.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N

        TablaPreguntas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Seleccionar", "Enunciado", "Tema", "Dificultad"
            }
        ));
        PanelScroll.setViewportView(TablaPreguntas);

        add(PanelScroll, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 670, 400));

        LabelPrincipal.setFont(new java.awt.Font("Dubai", 1, 18)); // NOI18N
        LabelPrincipal.setText("Selecciona las preguntas para tu cuestionario");
        add(LabelPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 10, -1, -1));

        SeleccionarBoton.setBackground(new java.awt.Color(153, 255, 153));
        SeleccionarBoton.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        SeleccionarBoton.setText("Seleccionar");
        SeleccionarBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SeleccionarBotonActionPerformed(evt);
            }
        });
        add(SeleccionarBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 460, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    private void closeDialog(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_closeDialog
        setVisible(false);
        dispose();
    }//GEN-LAST:event_closeDialog

    private void SeleccionarBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SeleccionarBotonActionPerformed
        // TODO add your handling code here:
    preguntasSeleccionadas = new ArrayList<>();
    DefaultTableModel model = (DefaultTableModel) TablaPreguntas.getModel();
    
    for (int i = 0; i < model.getRowCount(); i++) {
        Boolean isSelected = (Boolean) model.getValueAt(i, 0);
        if (isSelected) {
            int idPregunta = (Integer) model.getValueAt(i, 1);
            // Recupera el objeto Pregunta completo (puedes hacerlo con tu DAO)
            Pregunta preguntaCompleta = controlador.recuperarPreguntaPorId(idPregunta);
            preguntasSeleccionadas.add(preguntaCompleta);
        }
    }
    this.dispose(); // Cierra el JDialog
    }//GEN-LAST:event_SeleccionarBotonActionPerformed
    
    // Método público para obtener las preguntas seleccionadas
    public List<Pregunta> getPreguntasSeleccionadas() {
        return preguntasSeleccionadas;
    }
    
    private void configurarTablaPreguntas() {
        // Ocultar la columna de la ID (columna 1, ya que el índice es 0)
        TablaPreguntas.getColumnModel().getColumn(1).setMinWidth(0);
        TablaPreguntas.getColumnModel().getColumn(1).setMaxWidth(0);
        TablaPreguntas.getColumnModel().getColumn(1).setWidth(0);
        
        // Habilitar el ordenamiento de filas al hacer clic en el encabezado
        TablaPreguntas.setAutoCreateRowSorter(true);
    }
    
    
    private void cargarTodasLasPreguntas() {
        List<Pregunta> todasLasPreguntas = controlador.recuperarTodasPreguntas();
        
        DefaultTableModel model = (DefaultTableModel) TablaPreguntas.getModel();
        model.setRowCount(0); // Limpiar filas anteriores
        
        for (Pregunta p : todasLasPreguntas) {
            model.addRow(new Object[]{false, p.getId_Pregunta(), p.getEnunciado(), p.getTema(), p.getNivel().toString()});
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelPrincipal;
    private javax.swing.JScrollPane PanelScroll;
    private javax.swing.JButton SeleccionarBoton;
    private javax.swing.JTable TablaPreguntas;
    // End of variables declaration//GEN-END:variables
}
