package com.mycompany.doctecnica;

import com.mycompany.doctecnica.Controlador.ControladorVisual;

public class DocTecnica {
        public static void main(String[] args) {
        
            ControladorVisual inicio = new ControladorVisual();
            inicio.iniciarAplicacion();

}
}
