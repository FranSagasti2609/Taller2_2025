package com.mycompany.doctecnica.Model;

public enum TipoPregunta {
    MULTIPLE_OPCION,
    VERDADERO_O_FALSO;

    // Método estático para obtener el enum a partir de un String
    public static TipoPregunta fromString(String tipo) {
        if (tipo == null || tipo.trim().isEmpty()) {
            throw new IllegalArgumentException("El tipo de pregunta no puede ser nulo o vacío.");
        }
        
        String tipoEnum = tipo.trim().toUpperCase().replace(" ", "_");
        
        try {
            // Utilizamos valueOf para convertir el String en el enum.
            return TipoPregunta.valueOf(tipoEnum);
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Valor inválido para TipoPregunta: " + tipo, e);
        }
    }
}