package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Responde;
import com.mycompany.doctecnica.Model.Cuestionario;

import java.util.List;

public interface RespondeDAO {
    public boolean guardarRespuesta(Responde res);
    public boolean borrarRespuestas(int ci, int id_cuestionario); //esto sirve para cuando se vuelven a hacer cuestionario
    public boolean cambiarEstado(int ci, int id_cuestionario);
    public boolean restarIntento(int ci, int id_cuestionario);
    public int obtenerIntentosDisponibles(int ci, int id_cuestionario);
    public void agregarIntentosNuevos(int id_cuestionario, int diferencia);
    public List<Integer> obtenerFinalizados(int ci);
    public int contarPreguntasCorrectas(int ci, int id_cuestionario);
}
