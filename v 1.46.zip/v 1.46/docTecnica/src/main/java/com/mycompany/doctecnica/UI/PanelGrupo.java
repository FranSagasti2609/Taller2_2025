package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Model.Grupo;
import com.mycompany.doctecnica.DAO.GrupoDAOImp;
import com.mycompany.doctecnica.DAO.GrupoDAO;
import java.awt.Color;
import com.mycompany.doctecnica.Controlador.ControladorPrincipal;

import javax.swing.ImageIcon;
import java.awt.Image;
import javax.swing.*;
import java.util.List;

public class PanelGrupo extends javax.swing.JPanel {
   Escalar escalar = new Escalar();
   private Usuario user;
   ControladorPrincipal controlador = new ControladorPrincipal();
   
    public PanelGrupo(Usuario usuario) {
    this.user = usuario;
    initComponents();
    //Seteo iconos
    ImageIcon icon = new ImageIcon(getClass().getResource("/imagenes/grupo.png"));
    Image img = icon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
    // Layout vertical para mostrar botones en el scroll
    PanelScroll.setLayout(new BoxLayout(PanelScroll, BoxLayout.Y_AXIS));
    // Mostrar los grupos desde el inicio
    mostrarGruposDelDocente();
}


       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        CrearGrupoLabel = new javax.swing.JLabel();
        NombreGrupoLabel = new javax.swing.JLabel();
        NombreGrupoTextField = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        CrearBoton = new javax.swing.JButton();
        CrearGrupoLabel1 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        PanelScrollGrupos = new javax.swing.JScrollPane();
        PanelScroll = new javax.swing.JPanel();
        GrupoIcono = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        CrearGrupoLabel.setFont(new java.awt.Font("Dubai", 1, 18)); // NOI18N
        CrearGrupoLabel.setText("Creación de grupo");
        add(CrearGrupoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(267, 38, -1, -1));

        NombreGrupoLabel.setFont(new java.awt.Font("Dubai Light", 0, 14)); // NOI18N
        NombreGrupoLabel.setText("Nombre");
        add(NombreGrupoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(313, 76, -1, -1));

        NombreGrupoTextField.setBorder(null);
        add(NombreGrupoTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(251, 118, 177, -1));
        add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(251, 140, 177, 10));

        CrearBoton.setBackground(new java.awt.Color(51, 204, 0));
        CrearBoton.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        CrearBoton.setForeground(new java.awt.Color(255, 255, 255));
        CrearBoton.setText("Crear");
        CrearBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CrearBotonActionPerformed(evt);
            }
        });
        add(CrearBoton, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 160, -1, -1));

        CrearGrupoLabel1.setFont(new java.awt.Font("Dubai", 1, 18)); // NOI18N
        CrearGrupoLabel1.setText("Grupos del docente");
        add(CrearGrupoLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(265, 221, -1, -1));
        add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 205, 670, 10));

        PanelScrollGrupos.setBorder(null);

        PanelScroll.setBackground(new java.awt.Color(255, 255, 255));
        PanelScroll.setLayout(new javax.swing.BoxLayout(PanelScroll, javax.swing.BoxLayout.LINE_AXIS));
        PanelScrollGrupos.setViewportView(PanelScroll);

        add(PanelScrollGrupos, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 259, 664, 242));

        GrupoIcono.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/grupo50x50.png"))); // NOI18N
        add(GrupoIcono, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 30, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void CrearBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CrearBotonActionPerformed
        // TODO add your handling code here:
     String nombreGrupo = NombreGrupoTextField.getText().trim();

    if (nombreGrupo.isEmpty()) {
        JOptionPane.showMessageDialog(this, "El nombre del grupo no puede estar vacío");
        return;
    }

    int id = (int) (System.currentTimeMillis() % Integer.MAX_VALUE);
    Grupo nuevo = new Grupo(id, nombreGrupo, user.getCi());
    controlador.agregarGrupo(nuevo);

    NombreGrupoTextField.setText("");
    mostrarGruposDelDocente();
        
    }//GEN-LAST:event_CrearBotonActionPerformed

 private void mostrarGruposDelDocente() {
    PanelScroll.removeAll(); // limpia el panel

    //Traigo los grupos del docente.
    List<Grupo> grupos = controlador.obtenerGrupoPorCI(user.getCi());

    if (grupos.isEmpty()) {
        JLabel lbl = new JLabel("No tienes grupos creados.");
        lbl.setAlignmentX(CENTER_ALIGNMENT);
        PanelScroll.add(lbl);
    } else {
        for (Grupo g : grupos) {
            JButton btn = new JButton(g.getNombre());
            btn.setAlignmentX(CENTER_ALIGNMENT); // para centrarlo en BoxLayout
            btn.addActionListener(e -> abrirVentanaEstudiantes(g));
            //Personalizamos colores del boton
            btn.setForeground(Color.WHITE);
            btn.setBackground(new Color(51, 204, 0));
            
            PanelScroll.add(btn);
            PanelScroll.add(Box.createVerticalStrut(5)); // espacio entre botones
        }
    }

    PanelScroll.revalidate();
    PanelScroll.repaint();
}

    
    private void abrirVentanaEstudiantes(Grupo grupo) {
    JFrame ventana = new JFrame("Estudiantes del grupo: " + grupo.getNombre());
    ventana.setSize(670, 500);
    ventana.setLocationRelativeTo(this);
    ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    ventana.setResizable(false);
    ventana.setIconImage(new ImageIcon(getClass().getResource("/imagenes/logo.png")).getImage());
    // Usamos el panel con la tabla
    PanelEstudianteDeUnGrupo panel = new PanelEstudianteDeUnGrupo(grupo);
    ventana.add(panel);

    ventana.setVisible(true);
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CrearBoton;
    private javax.swing.JLabel CrearGrupoLabel;
    private javax.swing.JLabel CrearGrupoLabel1;
    private javax.swing.JLabel GrupoIcono;
    private javax.swing.JLabel NombreGrupoLabel;
    private javax.swing.JTextField NombreGrupoTextField;
    private javax.swing.JPanel PanelScroll;
    private javax.swing.JScrollPane PanelScrollGrupos;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    // End of variables declaration//GEN-END:variables
}
