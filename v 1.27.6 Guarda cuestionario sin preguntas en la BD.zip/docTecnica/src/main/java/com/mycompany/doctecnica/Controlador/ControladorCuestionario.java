package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.DAO.CuestionarioDAOImp;
import com.mycompany.doctecnica.Model.Cuestionario;

public class ControladorCuestionario {
    
    CuestionarioDAOImp dao = new CuestionarioDAOImp();
    
    //Metodo para guardar cuestionario en la base de datos.
    public boolean guardarCuestionario(Cuestionario c){
        return dao.insertar(c);
    }
}
