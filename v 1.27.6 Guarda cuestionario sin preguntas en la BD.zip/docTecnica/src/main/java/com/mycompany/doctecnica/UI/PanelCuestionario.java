package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Controlador.ControladorPreguntasRespuestas;
import com.mycompany.doctecnica.Controlador.ControladorCuestionario;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.*;
import com.mycompany.doctecnica.Model.Pregunta;
import javax.swing.JFrame;

public class PanelCuestionario extends javax.swing.JPanel {

    Escalar escalo = new Escalar();
    Usuario usuario;
    ControladorPreguntasRespuestas controlador = new ControladorPreguntasRespuestas();
    ControladorCuestionario controladorCues = new ControladorCuestionario();
    private JFrame parentFrame;
    Cuestionario cuestionario = new Cuestionario(); //creamos cuestionario (objeto)
    List<Pregunta> preguntasSeleccionadas = new ArrayList<>();
    
    public PanelCuestionario(Usuario user, JFrame parentFrame) {
        initComponents();
        this.usuario = user;
        this.parentFrame = parentFrame;
        escalo.escalarLabel(BackGroundGreen, "imagenes/greenBack.jpg");
        cargarTemasEnCombo(); //agrego temas al comboBOx
        
        
        //Si se selecciona modalidad random aparece el spiner para setear la cantidad de preguntas
    ModalidadComboBox.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        String modalidad = (String) ModalidadComboBox.getSelectedItem();

        if ("Aleatorio".equals(modalidad)) {
            PreguntasLabel.setVisible(true);
            SpinnerPreguntas.setVisible(true);
        } else {
            PreguntasLabel.setVisible(false);
            SpinnerPreguntas.setVisible(false);
        }
        
         if ("Estatico".equals(modalidad)) {
            SeleccionPreguntas dialog = new SeleccionPreguntas(parentFrame, true);
            dialog.setVisible(true);
             preguntasSeleccionadas = dialog.getPreguntasSeleccionadas();
             if (preguntasSeleccionadas == null || preguntasSeleccionadas.isEmpty()) {

            JOptionPane.showMessageDialog(parentFrame, "Debe seleccionar al menos una pregunta.");
            return;
            }else{
                 JOptionPane.showMessageDialog(parentFrame, "Has seleccionado correctamente " + preguntasSeleccionadas.size() + " preguntas.");
             }
         cuestionario.setPreguntas(preguntasSeleccionadas);
        } 
    }
});
    }

       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        BackGroundGreen = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        LabelPrincipal = new javax.swing.JLabel();
        TabbedPane = new javax.swing.JTabbedPane();
        CrearCuestionarioPanel = new javax.swing.JPanel();
        PanelCrearScroll = new javax.swing.JScrollPane();
        PanelCrearCuestionario = new javax.swing.JPanel();
        TituloField = new javax.swing.JTextField();
        TituloLabel1 = new javax.swing.JLabel();
        TemaComboBox = new javax.swing.JComboBox<>();
        RetroalimentacionLabel = new javax.swing.JLabel();
        TemaLabel = new javax.swing.JLabel();
        SpinnerPreguntas = new javax.swing.JSpinner();
        IntentosLabel1 = new javax.swing.JLabel();
        RetroalimentacionComboBox = new javax.swing.JComboBox<>();
        PreguntasLabel = new javax.swing.JLabel();
        ModalidadComboBox = new javax.swing.JComboBox<>();
        BotonCrearCuestionario = new javax.swing.JButton();
        SpinnerIntentos = new javax.swing.JSpinner();
        ModalidadLabel2 = new javax.swing.JLabel();
        ModificarPanel = new javax.swing.JPanel();
        ModBoton = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        BorrarCuestionario = new javax.swing.JPanel();
        BorrarBoton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        BackGround = new javax.swing.JLabel();

        jLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        jLabel1.setText("Listado de estudiantes del sistema");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Titulo", "Tema", "Tipo"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LabelPrincipal.setFont(new java.awt.Font("Dubai", 1, 18)); // NOI18N
        LabelPrincipal.setText("Apartado de cuestionarios");
        add(LabelPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, -1, -1));

        TabbedPane.setBackground(new java.awt.Color(153, 255, 153));
        TabbedPane.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        TabbedPane.setOpaque(true);

        PanelCrearScroll.setBackground(new java.awt.Color(255, 255, 255));

        PanelCrearCuestionario.setBackground(new java.awt.Color(255, 255, 255));
        PanelCrearCuestionario.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TituloField.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        TituloField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PanelCrearCuestionario.add(TituloField, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 50, 514, -1));

        TituloLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        TituloLabel1.setText("Titulo");
        PanelCrearCuestionario.add(TituloLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, -1, -1));

        TemaComboBox.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        PanelCrearCuestionario.add(TemaComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, -1, -1));

        RetroalimentacionLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        RetroalimentacionLabel.setText("Retroalimentacion");
        PanelCrearCuestionario.add(RetroalimentacionLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, -1, -1));

        TemaLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        TemaLabel.setText("Tema");
        PanelCrearCuestionario.add(TemaLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, -1));

        SpinnerPreguntas.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        SpinnerPreguntas.setModel(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));
        SpinnerPreguntas.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        SpinnerPreguntas.setValue(1);
        PanelCrearCuestionario.add(SpinnerPreguntas, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 180, 130, -1));
        SpinnerPreguntas.setVisible(false);

        IntentosLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        IntentosLabel1.setText("Cantidad de intentos");
        PanelCrearCuestionario.add(IntentosLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        RetroalimentacionComboBox.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        RetroalimentacionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Calificacion numerica", "Detallada" }));
        PanelCrearCuestionario.add(RetroalimentacionComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, -1, -1));

        PreguntasLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        PreguntasLabel.setText("Cantidad preguntas");
        PanelCrearCuestionario.add(PreguntasLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 180, -1, -1));
        PreguntasLabel.setVisible(false);

        ModalidadComboBox.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        ModalidadComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estatico", "Aleatorio", "Adaptativo" }));
        PanelCrearCuestionario.add(ModalidadComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, -1, -1));

        BotonCrearCuestionario.setBackground(new java.awt.Color(153, 255, 153));
        BotonCrearCuestionario.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        BotonCrearCuestionario.setText("Crear");
        BotonCrearCuestionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCrearCuestionarioActionPerformed(evt);
            }
        });
        PanelCrearCuestionario.add(BotonCrearCuestionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 300, -1, -1));

        SpinnerIntentos.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        SpinnerIntentos.setModel(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));
        SpinnerIntentos.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        SpinnerIntentos.setValue(1);
        PanelCrearCuestionario.add(SpinnerIntentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 130, 130, -1));

        ModalidadLabel2.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        ModalidadLabel2.setText("Modalidad");
        PanelCrearCuestionario.add(ModalidadLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, -1, -1));

        PanelCrearScroll.setViewportView(PanelCrearCuestionario);

        javax.swing.GroupLayout CrearCuestionarioPanelLayout = new javax.swing.GroupLayout(CrearCuestionarioPanel);
        CrearCuestionarioPanel.setLayout(CrearCuestionarioPanelLayout);
        CrearCuestionarioPanelLayout.setHorizontalGroup(
            CrearCuestionarioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelCrearScroll, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
        );
        CrearCuestionarioPanelLayout.setVerticalGroup(
            CrearCuestionarioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CrearCuestionarioPanelLayout.createSequentialGroup()
                .addComponent(PanelCrearScroll, javax.swing.GroupLayout.PREFERRED_SIZE, 406, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        TabbedPane.addTab("Crear", CrearCuestionarioPanel);

        ModificarPanel.setBackground(new java.awt.Color(255, 255, 255));

        ModBoton.setBackground(new java.awt.Color(51, 204, 0));
        ModBoton.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        ModBoton.setForeground(new java.awt.Color(255, 255, 255));
        ModBoton.setText("Modificar");
        ModBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModBotonActionPerformed(evt);
            }
        });

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Titulo", "Tema", "Tipo"
            }
        ));
        jScrollPane3.setViewportView(jTable3);

        javax.swing.GroupLayout ModificarPanelLayout = new javax.swing.GroupLayout(ModificarPanel);
        ModificarPanel.setLayout(ModificarPanelLayout);
        ModificarPanelLayout.setHorizontalGroup(
            ModificarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ModificarPanelLayout.createSequentialGroup()
                .addGap(294, 294, 294)
                .addComponent(ModBoton)
                .addContainerGap(299, Short.MAX_VALUE))
            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        ModificarPanelLayout.setVerticalGroup(
            ModificarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ModificarPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ModBoton)
                .addContainerGap())
        );

        TabbedPane.addTab("Modificar", ModificarPanel);

        BorrarCuestionario.setBackground(new java.awt.Color(255, 255, 255));

        BorrarBoton.setBackground(new java.awt.Color(255, 102, 102));
        BorrarBoton.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        BorrarBoton.setText("Borrar");
        BorrarBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrarBotonActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Titulo", "Tema", "Tipo"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout BorrarCuestionarioLayout = new javax.swing.GroupLayout(BorrarCuestionario);
        BorrarCuestionario.setLayout(BorrarCuestionarioLayout);
        BorrarCuestionarioLayout.setHorizontalGroup(
            BorrarCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BorrarCuestionarioLayout.createSequentialGroup()
                .addGap(294, 294, 294)
                .addComponent(BorrarBoton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
        );
        BorrarCuestionarioLayout.setVerticalGroup(
            BorrarCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BorrarCuestionarioLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 363, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BorrarBoton)
                .addContainerGap())
        );

        TabbedPane.addTab("Borrar", BorrarCuestionario);

        add(TabbedPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 670, 440));
        add(BackGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 70));
    }// </editor-fold>//GEN-END:initComponents

    private void BorrarBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrarBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BorrarBotonActionPerformed

    private void ModBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModBotonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ModBotonActionPerformed

    private void BotonCrearCuestionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCrearCuestionarioActionPerformed
        // TODO add your handling code here:
        String tituloCuestionario = TituloField.getText().trim();
        if (tituloCuestionario.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El título es obligatorio.");
            return;
         }
        
        cuestionario.setTitulo(tituloCuestionario);
        cuestionario.setModalidad(ModalidadComboBox.getSelectedItem().toString());
        cuestionario.setCiUsuario(usuario.getCi());
        cuestionario.setRetroalimentacion(RetroalimentacionComboBox.getSelectedItem().toString());
        cuestionario.setCantIntentos((int)SpinnerIntentos.getValue());
        // Asignar el valor de la cantidad de preguntas aleatorias
        if ("Aleatorio".equals(ModalidadComboBox.getSelectedItem().toString())) {
        cuestionario.setCantidadPreguntasAleatorias((int) SpinnerPreguntas.getValue());
        } else {
        cuestionario.setCantidadPreguntasAleatorias(0);}
        
        if("Estatico".equals(ModalidadComboBox.getSelectedItem().toString())){
            if (cuestionario.getPreguntas() == null || cuestionario.getPreguntas().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar al menos una pregunta para un cuestionario estático.");
            return;
    }
            cuestionario.setPreguntas(preguntasSeleccionadas);
        }
        
    //agrego cuestionario a la base
    boolean creado = controladorCues.guardarCuestionario(cuestionario);
    if (creado) {
        JOptionPane.showMessageDialog(this, "Cuestionario creado con éxito.");
        limpiarFormulario(); //luego de insertar un cuestionario dejamos todo limpio para poder volver a hacerlo con uno nuevo
    } else {
        JOptionPane.showMessageDialog(this, "No se pudo crear el cuestionario.");
    } 

    }//GEN-LAST:event_BotonCrearCuestionarioActionPerformed

    
    private void cargarTemasEnCombo() {
    List<String> temas = controlador.recuperarTemas();
   TemaComboBox.removeAllItems(); // limpia el combo

    if (temas.isEmpty()) {TemaComboBox.addItem("No hay temas");} 
        else {
        for (String t : temas) { //para cada tema de la lista lo agrego a la comboBOX
           TemaComboBox.addItem(t);
        }
    }
    // Opción especial para agregar nuevos temas
   TemaComboBox.addItem("<<Agregar nuevo tema>>");
    // Listener para detectar si el usuario quiere crear uno nuevo
   TemaComboBox.addActionListener(e -> {
        if ("<<Agregar nuevo tema>>".equals(TemaComboBox.getSelectedItem())) {
           String nuevoTema = JOptionPane.showInputDialog(this, "Ingrese el nuevo tema:");
            if (nuevoTema != null && !nuevoTema.trim().isEmpty()) {//garantizamos que haya un tema
               TemaComboBox.insertItemAt(nuevoTema, 0);
               TemaComboBox.setSelectedItem(nuevoTema);
            } else {
               TemaComboBox.setSelectedIndex(0); // vuelve al primero
            }
        }
        }
    );
}
    
    private void limpiarFormulario() {
    // Vaciar el campo de título
    TituloField.setText("");

    // Resetear combo de tema al primer ítem
    if (TemaComboBox.getItemCount() > 0) {
        TemaComboBox.setSelectedIndex(0);
    }

    // Resetear combo de retroalimentación al primero
    if (RetroalimentacionComboBox.getItemCount() > 0) {
        RetroalimentacionComboBox.setSelectedIndex(0);
    }

    // Reiniciar cantidad de intentos a 1
    SpinnerIntentos.setValue(1);

    // Reiniciar cantidad de preguntas aleatorias a 1 y ocultar spinner
    SpinnerPreguntas.setValue(1);
    SpinnerPreguntas.setVisible(false);
    PreguntasLabel.setVisible(false);
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BackGround;
    private javax.swing.JLabel BackGroundGreen;
    private javax.swing.JButton BorrarBoton;
    private javax.swing.JPanel BorrarCuestionario;
    private javax.swing.JButton BotonCrearCuestionario;
    private javax.swing.JPanel CrearCuestionarioPanel;
    private javax.swing.JLabel IntentosLabel1;
    private javax.swing.JLabel LabelPrincipal;
    private javax.swing.JButton ModBoton;
    private javax.swing.JComboBox<String> ModalidadComboBox;
    private javax.swing.JLabel ModalidadLabel2;
    private javax.swing.JPanel ModificarPanel;
    private javax.swing.JPanel PanelCrearCuestionario;
    private javax.swing.JScrollPane PanelCrearScroll;
    private javax.swing.JLabel PreguntasLabel;
    private javax.swing.JComboBox<String> RetroalimentacionComboBox;
    private javax.swing.JLabel RetroalimentacionLabel;
    private javax.swing.JSpinner SpinnerIntentos;
    private javax.swing.JSpinner SpinnerPreguntas;
    private javax.swing.JTabbedPane TabbedPane;
    private javax.swing.JComboBox<String> TemaComboBox;
    private javax.swing.JLabel TemaLabel;
    private javax.swing.JTextField TituloField;
    private javax.swing.JLabel TituloLabel1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    // End of variables declaration//GEN-END:variables
}
