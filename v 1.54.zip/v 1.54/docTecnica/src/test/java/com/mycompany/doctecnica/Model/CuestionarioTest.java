package com.mycompany.doctecnica.Model;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

public class CuestionarioTest {
    
    @Test
    public void testSetAndGetId_Cuestionario() {
        Cuestionario c = new Cuestionario();
        c.setId_Cuestionario(5);
        assertEquals(5, c.getId_Cuestionario());
    }

    @Test
    public void testSetAndGetTitulo() {
        Cuestionario c = new Cuestionario();
        c.setTitulo("Cuestionario de Redes");
        assertEquals("Cuestionario de Redes", c.getTitulo());
    }

    @Test
    public void testSetAndGetModalidad() {
        Cuestionario c = new Cuestionario();
        c.setModalidad("online");
        assertEquals("online", c.getModalidad());
    }

    @Test
    public void testSetAndGetRetroalimentacion() {
        Cuestionario c = new Cuestionario();
        c.setRetroalimentacion("Buen trabajo");
        assertEquals("Buen trabajo", c.getRetroalimentacion());
    }

    @Test
    public void testSetAndGetCiUsuario() {
        Cuestionario c = new Cuestionario();
        c.setCiUsuario(123456);
        assertEquals(123456, c.getCiUsuario());
    }

    @Test
    public void testSetAndGetCantIntentos() {
        Cuestionario c = new Cuestionario();
        c.setCantIntentos(3);
        assertEquals(3, c.getCantIntentos());
    }

    @Test
    public void testSetAndGetCantidadPreguntasAleatorias() {
        Cuestionario c = new Cuestionario();
        c.setCantidadPreguntasAleatorias(10);
        assertEquals(10, c.getCantidadPreguntasAleatorias());
    }

    @Test
    public void testSetAndGetTemaFiltro() {
        Cuestionario c = new Cuestionario();
        c.setTemaFiltro("Ciberseguridad");
        assertEquals("Ciberseguridad", c.getTemaFiltro());
    }

    @Test
    public void testSetAndGetPreguntas() {
        Cuestionario c = new Cuestionario();
        List<Pregunta> lista = new ArrayList<>();
        lista.add(new Pregunta());
        c.setPreguntas(lista);
        assertEquals(lista, c.getPreguntas());
        assertEquals(1, c.getPreguntas().size());
    }
}
