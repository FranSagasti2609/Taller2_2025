package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Responde;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;

public class RespondeDAOImp extends Conexion{
    
    public boolean guardarRespuesta(Responde res){
   
        String sql = "INSERT INTO responde (id_pregunta, ci_usuario, es_correcta) VALUES (?, ?,?)";
        
       try{
           conectar();
           ejecutarSentencia(sql, res.getIdPregunta(), res.getCiUsuario(), res.getEsCorrecta());
           return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
    
    public boolean borrarRespuestasPrevias(int ciUsuario, int idCuestionario) {
    String sql = "DELETE FROM responde " +
                 "WHERE ci_usuario = ? " +
                 "AND id_pregunta IN (SELECT id_pregunta FROM asigna WHERE id_cuestionario = ?)";
    try {
        conectar();
        ejecutarSentencia(sql, ciUsuario, idCuestionario);
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        desconectar();
    }
}

    
    public boolean cambiarEstado(int ci, int id_cuestionario){
       String sql = "UPDATE realiza SET estado = 'FINALIZADO' WHERE ci_usuario = ? and id_cuestionario = ?";
       
       try{
           conectar();
          ejecutarSentencia(sql, ci, id_cuestionario);
          return true;
       }catch(SQLException e){
           e.printStackTrace();
           return false;
        } finally {
            desconectar();
        }
   };
   
   public boolean restarIntento(int ci, int id_cuestionario){
       String sql = "UPDATE realiza SET cant_intentos = cant_intentos -1 WHERE ci_usuario = ? and id_cuestionario = ? AND cant_intentos >0 ";
       
       try{
         conectar();
          ejecutarSentencia(sql, ci, id_cuestionario);
          return true;
       }catch(SQLException e){
           e.printStackTrace();
           return false;
        } finally {
            desconectar();
        }
   }
   
   public int obtenerIntentosDisponibles(int ci, int id_cuestionario){
       int cant_intentos = 0;
       String sql = "SELECT cant_intentos FROM realiza WHERE ci_usuario = ? and id_cuestionario = ?";
       
       try{
           conectar();
           ResultSet rs = ejecutarConsulta(sql, ci, id_cuestionario);
          if (rs.next()) {
            cant_intentos = rs.getInt("cant_intentos");
        }
       }catch(SQLException e){
           e.printStackTrace();
        } finally {
            desconectar();
        }
       return cant_intentos;
   }
   
   public void agregarIntentosNuevos(int id_cuestionario, int diferencia){
       String sql = "UPDATE realiza set cant_intentos = cant_intentos + ? WHERE id_cuestionario = ?";
       
           try{
           conectar();
           ejecutarSentencia(sql, diferencia, id_cuestionario);
       }catch(SQLException e){
           e.printStackTrace();
        } finally {
            desconectar();
        }
           
   }
   
   public List<Integer> obtenerFinalizados(int ci){
       List<Integer> cuestFinalizados = new ArrayList<>();
       String sql = "SELECT id_cuestionario FROM realiza WHERE ci_usuario = ? and estado = ? ";
       try{
           conectar();
           ResultSet rs = ejecutarConsulta(sql, ci, "FINALIZADO");
            while(rs.next()) {
                int id_cuest = rs.getInt("id_cuestionario");
                cuestFinalizados.add(id_cuest);
        }
            rs.close();
       }catch(SQLException e){
           e.printStackTrace();
           return new ArrayList<>(); 
        } finally {
            desconectar();
        }
       
       return cuestFinalizados;
   }
   
   public int contarPreguntasCorrectas(int ci, int id_cuestionario){
       String sql = "SELECT COUNT(*) FROM responde WHERE ci_usuario = ? AND es_correcta = 1 AND id_pregunta IN" +
                          "(SELECT id_pregunta FROM asigna WHERE id_cuestionario = ?)";
        int correctas =0; 
        
       try{
           conectar();
           ResultSet rs = ejecutarConsulta(sql,ci, id_cuestionario);
          if(rs.next()){
              correctas = rs.getInt(1);
          }
       }catch(SQLException e){
           e.printStackTrace();
        } finally {
            desconectar();
        }
       return correctas;
   }
   
   public List<Responde> obtenerRespuestasDeCuestionario(int ciUsuario, int idCuestionario) {
    List<Responde> lista = new ArrayList<>();
    String sql =
        "SELECT r.num_respuesta, r.id_pregunta, r.es_correcta " +
        "FROM responde r " +
        "JOIN asigna a ON r.id_pregunta = a.id_pregunta " +
        "WHERE r.ci_usuario = ? AND a.id_cuestionario = ?";

    try {
        conectar();
        ResultSet rs = ejecutarConsulta(sql, ciUsuario, idCuestionario);
        while (rs.next()) {
            Responde r = new Responde();
            r.setNumRespuesta(rs.getInt("num_respuesta"));
            r.setIdPregunta(rs.getInt("id_pregunta"));
            r.setCiUsuario(ciUsuario);
            r.setEsCorrecta(rs.getBoolean("es_correcta"));
            lista.add(r);
        }
        rs.close();
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return lista;
}

   
  }
