package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.Model.Nivel;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Responde;
import com.mycompany.doctecnica.Model.Respuesta;
import com.mycompany.doctecnica.Model.TipoPregunta;
import com.mycompany.doctecnica.UI.uc.IUcPregunta;
import com.mycompany.doctecnica.UI.uc.UcPreguntaCuestionario;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Controlador.ControladorRespuestas;
import com.mycompany.doctecnica.Controlador.ControladorPreguntasRespuestas;
import com.mycompany.doctecnica.Controlador.ControladorCuestionario;

import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import java.awt.Color;
import java.util.Map;

public class PanelRealizarCuestionario extends javax.swing.JPanel {

    private Cuestionario cuest;
    private Usuario user;
    private List<Pregunta> preguntas;    
    private ControladorRespuestas controlRes = new ControladorRespuestas();
    ControladorPreguntasRespuestas controlPreg = new ControladorPreguntasRespuestas();
    ControladorCuestionario controlCuest = new ControladorCuestionario();
    private final List<IUcPregunta> componentesPregunta = new ArrayList<>();
    private JPanel zonaTrabajo;
    private Map<Integer, List<Pregunta>> preguntasClasificadas; //para cuestionarios adaptativos.
    //Variables para cuestionarios adaptativos
    private int nivelActual= 0; //gestiona el nivel actual de dificultad. 0FACIL, 1Medio, 2dificil
    private boolean respuestasBorradas = false; //controla el borrado en los adaptativos, para no perder todas las preguntas.
    private boolean cuestionarioFinalizado = false; //para controlar el flujo de los adaptativos *en el panel dificil FINALIZAR correctamente *
    
    public PanelRealizarCuestionario(Usuario usuario, Cuestionario c,JPanel zonaTrab) {
        
        this.user = usuario;
        this.cuest = c;
        this.zonaTrabajo = zonaTrab;
        initComponents();
        
        preguntas = cuest.getPreguntas(); //cargo las preguntas del cuest
        preguntasClasificadas = controlCuest.obtenerPreguntasOrdenadas(cuest.getId_Cuestionario());
        
        if("Adaptativo".equals(cuest.getModalidad())){
            construirFormularioAdaptativo(0);
        }else{construirFormularioPreguntas();}
        
        
    }

    private void construirFormularioPreguntas() {
    panelContenedorPreguntas.removeAll();
    panelContenedorPreguntas.setBackground(Color.WHITE);

    for (Pregunta p : cuest.getPreguntas()) {
        // Usamos SIEMPRE el UC unificado
        UcPreguntaCuestionario uc = new UcPreguntaCuestionario(p);
        panelContenedorPreguntas.add(uc);
        componentesPregunta.add(uc);   // importante para luego obtener las respuestas
        panelContenedorPreguntas.add(Box.createVerticalStrut(10));
        controlPreg.aumentarCantApariciones(p.getId_Pregunta()); //aumento aparicion
    }

    panelContenedorPreguntas.revalidate();
    panelContenedorPreguntas.repaint();
}
    
    private void construirFormularioAdaptativo(int nivel) {
        this.nivelActual = nivel;
        
    List<Pregunta> preguntas = preguntasClasificadas.getOrDefault(this.nivelActual, new ArrayList<>());

    panelContenedorPreguntas.removeAll();
    panelContenedorPreguntas.setBackground(Color.WHITE);

    // Recorro nivelActuales hasta encontrar alguno con preguntas o terminar
    while (this.nivelActual <= 2 && preguntas.isEmpty()) {
             if (this.nivelActual < 2) {
                // Nivel vacío, pero no es el último: mostrar aviso y avanzar
                String nombreNivel = (this.nivelActual == 0) ? "Fácil" : "Medio";
                String siguienteNivel = (this.nivelActual == 0) ? "Medio" : "Difícil";
                JOptionPane.showMessageDialog(this, "No hay preguntas en el nivel " + nombreNivel + ", se pasa a " + siguienteNivel + ".","Aviso: Nivel vacío",JOptionPane.WARNING_MESSAGE );
                this.nivelActual++; //aumento de nivel para pasar a medio o dificil respectivamente
                preguntas = preguntasClasificadas.getOrDefault(nivelActual, new ArrayList<>());
            } else {
                // Nivel difícil vacío terminar
                JOptionPane.showMessageDialog( this,  "No hay más preguntas disponibles en ningún nivel. Fin del cuestionario.", "Fin del Cuestionario",JOptionPane.INFORMATION_MESSAGE);
                return;
            }
    }

    // Si aún así no hay preguntas en ningún nivelActual, cortar acá
    if (preguntas.isEmpty()) {
        return;
    }

    // Mostrar título del nivelActual actual
    String titulo = (this.nivelActual == 0) ? "FÁCIL" : (this.nivelActual == 1) ? "MEDIO" : "DIFÍCIL";
    JLabel labelTitulo = new JLabel("--- Nivel Actual: " + titulo + " ---");
    labelTitulo.setAlignmentX(CENTER_ALIGNMENT);
    panelContenedorPreguntas.add(labelTitulo);
    panelContenedorPreguntas.add(Box.createVerticalStrut(10));

    // Mostrar preguntas
    for (Pregunta p : preguntas) {
        UcPreguntaCuestionario uc = new UcPreguntaCuestionario(p);
        panelContenedorPreguntas.add(uc);
        componentesPregunta.add(uc);
        panelContenedorPreguntas.add(Box.createVerticalStrut(10));

        controlPreg.aumentarCantApariciones(p.getId_Pregunta());
    }

    // Configurar botón
    btnFinalizar.setText((nivelActual == 2) ? "Finalizar Cuestionario" : "Pasar de Nivel");

    panelContenedorPreguntas.revalidate();
    panelContenedorPreguntas.repaint();
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scrollCuestionario = new javax.swing.JScrollPane();
        panelContenedorPreguntas = new javax.swing.JPanel();
        btnFinalizar = new javax.swing.JButton();

        scrollCuestionario.setBackground(new java.awt.Color(255, 255, 255));

        panelContenedorPreguntas.setLayout(new javax.swing.BoxLayout(panelContenedorPreguntas, javax.swing.BoxLayout.Y_AXIS));
        scrollCuestionario.setViewportView(panelContenedorPreguntas);

        btnFinalizar.setBackground(new java.awt.Color(51, 204, 0));
        btnFinalizar.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        btnFinalizar.setForeground(new java.awt.Color(255, 255, 255));
        btnFinalizar.setText("Finalizar");
        btnFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollCuestionario, javax.swing.GroupLayout.PREFERRED_SIZE, 671, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(277, 277, 277)
                .addComponent(btnFinalizar))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(scrollCuestionario, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFinalizar)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


//cuando pulso el boton de finalizar deben almacenarse las respuestas...
    private void btnFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalizarActionPerformed
        // TODO add your handling code here:                                           
    String modalidad = cuest.getModalidad();

      // Evitar doble ejecución de finalización
    if (cuestionarioFinalizado) {
        return;
    }

        controlRes.borrarRespuestas(user.getCi(), cuest.getId_Cuestionario());
    
    //Validar que todas las preguntas visibles tengan respuesta
    for (IUcPregunta com : componentesPregunta) {
        Respuesta respuestaElegida = com.getRespuesta();
        if (respuestaElegida == null) {
            JOptionPane.showMessageDialog(this, "Debes responder todas las preguntas antes de continuar.", "Pregunta sin responder",  JOptionPane.WARNING_MESSAGE);
            return;
        }
    }

    for (IUcPregunta com : componentesPregunta) {
        Respuesta respuestaElegida = com.getRespuesta();

        Responde res = new Responde(respuestaElegida.getIdPregunta(), user.getCi(),respuestaElegida.esCorrecta());
        controlRes.guardarRespuesta(res);

        if (respuestaElegida.esCorrecta()) {
            controlPreg.aumentarCantCorrectas(respuestaElegida.getIdPregunta());
        }
        // trazabilidad: aparición
        controlPreg.aumentarCantApariciones(respuestaElegida.getIdPregunta());
    }

    // Modalidad específica
    if ("Adaptativo".equalsIgnoreCase(modalidad)) {
        
        List<Respuesta> respuestasNivel = new ArrayList<>();
        for (IUcPregunta com : componentesPregunta) {
            Respuesta r = com.getRespuesta();
            respuestasNivel.add(r);
        }
        
        boolean pasaNivel = controlCuest.procesarNivel(user.getCi(), cuest, respuestasNivel,this.nivelActual);
        
        if (pasaNivel && this.nivelActual < 2) {
            // Pasa al siguiente nivelActual
            this.nivelActual++;
            JOptionPane.showMessageDialog(this, "¡Bien hecho! Pasas al siguiente nivel (" + (this.nivelActual == 1 ? "Medio" : "Difícil") + ").");
            construirFormularioAdaptativo(this.nivelActual);
            return; // No marcar finalizado todavía
        } else if (this.nivelActual< 2 && !pasaNivel) {
            // No pasó el filtro termina acá
            JOptionPane.showMessageDialog(this,"No alcanzaste el 50%. El cuestionario termina aquí.");        
        }
        cuestionarioFinalizado = true;
        // Caso adaptativo: termina (por no pasar o estar en el último nivelActual)
        controlRes.restarIntentosEstudiante(user.getCi(), cuest.getId_Cuestionario());
        controlRes.cambiarEstadoEstudiante(user.getCi(), cuest.getId_Cuestionario());

        JOptionPane.showMessageDialog(this, "Cuestionario finalizado. Puedes ver tu nota en devoluciones.");
    } else {
        // Estatico o Aleatorio, flujo normal
        controlRes.restarIntentosEstudiante(user.getCi(), cuest.getId_Cuestionario());
        controlRes.cambiarEstadoEstudiante(user.getCi(), cuest.getId_Cuestionario());

        JOptionPane.showMessageDialog(this, "Cuestionario finalizado. Puedes ver tu nota en devoluciones.");
    }

    // Volvemos al menú de cuestionarios
    PanelCuestionarioEstudiante panelCuest = new PanelCuestionarioEstudiante(user, zonaTrabajo);
    zonaTrabajo.removeAll();
    zonaTrabajo.add(panelCuest);
    zonaTrabajo.revalidate();
    zonaTrabajo.repaint();

    }//GEN-LAST:event_btnFinalizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFinalizar;
    private javax.swing.JPanel panelContenedorPreguntas;
    private javax.swing.JScrollPane scrollCuestionario;
    // End of variables declaration//GEN-END:variables
}
