package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.TipoPregunta;
import com.mycompany.doctecnica.Model.Nivel;
import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.DAO.RespondeDAOImp;
import com.mycompany.doctecnica.DAO.PreguntaDAOImp;


import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

public class CuestionarioDAOImp extends Conexion implements CuestionarioDAO{
        private RespondeDAOImp daoRes = new RespondeDAOImp();
        private PreguntaDAOImp daoPreg = new PreguntaDAOImp();
        
    @Override
public boolean insertar(Cuestionario c) {
    String sql = "INSERT INTO cuestionario " +
                 "(titulo, modalidad, ci_usuario, cant_intentos, cantidad_preguntas_aleatorias, retroalimentacion) " +
                 "VALUES (?, ?, ?, ?, ?, ?)";
    try {
        conectar();
        PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        stmt.setString(1, c.getTitulo());
        stmt.setString(2, c.getModalidad());
        stmt.setInt(3, c.getCiUsuario());
        stmt.setInt(4, c.getCantIntentos());
        stmt.setInt(5, c.getCantidadPreguntasAleatorias());
        stmt.setString(6, c.getRetroalimentacion());
        

        int filas = stmt.executeUpdate();
        if (filas > 0) {
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                c.setId_Cuestionario(rs.getInt(1));
            }

            // Insertar las preguntas asociadas (si vienen cargadas en el objeto)
            if (c.getPreguntas() != null) {
                for (Pregunta p : c.getPreguntas()) {
                    agregarPreguntaACuestionario(c.getId_Cuestionario(), p.getId_Pregunta());
                }
            }
            return true;
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return false;
}


       @Override
    public List<Cuestionario> obtenerTodos() {
        List<Cuestionario> lista = new ArrayList<>();
        String sql = "SELECT * FROM cuestionario";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql);
            while (rs.next()) {
                lista.add(mapearCuestionario(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }

    @Override
   public Cuestionario obtenerPorId(int id) {
        String sql = "SELECT * FROM cuestionario WHERE id_cuestionario=?";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql, id);
            if (rs.next()) {
                return mapearCuestionario(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return null;
    }

   @Override
public boolean actualizar(Cuestionario c) {
    
    //Antes de actualizar obtengo los intentos viejos.
    int intentosPrevios =0;
    String sql_Intentos = "SELECT cant_intentos FROM cuestionario WHERE id_cuestionario = ? ";
    try{
        conectar();
        ResultSet rs = ejecutarConsulta(sql_Intentos, c.getId_Cuestionario());
        if(rs.next()){
            intentosPrevios = rs.getInt("cant_intentos");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    //obtengo la diferencia
    int diferencia = c.getCantIntentos() - intentosPrevios;
    
    
    String sql = "UPDATE cuestionario SET titulo=?, modalidad=?, ci_usuario=?, cant_intentos=?, cantidad_preguntas_aleatorias=?, retroalimentacion=? WHERE id_cuestionario=?";
    try {
        conectar();
        ejecutarSentencia(sql,
            c.getTitulo(),
            c.getModalidad(),
            c.getCiUsuario(),
            c.getCantIntentos(),
            c.getCantidadPreguntasAleatorias(),
            c.getRetroalimentacion(),
            c.getId_Cuestionario()
        );
        //llamo al dao de repsonde para agregar diferencia
        if(diferencia >0){
        daoRes.agregarIntentosNuevos(c.getId_Cuestionario(), diferencia);
    }
        
        //Vuelvo a actualizar las preguntas, borro el array viejo e inseto el nuevo.
            String sqlBorrar = "DELETE FROM asigna WHERE id_cuestionario = ?";
            ejecutarSentencia(sqlBorrar, c.getId_Cuestionario());
        //luego del borrado inserto las nuevas, dependiendo la modalidad...
        if("Estatico".equalsIgnoreCase(c.getModalidad()) || "Adaptativo".equalsIgnoreCase(c.getModalidad())){
             if(c.getPreguntas() != null){
            for(Pregunta p : c.getPreguntas()){
                ejecutarSentencia("INSERT INTO asigna (id_cuestionario, id_pregunta) VALUES (?,?)", c.getId_Cuestionario(), p.getId_Pregunta());
            }
        }
        }else if ("Aleatorio".equalsIgnoreCase(c.getModalidad())) {
    // Re-sortea las preguntas
    List<Pregunta> nuevasRandom =  daoPreg.obtenerPreguntasRandom(c.getCantidadPreguntasAleatorias(),c.getTemaFiltro());

    // Las guardo en el propio objeto
    c.setPreguntas(nuevasRandom);

    // Inserto en ASIGNA las preguntas sorteadas
    for (Pregunta p : nuevasRandom) {
        ejecutarSentencia(
            "INSERT INTO asigna (id_cuestionario, id_pregunta) VALUES (?, ?)",
            c.getId_Cuestionario(),
            p.getId_Pregunta()
        );
    }
}

       
        
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return false;
}

    @Override
public boolean eliminar(int id) {
    try {
        // Primero elimino las relaciones en asigna
        eliminarPreguntasDeCuestionario(id);
        //Elimino de la  tabla asigna
        eliminarAsignacion(id);
        
        // Luego elimino el cuestionario
        String sql = "DELETE FROM cuestionario WHERE id_cuestionario=?";
        conectar();
        ejecutarSentencia(sql, id);
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return false;
}


    
   private Cuestionario mapearCuestionario(ResultSet rs) throws SQLException {
        Cuestionario c = new Cuestionario();
        c.setId_Cuestionario(rs.getInt("id_cuestionario"));
        c.setTitulo(rs.getString("titulo"));
        c.setModalidad(rs.getString("modalidad"));
        c.setCiUsuario(rs.getInt("ci_usuario"));
        c.setRetroalimentacion(rs.getString("retroalimentacion"));
        c.setCantIntentos(rs.getInt("cant_intentos"));
        c.setPreguntas(obtenerPreguntasDeCuestionario(c.getId_Cuestionario()));
        c.setCantidadPreguntasAleatorias(rs.getInt("cantidad_preguntas_aleatorias"));
        return c;
    }
   
   @Override
   public List<Pregunta> obtenerPreguntasDeCuestionario(int idCuestionario) {
    List<Pregunta> preguntas = new ArrayList<>();
    String sql = "SELECT p.* FROM asigna a " +
                 "JOIN pregunta p ON a.id_pregunta = p.id_pregunta " +
                 "WHERE a.id_cuestionario = ?";

    try {
        conectar();
        ResultSet rs = ejecutarConsulta(sql, idCuestionario);
        while (rs.next()) {
            Pregunta p = new Pregunta();
            p.setId_Pregunta(rs.getInt("id_pregunta"));
            p.setTema(rs.getString("tema"));
            p.setEnunciado(rs.getString("enunciado"));
            p.setTipo(TipoPregunta.fromString(rs.getString("tipo")));
            p.setNivel(Nivel.fromInt(rs.getInt("nivel")));
            p.setCantApariciones(rs.getInt("cant_apariciones"));
            p.setCantRespuestasCorrectas(rs.getInt("cant_respuestas_correctas"));
            preguntas.add(p);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }

    PreguntaDAOImp pdao = new PreguntaDAOImp();
    for (Pregunta p : preguntas) {
        p.setOpcionesRespuesta(pdao.obtenerOpcionesDeRespuesta(p.getId_Pregunta()));
    }

    return preguntas;
}
   
   public Map<Integer, List<Pregunta>> obtenerPreguntasOrdenadas(int idCuestionario) {
        
    List<Pregunta> preguntasFaciles = new ArrayList<>();
    List<Pregunta> preguntasMedias = new ArrayList<>();
    List<Pregunta> preguntasDificiles = new ArrayList<>();
    List<Pregunta> preguntas = new ArrayList<>();
    
    String sql = "SELECT p.* FROM asigna a " +
                 "JOIN pregunta p ON a.id_pregunta = p.id_pregunta " +
                 "WHERE a.id_cuestionario = ?";

    try {
        conectar();
        ResultSet rs = ejecutarConsulta(sql, idCuestionario);
        while (rs.next()) {
            Pregunta p = new Pregunta();
            p.setId_Pregunta(rs.getInt("id_pregunta"));
            p.setTema(rs.getString("tema"));
            p.setEnunciado(rs.getString("enunciado"));
            p.setTipo(TipoPregunta.fromString(rs.getString("tipo")));
            p.setNivel(Nivel.fromInt(rs.getInt("nivel")));
            p.setCantApariciones(rs.getInt("cant_apariciones"));
            p.setCantRespuestasCorrectas(rs.getInt("cant_respuestas_correctas"));
            preguntas.add(p);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }

    PreguntaDAOImp pdao = new PreguntaDAOImp();
    
    for (Pregunta p : preguntas) {
        p.setOpcionesRespuesta(pdao.obtenerOpcionesDeRespuesta(p.getId_Pregunta()));
        
        // Clasificación basada en el nivel.getValor() (0,1, 2)
        int nivelValor = p.getNivel().getValor();
        
        if (nivelValor == 0) {
            preguntasFaciles.add(p);
        } else if (nivelValor == 1) {
            preguntasMedias.add(p);
        } else if (nivelValor == 2) {
            preguntasDificiles.add(p);
        }
    }
    
    
        Map<Integer, List<Pregunta>> preguntasClasificadas = new HashMap<>();
        preguntasClasificadas.put(0, preguntasFaciles);
        preguntasClasificadas.put(1, preguntasMedias);
        preguntasClasificadas.put(2, preguntasDificiles);
        
        return preguntasClasificadas;

}


       // Insertar relación (agregar pregunta a un cuestionario)
    public boolean agregarPreguntaACuestionario(int idCuestionario, int idPregunta) {
        String sql = "INSERT INTO asigna (id_cuestionario, id_pregunta) VALUES (?, ?)";
        try {
            conectar();
            ejecutarSentencia(sql, idCuestionario, idPregunta);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }

    // Eliminar TODAS las preguntas asociadas a un cuestionario
    public boolean eliminarPreguntasDeCuestionario(int idCuestionario) {
        String sql = "DELETE FROM asigna WHERE id_cuestionario=?";
        try {
            conectar();
            ejecutarSentencia(sql, idCuestionario);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }

    // Eliminar una sola pregunta de un cuestionario
    public boolean eliminarPreguntaDeCuestionario(int idCuestionario, int idPregunta) {
        String sql = "DELETE FROM asigna WHERE id_cuestionario=? AND id_pregunta=?";
        try {
            conectar();
            ejecutarSentencia(sql, idCuestionario, idPregunta);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
    
    //Eliminar el cuestionario de la tabla realiza *a un estudiante
    public boolean eliminarAsignacion(int idCuestionario){
        String sql = "DELETE FROM realiza WHERE id_cuestionario=?";
        try {
            conectar();
            ejecutarSentencia(sql, idCuestionario);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
    
    public boolean asignarCuestionarioVariosEst(int idCuestionario, List<Usuario> estudiantes, Cuestionario cuestionario) {
    String sql = "INSERT IGNORE INTO realiza (ci_usuario, id_cuestionario, cant_intentos, estado) "
               + "VALUES (?, ?, ?, 'pendiente')";

    try {
        conectar();
        for (Usuario est : estudiantes) {
            // Insertar con la cantidad de intentos directamente
            ejecutarSentencia(sql, est.getCi(), idCuestionario, cuestionario.getCantIntentos());
        }
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    } finally {
        desconectar();
    }
}

    //Metodo para recuperar los cuestionarios de un determinado usuario, vamos a la tabla REALIZA
    public List<Cuestionario> obtenerCuestionariosAsignados(int ciEstudiante) {
    List<Cuestionario> cuestionarios = new ArrayList<>();

    // Traemos los cuestionarios que figuren en 'realiza' para este estudiante
    String sql = "SELECT c.* FROM cuestionario c " +
                 "INNER JOIN realiza r ON c.id_cuestionario = r.id_cuestionario " +
                 "WHERE r.ci_usuario = ?";

    try {
        conectar();
        ResultSet rs = ejecutarConsulta(sql, ciEstudiante);
        while (rs.next()) {
            Cuestionario c = new Cuestionario();
            c.setId_Cuestionario(rs.getInt("id_cuestionario"));
            c.setTitulo(rs.getString("titulo"));
            c.setModalidad(rs.getString("modalidad"));
            c.setCiUsuario(rs.getInt("ci_usuario"));
            c.setRetroalimentacion(rs.getString("retroalimentacion"));
            c.setCantIntentos(rs.getInt("cant_intentos"));
            c.setCantidadPreguntasAleatorias(rs.getInt("cantidad_preguntas_aleatorias"));

            cuestionarios.add(c); //agregamos cada cuestionario a la lista
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }

    return cuestionarios;
}
    public int obtenerCantidadPreguntas(int id_cuestionario){
        int cant_preguntas =0;
        String sql = "SELECT COUNT(*) FROM asigna where id_cuestionario = ?";
        
        try{
            conectar();
            ResultSet rs = ejecutarConsulta(sql, id_cuestionario);
            if(rs.next()){
                cant_preguntas = rs.getInt(1);
            }
        }catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
        
      return cant_preguntas;  
    };

}

