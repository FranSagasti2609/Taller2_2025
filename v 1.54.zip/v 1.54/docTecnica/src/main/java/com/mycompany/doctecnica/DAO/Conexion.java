package com.mycompany.doctecnica.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class Conexion {
    
    protected Connection conn;
    private final String DRIVER ="org.mariadb.jdbc.Driver";
    private final String USER = "evaluauser";
    private final String PASSWORD = "Evalua2025";
    private final String HOST = "localhost";
    private final String DB_NAME="evaluame";

    protected void conectar() throws SQLException {
        conn=null;
        String url = "jdbc:mariadb://" + HOST + ":3306/" + DB_NAME;
        try{
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(url, USER, PASSWORD);
        }
        catch (ClassNotFoundException ex) {
            System.out.print("ERROR: No se pudo encontrar el driver JDBC. Consulte un administrador.");
        }
        catch (SQLException ex) {
            throw new SQLException("ERROR: No se pudo conectar con la base de datos. Consulte un administrador.", ex);
        }  
        
    }
    
    public void initUsuarioYBase() {
    boolean conectado = false;

    // Intentamos conectar con evaluauser
    try {
        conectar();
        conectado = true;
    } catch (SQLException ex) {
        System.out.println("No se pudo conectar con evaluauser, intentando crear usuario y base...");
    }

    if (!conectado) {
        // Conectar como root temporalmente
        String rootUser = "root";      // el usuario root de MariaDB
        String rootPass = "root";          // la contraseña de root en la PC del usuario
        try (Connection rootConn = DriverManager.getConnection(
                "jdbc:mariadb://localhost:3306/", rootUser, rootPass);
             java.sql.Statement stmt = rootConn.createStatement()) {

            // Crear usuario evaluauser
            stmt.execute("DROP USER IF EXISTS 'evaluauser'@'localhost'");
            stmt.execute("CREATE USER 'evaluauser'@'localhost' IDENTIFIED BY 'Evalua2025'");
            stmt.execute("GRANT ALL PRIVILEGES ON *.* TO 'evaluauser'@'localhost' WITH GRANT OPTION");
            stmt.execute("FLUSH PRIVILEGES");

            System.out.println("Usuario evaluauser creado correctamente.");

            //  Crear la base si no existe
            stmt.execute("CREATE DATABASE IF NOT EXISTS evaluame DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci");
            System.out.println("Base de datos evaluame creada correctamente.");

            // Crear tablas usando evaluame.sql
            try (var inputStream = getClass().getClassLoader().getResourceAsStream("sql/evaluame.sql")) {
                if (inputStream != null) {
                    String sql = new String(inputStream.readAllBytes());
                    for (String sentencia : sql.split(";")) {
                        sentencia = sentencia.trim();
                        if (!sentencia.isEmpty()) stmt.execute(sentencia);
                    }
                    System.out.println("Tablas creadas correctamente.");
                } else {
                    System.out.println("No se encontró evaluame.sql en recursos.");
                }
            }

        } catch (Exception e) {
            System.out.println("Error inicializando usuario y base: " + e.getMessage());
            e.printStackTrace();
            return;
        }

        // Finalmente conectamos normalmente con evaluauser
        try {
            conectar();
            System.out.println("Conectado con evaluauser exitosamente.");
        } catch (SQLException ex) {
            System.out.println("ERROR: no se pudo conectar con evaluauser tras crearlo.");
            ex.printStackTrace();
        }
    }
}

    protected void desconectar(){
        try{
            conn.close();
         
        }
        catch (Exception ex) {
            System.out.print("ERROR");
        }
    }
    /**
    *Ejecuta una sentencia de inserción, modificación o eliminación de datos en BBDD.
    * @param sql Sentencia a realizar del tipo INSERT, UPDATE o DELETE
    * @param parametros valores relacionados a la sentencia. 
    */
    protected void ejecutarSentencia(String sql, Object... parametros) throws SQLException{
        try{
            PreparedStatement stmt = conn.prepareStatement(sql);
            for(int i =0; i< parametros.length; i++){
                stmt.setObject(i+1, parametros[i]);
            }
            stmt.executeUpdate();
           
        }
        catch (SQLException ex) {
            throw ex;
        }
        
    }
       
    protected ResultSet ejecutarConsulta(String consulta, Object... parametros){
        ResultSet rs = null;
        try{
            PreparedStatement stmt = conn.prepareStatement(consulta);
            for(int i =0; i< parametros.length; i++){
                stmt.setObject(i+1, parametros[i]);
            }
            rs = stmt.executeQuery();
          
            
        }
        catch (Exception ex) {
            System.out.print("ERROR \n" + ex.getMessage());
        }
        return rs;
    }
}
