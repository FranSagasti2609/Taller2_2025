package com.mycompany.doctecnica;

import com.mycompany.doctecnica.Controlador.ControladorVisual;
import com.mycompany.doctecnica.DAO.Conexion;

public class DocTecnica {
        public static void main(String[] args) {
        
            ControladorVisual inicio = new ControladorVisual();
            
            Conexion conexion = new Conexion() {}; // clase anónima si es abstracta
            conexion.initUsuarioYBase();
            
            inicio.iniciarAplicacion();

}
}
