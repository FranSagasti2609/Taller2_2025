package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Respuesta;
import java.util.List;

public interface RespuestaDAO {
    public void insertar(Respuesta res);
    public List<Respuesta> obtenerPorPregunta(int idPregunta);
    public void eliminarPorPregunta(int idPregunta);
}
