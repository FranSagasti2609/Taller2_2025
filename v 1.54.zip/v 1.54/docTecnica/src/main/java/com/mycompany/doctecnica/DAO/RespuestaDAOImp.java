package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Respuesta;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RespuestaDAOImp extends Conexion {

    public void insertar(Respuesta r) {
        String sql = "INSERT INTO respuesta (id_respuesta, enunciado, es_correcta, id_pregunta) VALUES (?, ?, ?, ?)";
        try {
            conectar();
            ejecutarSentencia(sql, r.getId(), r.getTexto(), r.esCorrecta(), r.getIdPregunta());
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }

    public List<Respuesta> obtenerPorPregunta(int idPregunta) {
        List<Respuesta> lista = new ArrayList<>();
        String sql = "SELECT * FROM respuesta WHERE id_pregunta = ?";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql, idPregunta);
            while (rs.next()) {
                Respuesta r = new Respuesta(
                    rs.getString("enunciado"),
                    rs.getBoolean("es_correcta"),
                    rs.getInt("id_pregunta")
                );
                lista.add(r);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }
    
   public void eliminarPorPregunta(int idPregunta) {
    String sql = "DELETE FROM respuesta WHERE id_pregunta = ?";
    
    try {
        conectar();
        ejecutarSentencia(sql, idPregunta);
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
}
   
   

}
