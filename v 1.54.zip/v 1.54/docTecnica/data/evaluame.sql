-- =======================================================
-- CREACIÓN DE BASE DE DATOS
-- =======================================================
CREATE DATABASE IF NOT EXISTS `evaluame`
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_spanish_ci;
USE `evaluame`;


-- =======================================================
-- TABLA USUARIO (base de todas las demás)
-- =======================================================
CREATE TABLE IF NOT EXISTS `usuario` (
  `ci` INT UNSIGNED NOT NULL,
  `nombre` VARCHAR(50) NOT NULL DEFAULT '',
  `apellido` VARCHAR(50) NOT NULL DEFAULT '',
  `contrasena` CHAR(32) NOT NULL DEFAULT '',
  `rol` ENUM('Docente','Estudiante') NOT NULL DEFAULT 'Docente',
  PRIMARY KEY (`ci`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- =======================================================
-- TABLA GRUPO (depende de usuario)
-- =======================================================
CREATE TABLE IF NOT EXISTS `grupo` (
  `id_grupo` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  `ci_usuario` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_grupo`),
  KEY `FK__usuario` (`ci_usuario`),
  CONSTRAINT `FK__usuario`
    FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`)
    ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- =======================================================
-- TABLA INTEGRA (relación N:N entre usuario y grupo)
-- =======================================================
CREATE TABLE IF NOT EXISTS `integra` (
  `ci_usuario` INT UNSIGNED NOT NULL,
  `id_grupo` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`ci_usuario`, `id_grupo`),
  KEY `FK_integra_grupo` (`id_grupo`),
  CONSTRAINT `FK_integra_usuario`
    FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`)
    ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_integra_grupo`
    FOREIGN KEY (`id_grupo`) REFERENCES `grupo` (`id_grupo`)
    ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- =======================================================
-- TABLA CUESTIONARIO (depende de usuario)
-- =======================================================
CREATE TABLE IF NOT EXISTS `cuestionario` (
  `id_cuestionario` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `titulo` VARCHAR(50) NOT NULL DEFAULT '',
  `modalidad` VARCHAR(50) NOT NULL DEFAULT '',
  `ci_usuario` INT UNSIGNED NOT NULL,
  `cant_intentos` INT DEFAULT 0,
  `cantidad_preguntas_aleatorias` INT DEFAULT 0,
  `retroalimentacion` VARCHAR(50) NOT NULL DEFAULT 'numerica',
  PRIMARY KEY (`id_cuestionario`),
  KEY `FK__cuest_usuario` (`ci_usuario`),
  CONSTRAINT `FK__cuest_usuario`
    FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`)
    ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- =======================================================
-- TABLA PREGUNTA (depende de usuario)
-- =======================================================
CREATE TABLE IF NOT EXISTS `pregunta` (
  `id_pregunta` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `tema` VARCHAR(50) NOT NULL DEFAULT '',
  `enunciado` VARCHAR(250) NOT NULL DEFAULT '',
  `tipo` VARCHAR(50) NOT NULL DEFAULT '',
  `nivel` INT NOT NULL DEFAULT 0,
  `cant_apariciones` INT NOT NULL DEFAULT 0,
  `cant_respuestas_correctas` INT DEFAULT 0,
  `ci_usuario` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_pregunta`),
  KEY `FK__preg_usuario` (`ci_usuario`),
  CONSTRAINT `FK__preg_usuario`
    FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`)
    ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- =======================================================
-- TABLA RESPUESTA (depende de pregunta)
-- =======================================================
CREATE TABLE IF NOT EXISTS `respuesta` (
  `id_respuesta` INT NOT NULL AUTO_INCREMENT,
  `id_pregunta` INT UNSIGNED NOT NULL,
  `enunciado` VARCHAR(250) NOT NULL,
  `es_correcta` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id_respuesta`),
  KEY `idx_respuesta_pregunta` (`id_pregunta`),
  CONSTRAINT `FK_respuesta_pregunta`
    FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta` (`id_pregunta`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- =======================================================
-- TABLA ASIGNA (relación N:N entre cuestionario y pregunta)
-- =======================================================
CREATE TABLE IF NOT EXISTS `asigna` (
  `id_cuestionario` INT UNSIGNED NOT NULL,
  `id_pregunta` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id_cuestionario`, `id_pregunta`),
  KEY `idx_asigna_pregunta` (`id_pregunta`),
  CONSTRAINT `FK__asig_cuestionario`
    FOREIGN KEY (`id_cuestionario`) REFERENCES `cuestionario` (`id_cuestionario`)
    ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK__asig_pregunta`
    FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta` (`id_pregunta`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- =======================================================
-- TABLA REALIZA (relación estudiante-cuestionario)
-- =======================================================
CREATE TABLE IF NOT EXISTS `realiza` (
  `ci_usuario` INT UNSIGNED NOT NULL,
  `id_cuestionario` INT UNSIGNED NOT NULL,
  `cant_intentos` INT UNSIGNED NOT NULL,
  `estado` ENUM('PENDIENTE','FINALIZADO') NOT NULL DEFAULT 'PENDIENTE',
  PRIMARY KEY (`ci_usuario`, `id_cuestionario`),
  KEY `FK__realiza_cuestionario` (`id_cuestionario`),
  CONSTRAINT `FK__realiza_usuario`
    FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`)
    ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK__realiza_cuestionario`
    FOREIGN KEY (`id_cuestionario`) REFERENCES `cuestionario` (`id_cuestionario`)
    ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;


-- =======================================================
-- TABLA RESPONDE (registro de respuestas de estudiantes)
-- =======================================================
CREATE TABLE IF NOT EXISTS `responde` (
  `num_respuesta` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `id_pregunta` INT UNSIGNED NOT NULL,
  `ci_usuario` INT UNSIGNED NOT NULL,
  `es_correcta` TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`num_respuesta`),
  KEY `idx_responde_pregunta` (`id_pregunta`),
  KEY `idx_responde_usuario` (`ci_usuario`),
  CONSTRAINT `FK_responde_pregunta`
    FOREIGN KEY (`id_pregunta`) REFERENCES `pregunta` (`id_pregunta`)
    ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_responde_usuario`
    FOREIGN KEY (`ci_usuario`) REFERENCES `usuario` (`ci`)
    ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish_ci;