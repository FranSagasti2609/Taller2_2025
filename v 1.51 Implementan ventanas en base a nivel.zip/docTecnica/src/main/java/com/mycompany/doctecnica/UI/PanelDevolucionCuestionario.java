package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.Model.Nivel;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Responde;
import com.mycompany.doctecnica.Model.Respuesta;
import com.mycompany.doctecnica.Model.TipoPregunta;
import com.mycompany.doctecnica.UI.uc.IUcPregunta;
import com.mycompany.doctecnica.UI.uc.UcPreguntaCuestionario;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Controlador.ControladorRespuestas;
import com.mycompany.doctecnica.Controlador.ControladorPreguntasRespuestas;
import com.mycompany.doctecnica.Controlador.ControladorPrincipal;

import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import java.awt.Color;

public class PanelDevolucionCuestionario extends javax.swing.JPanel {

    private Cuestionario cuest;
    private Usuario user;
    private List<Pregunta> preguntas;    
    private ControladorRespuestas controlRes = new ControladorRespuestas();
    ControladorPreguntasRespuestas controlPreg = new ControladorPreguntasRespuestas();
    private final List<IUcPregunta> componentesPregunta = new ArrayList<>();
    private JPanel zonaTrabajo;
    private ControladorPrincipal controlMain = new ControladorPrincipal();
    int nota;
    
    public PanelDevolucionCuestionario(Usuario usuario, Cuestionario c,JPanel zonaTrab) {
        
        this.user = usuario;
        this.cuest = c;
        this.zonaTrabajo = zonaTrab;
        nota = controlMain.obtenerCalificacion(user.getCi(), cuest.getId_Cuestionario());
        initComponents();
        
        
        //Analizamos que tipo de evaluacion tenemos para cargar el panel correspondiente
        if("Detallada".equals(c.getRetroalimentacion())){
            preguntas = cuest.getPreguntas(); //cargo las preguntas del cuest
            construirFormularioPreguntas();
        }
    }

    private void construirFormularioPreguntas() {
    panelContenedorPreguntas.removeAll();
    panelContenedorPreguntas.setBackground(Color.WHITE);

       List<Responde> respuestasEst = controlRes.getRespuestas(
            user.getCi(),
            cuest.getId_Cuestionario()
    );

    for (Pregunta p : cuest.getPreguntas()) {
        boolean correcta = false;
        for (Responde r : respuestasEst) {
            if (r.getIdPregunta() == p.getId_Pregunta()) {
                correcta = r.getEsCorrecta();   // true si fue correcta
                break;
            }
        }

        UcPreguntaCuestionario uc = new UcPreguntaCuestionario(p);

        JLabel lblResultado = new JLabel(
                correcta ? "✔ Correcta" : "✘ Incorrecta"
        );
        lblResultado.setForeground(correcta ? Color.GREEN.darker() : Color.RED);

        // Panel para agrupar pregunta + resultado
        JPanel panelPregunta = new JPanel();
        panelPregunta.setLayout(new BoxLayout(panelPregunta, BoxLayout.Y_AXIS));
        panelPregunta.setBackground(Color.WHITE);
        panelPregunta.add(uc);
        panelPregunta.add(lblResultado);

        panelContenedorPreguntas.add(panelPregunta);
        panelContenedorPreguntas.add(Box.createVerticalStrut(10));

    }

    panelContenedorPreguntas.revalidate();
    panelContenedorPreguntas.repaint();
}

    
    private void devolucionSimple(){

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scrollCuestionario = new javax.swing.JScrollPane();
        panelContenedorPreguntas = new javax.swing.JPanel();
        LabelNota = new javax.swing.JLabel();

        scrollCuestionario.setBackground(new java.awt.Color(255, 255, 255));

        panelContenedorPreguntas.setLayout(new javax.swing.BoxLayout(panelContenedorPreguntas, javax.swing.BoxLayout.Y_AXIS));
        scrollCuestionario.setViewportView(panelContenedorPreguntas);

        LabelNota.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        LabelNota.setText("Tu nota final es: " + nota +"/10"
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollCuestionario, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 671, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(201, 201, 201)
                .addComponent(LabelNota)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(LabelNota)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollCuestionario, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
    }// </editor-fold>//GEN-END:initComponents



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel LabelNota;
    private javax.swing.JPanel panelContenedorPreguntas;
    private javax.swing.JScrollPane scrollCuestionario;
    // End of variables declaration//GEN-END:variables
}
