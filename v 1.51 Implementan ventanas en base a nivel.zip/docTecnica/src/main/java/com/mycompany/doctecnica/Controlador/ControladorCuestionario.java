package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.DAO.CuestionarioDAOImp;
import com.mycompany.doctecnica.DAO.RespondeDAOImp;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Model.Pregunta;
import java.util.List;
import java.util.Map;

public class ControladorCuestionario {
    
    CuestionarioDAOImp dao = new CuestionarioDAOImp();
    RespondeDAOImp daoRes = new RespondeDAOImp();
    //Metodo para guardar cuestionario en la base de datos.
    public boolean guardarCuestionario(Cuestionario c){
        return dao.insertar(c);
    }
    
    public boolean borrarCuestionario(int idCuestionario) {
     return dao.eliminar(idCuestionario);
}
    
    public List<Cuestionario> cargarCuestionarios(){
        return dao.obtenerTodos();
    }
    
    public Cuestionario obtenerCuesPorId(int idCuestionario){
        return dao.obtenerPorId(idCuestionario);
        
    }
    
    public boolean actualizarCuestionario(Cuestionario c){
        return dao.actualizar(c);
    }
    
    public boolean asignarCuestionarioVariosEst(int idCuestionario, List<Usuario> estudiantes, Cuestionario cuest){
      return dao.asignarCuestionarioVariosEst(idCuestionario, estudiantes, cuest);
    }
    
    public List<Cuestionario> obtenerCuestionariosEst(int ci){
        return dao.obtenerCuestionariosAsignados(ci);
    }
    
    public List<Integer> obtenerTerminadosEstudiante(int ci){
        return daoRes.obtenerFinalizados(ci);
    }
    
    public Map<Integer, List<Pregunta>> obtenerPreguntasOrdenadas(int idCuestionario){
        return dao.obtenerPreguntasOrdenadas(idCuestionario);
    }
}
