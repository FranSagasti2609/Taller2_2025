package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Nivel;
import com.mycompany.doctecnica.Model.TipoPregunta;
import com.mycompany.doctecnica.Model.Respuesta;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PreguntaDAOImp extends Conexion {

    // Crear pregunta
    public boolean insertar(Pregunta pregunta, int ciDocente) {
        String sql = "INSERT INTO pregunta (tema, enunciado, tipo, nivel, cant_apariciones, ci_usuario, cant_respuestas_correctas) "
                   + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            conectar();
            PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, pregunta.getTema());
            stmt.setString(2, pregunta.getEnunciado());
            stmt.setString(3, pregunta.getTipo().toString());
            stmt.setInt(4, pregunta.getNivel().getValor());   // Nivel como int
            stmt.setInt(5, 0); // cant_apariciones inicia en 0
            stmt.setInt(6, ciDocente); // FK al docente que crea
            stmt.setInt(7, 0); // cant_respuestas_correctas inicia en 0

            int filas = stmt.executeUpdate();

            if (filas > 0) {
                // Obtener el id autogenerado
                ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    pregunta.setId_Pregunta(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return false;
    }

    // Listar preguntas
    public List<Pregunta> obtenerTodas() {
        List<Pregunta> lista = new ArrayList<>();
        String sql = "SELECT * FROM pregunta";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql);
            while (rs.next()) {
                Pregunta p = new Pregunta();
                p.setId_Pregunta(rs.getInt("id_pregunta"));
                p.setTema(rs.getString("tema"));
                p.setEnunciado(rs.getString("enunciado"));
                p.setTipo(TipoPregunta.valueOf(rs.getString("tipo"))); // enum desde String
                p.setNivel(Nivel.fromInt(rs.getInt("nivel")));        // int → enum
                p.setCantApariciones(rs.getInt("cant_apariciones"));
                p.setCantRespuestasCorrectas(rs.getInt("cant_respuestas_correctas"));
                lista.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }

    // Modificar pregunta
    public boolean actualizar(Pregunta pregunta) {
        String sql = "UPDATE pregunta SET tema=?, enunciado=?, tipo=?, nivel=? WHERE id_pregunta=?";
        try {
            conectar();
            ejecutarSentencia(sql,
                    pregunta.getTema(),
                    pregunta.getEnunciado(),
                    pregunta.getTipo().toString(),
                    pregunta.getNivel().getValor(),
                    pregunta.getId_Pregunta()
            );
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }

    // Eliminar pregunta
    public boolean eliminar(int idPregunta) {
        String sql = "DELETE FROM pregunta WHERE id_pregunta=?";
        try {
            conectar();
            ejecutarSentencia(sql, idPregunta);
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
    
   public Pregunta obtenerPorId(int idPreg){
        Pregunta pregunta =null;
        String sql = "SELECT * FROM pregunta WHERE id_pregunta=?";
        
        try{
            conectar();
           ResultSet rs = ejecutarConsulta(sql, idPreg);
            if (rs.next()) {
            // Create a new Pregunta object
            pregunta = new Pregunta();
            
           //Creamos la pregunta en base a los atributos traidos
                pregunta.setId_Pregunta(rs.getInt("id_pregunta"));
                pregunta.setEnunciado(rs.getString("enunciado"));
                pregunta.setTema(rs.getString("tema"));
                pregunta.setCantApariciones(rs.getInt("cant_apariciones"));
                pregunta.setCantRespuestasCorrectas(rs.getInt("cant_respuestas_correctas"));
                //hacemos casteo para ambos atributos de nivel y tipo de preg
                 int nivelInt = rs.getInt("nivel");
                Nivel nivelEnum = Nivel.fromInt(nivelInt);
                pregunta.setNivel(nivelEnum);
                 
                String tipoString = rs.getString("tipo");
                TipoPregunta tipo = TipoPregunta.fromString(tipoString);
                pregunta.setTipo(tipo);
                
                //el tema de las opciones de respuesta
                List<Respuesta> opciones = obtenerOpcionesDeRespuesta(pregunta.getId_Pregunta());
                pregunta.setOpcionesRespuesta(opciones);
    

        }
        }catch (SQLException e) {
            e.printStackTrace();
          } finally {
            desconectar();
        }
        return pregunta;
    }
    
     public List<Respuesta> obtenerOpcionesDeRespuesta(int idPregunta){
         List<Respuesta> opciones = new ArrayList<>();
         
         String sql = "SELECT * FROM respuesta WHERE id_pregunta = ?";
         try {
            conectar();
          
            ResultSet rs = ejecutarConsulta(sql, idPregunta);
            
            // Recorremos cada fila del ResultSet.
            while (rs.next()) {
                // Por cada fila, creamos un nuevo objeto Respuesta.
                Respuesta respuesta = new Respuesta();
                
                // Mapeamos los datos de la fila a los atributos del objeto Respuesta.
                respuesta.setTexto(rs.getString("enunciado"));
                respuesta.setEsCorrecta(rs.getBoolean("es_correcta"));
                respuesta.setIdPregunta(rs.getInt("id_pregunta"));
                
                // Añadimos el objeto Respuesta a la lista.
                opciones.add(respuesta);
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            // En caso de error, la lista se devolverá vacía, lo cual es aceptable.
        } finally {
            desconectar();
        }
         
         return opciones;
     }
     
     //Metodo para obtener los temas de preguntas, necesario para el comboBox del panel de PREGUNTAS
     public List<String> obtenerTemasPreguntas() {
         
    List<String> temas = new ArrayList<>();
    String sql = "SELECT DISTINCT tema FROM pregunta WHERE tema IS NOT NULL ORDER BY tema ASC";

    try {
        conectar();
        ResultSet rs = ejecutarConsulta(sql);
        while (rs.next()) {
            temas.add(rs.getString("tema"));
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }

    return temas;
}
     
     //Metodo para traer preguntas randoms de la BD, que ademas hace un check
     public List<Pregunta> obtenerPreguntasRandom(int cantidad, String tema){
    List<Pregunta> preguntas = new ArrayList<>();
    try{
        conectar();

        // Contar disponibles
        String sqlCount;
        boolean todos = "Todos".equals(tema);
        if (todos) {
            sqlCount = "SELECT COUNT(*) FROM pregunta";
        } else {
            sqlCount = "SELECT COUNT(*) FROM pregunta WHERE tema = ?";
        }

        PreparedStatement stmtCount = conn.prepareStatement(sqlCount);
        if (!todos) {
            stmtCount.setString(1, tema);
        }
        ResultSet rsCount = stmtCount.executeQuery();

        int totalDisponibles = 0;
        if (rsCount.next()) {
            totalDisponibles = rsCount.getInt(1);
        }

        if (totalDisponibles < cantidad) {
            throw new SQLException("No hay suficientes preguntas. Disponibles: "
                                    + totalDisponibles + ", requeridas: " + cantidad);
        }

        // Seleccionar preguntas al azar
        String sql = todos ?
            "SELECT * FROM pregunta ORDER BY RAND() LIMIT ?" :
            "SELECT * FROM pregunta WHERE tema = ? ORDER BY RAND() LIMIT ?";

        PreparedStatement stmt = conn.prepareStatement(sql);
        if (todos) {
            stmt.setInt(1, cantidad);
        } else {
            stmt.setString(1, tema);
            stmt.setInt(2, cantidad);
        }

        ResultSet rs = stmt.executeQuery();
        while (rs.next()) {
            Pregunta p = new Pregunta();
            p.setId_Pregunta(rs.getInt("id_pregunta"));
            p.setTema(rs.getString("tema"));
            p.setEnunciado(rs.getString("enunciado"));
            preguntas.add(p);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        desconectar();
    }
    return preguntas;
}

     
     //metodo para actualizar aparicion de la pregunta.
    public void incrementarCantApariciones(int idPregunta) {
        String sqlSelect = "SELECT cant_apariciones FROM pregunta WHERE id_pregunta = ?";
        String sqlUpdate = "UPDATE pregunta SET cant_apariciones = ? WHERE id_pregunta = ?";
        
        try {
            conectar();
            int cantAparicionesActual;
            ResultSet rs = ejecutarConsulta(sqlSelect, idPregunta);
            
            if (rs.next()) {
                cantAparicionesActual = rs.getInt("cant_apariciones");
                rs.close();
            } else {
                return;
            }

            int nuevoValor = cantAparicionesActual + 1;
            ejecutarSentencia(sqlUpdate, nuevoValor, idPregunta);
            
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }
    
    //metodo para aumentar cuando una pregunta se responde correctamente
    public void aumentarCorrecta(int idPregunta){
        String sqlSelect = "SELECT cant_respuestas_correctas FROM pregunta WHERE id_pregunta = ?";
        String sqlUpdate = "UPDATE pregunta SET cant_respuestas_correctas = ? WHERE id_pregunta = ?";
        
        try{
            conectar();
            int cantCorrectas;
            ResultSet rs = ejecutarConsulta(sqlSelect, idPregunta);
            if (rs.next()) {
                cantCorrectas = rs.getInt("cant_respuestas_correctas");
                rs.close();
            } else {
                return;
            }
            
            int nuevasCorrectas = cantCorrectas + 1;
            ejecutarSentencia(sqlUpdate, nuevasCorrectas, idPregunta);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }

}
