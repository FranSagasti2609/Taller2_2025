package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Grupo;
import com.mycompany.doctecnica.Model.Usuario;
import java.util.List;

public interface GrupoDAO {
    void insertar(Grupo grupo);
    List<Grupo> obtenerPorDocente(int ciDocente);
    List<Grupo> obtenerTodos();
    void eliminar(int idGrupo);
    boolean agregarEstudianteAGrupo(int ciEstudiante, int idGrupo);
    List<Usuario> obtenerEstudiantesPorGrupo(int idGrupo);
    public boolean existeUsuario(int ci);
    public boolean estaEnAlgúnGrupo(int ci);
    public boolean eliminarEstudianteDeGrupo(int idGrupo, int ciUsuario);
}
