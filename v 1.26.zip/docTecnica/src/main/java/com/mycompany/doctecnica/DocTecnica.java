package com.mycompany.doctecnica;

import com.mycompany.doctecnica.Controlador.ControladorVisual;
import com.mycompany.doctecnica.DAO.PreguntaDAOImp;
import com.mycompany.doctecnica.DAO.RespuestaDAOImp;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Respuesta;
import com.mycompany.doctecnica.Model.TipoPregunta;
import com.mycompany.doctecnica.Model.Nivel;
import java.util.List;
import java.util.Scanner;

public class DocTecnica {
        public static void main(String[] args) {
        
            ControladorVisual inicio = new ControladorVisual();
            inicio.iniciarAplicacion();
            
            //test seleccion logica PREGUNTA-RESPUESTA
            /*PreguntaDAOImp daoPregunta = new PreguntaDAOImp();
        Pregunta preguntaSeleccionada = daoPregunta.obtenerPorId(2);

        if (preguntaSeleccionada != null) {
            RespuestaDAOImp daoRespuesta = new RespuestaDAOImp();
            List<Respuesta> opciones = daoRespuesta.obtenerPorPregunta(preguntaSeleccionada.getId_Pregunta());

            preguntaSeleccionada.setOpcionesRespuesta(opciones);

            System.out.println("Pregunta: " + preguntaSeleccionada.getEnunciado());
            System.out.println("----------------------------------------");
            
            for (int i = 0; i < opciones.size(); i++) {
                System.out.println((i + 1) + ". " + opciones.get(i).getTexto());
            }

            Scanner scanner = new Scanner(System.in);
            System.out.print("\nSelecciona una opción (ingresa el número): ");
            int seleccion = -1;
            
            try {
                seleccion = scanner.nextInt();
            } catch (Exception e) {
                System.out.println("Entrada inválida.");
                scanner.close();
                return;
            }
            
            if (seleccion > 0 && seleccion <= opciones.size()) {
                Respuesta respuestaElegida = opciones.get(seleccion - 1);
                System.out.println("\nHas seleccionado: " + respuestaElegida.getTexto());
                
                if (respuestaElegida.esCorrecta()) {
                    System.out.println("¡Respuesta correcta! ✅");
                } else {
                    System.out.println("Respuesta incorrecta. ❌");
                }
            } else {
                System.out.println("Opción no válida.");
            }
            
            scanner.close();
        } else {
            System.out.println("No se encontró la pregunta con el ID 2.");
        }*/
    }
}
