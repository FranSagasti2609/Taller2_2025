package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Grupo;
import com.mycompany.doctecnica.Model.Usuario;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GrupoDAOImp extends Conexion implements GrupoDAO {

    @Override
    public void insertar(Grupo grupo) {
        String sql = "INSERT INTO grupo (id_grupo, nombre, ci_usuario) VALUES (?, ?, ?)";
        try {
            conectar();
            ejecutarSentencia(sql, grupo.getId(), grupo.getNombre(), grupo.getCi_docente());
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }

    @Override
    public List<Grupo> obtenerPorDocente(int ciDocente) {
        List<Grupo> lista = new ArrayList<>();
        String sql = "SELECT * FROM grupo WHERE ci_usuario = ?";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql, ciDocente);
            while (rs.next()) {
                lista.add(new Grupo(
                        rs.getInt("id_grupo"),
                        rs.getString("nombre"),
                        rs.getInt("ci_usuario")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }

    @Override
    public List<Grupo> obtenerTodos() {
        List<Grupo> lista = new ArrayList<>();
        String sql = "SELECT * FROM grupo";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql);
            while (rs.next()) {
                lista.add(new Grupo(
                        rs.getInt("id_grupo"),
                        rs.getString("nombre"),
                        rs.getInt("ci_usuario")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }

    @Override
    public void eliminar(int idGrupo) {
        String sql = "DELETE FROM grupo WHERE id_grupo = ?";
        try {
            conectar();
            ejecutarSentencia(sql, idGrupo);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
    }

    public boolean agregarEstudianteAGrupo(int ciEstudiante, int idGrupo) {
        try {
            conectar();
            // Verificar si ya está en algún grupo
            String checkSql = "SELECT COUNT(*) FROM integra WHERE ci_usuario = ?";
            ResultSet rs = ejecutarConsulta(checkSql, ciEstudiante);
            if (rs.next() && rs.getInt(1) > 0) {
                return false; // Ya está en un grupo
            }

            // Insertar si no está
            String sql = "INSERT INTO integra (ci_usuario, id_grupo) VALUES (?, ?)";
            ejecutarSentencia(sql, ciEstudiante, idGrupo);
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }

    public List<Usuario> obtenerEstudiantesPorGrupo(int idGrupo) {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT u.ci, u.nombre, u.apellido, u.contrasena, u.rol " +
                     "FROM usuario u " +
                     "INNER JOIN integra i ON u.ci = i.ci_usuario " +
                     "WHERE i.id_grupo = ?";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql, idGrupo);
            while (rs.next()) {
                lista.add(new Usuario(
                        rs.getInt("ci"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("contrasena"),
                        rs.getString("rol")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return lista;
    }

    public boolean existeUsuario(int ci) {
        String sql = "SELECT 1 FROM usuario WHERE ci = ?";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql, ci);
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return false;
    }

    public boolean estaEnAlgúnGrupo(int ci) {
        String sql = "SELECT 1 FROM integra WHERE ci_usuario = ?";
        try {
            conectar();
            ResultSet rs = ejecutarConsulta(sql, ci);
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            desconectar();
        }
        return false;
    }
    
    public boolean eliminarEstudianteDeGrupo(int idGrupo, int ciUsuario) {
        //Esto implica trabajar en la tabla INTEGRA, ya que no queremos eliminar un usuario de la BD, sino de un grupo.
    String sql = "DELETE FROM integra WHERE id_grupo = ? AND ci_usuario = ?";
   try {
        conectar(); // abre la conexión
        ejecutarSentencia(sql, idGrupo, ciUsuario);
        desconectar(); // cierra la conexión
        return true;
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

}
