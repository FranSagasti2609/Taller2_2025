package com.mycompany.doctecnica.Model;

public class Responde {
    private int nro_respuesta;   // Número de la respuesta elegida
    private int id_pregunta;     // Pregunta a la que pertenece esa respuesta
    private int ci_usuario;      // Estudiante que respondió
    private boolean esCorrecta;  // Para guardar si fue correcta o no (extra, no está en la tabla pero útil)
    private String respuestaDada; // Texto de la respuesta, opcional para mostrar después

    public Responde() {}

    public Responde(int nro_respuesta, int id_pregunta, int ci_usuario, boolean esCorrecta, String respuestaDada) {
        this.nro_respuesta = nro_respuesta;
        this.id_pregunta = id_pregunta;
        this.ci_usuario = ci_usuario;
        this.esCorrecta = esCorrecta;
        this.respuestaDada = respuestaDada;
    }

    public int getNro_respuesta() {
        return nro_respuesta;
    }

    public void setNro_respuesta(int nro_respuesta) {
        this.nro_respuesta = nro_respuesta;
    }

    public int getId_pregunta() {
        return id_pregunta;
    }

    public void setId_pregunta(int id_pregunta) {
        this.id_pregunta = id_pregunta;
    }

    public int getCi_usuario() {
        return ci_usuario;
    }

    public void setCi_usuario(int ci_usuario) {
        this.ci_usuario = ci_usuario;
    }

    public boolean isEsCorrecta() {
        return esCorrecta;
    }

    public void setEsCorrecta(boolean esCorrecta) {
        this.esCorrecta = esCorrecta;
    }

    public String getRespuestaDada() {
        return respuestaDada;
    }

    public void setRespuestaDada(String respuestaDada) {
        this.respuestaDada = respuestaDada;
    }
}
