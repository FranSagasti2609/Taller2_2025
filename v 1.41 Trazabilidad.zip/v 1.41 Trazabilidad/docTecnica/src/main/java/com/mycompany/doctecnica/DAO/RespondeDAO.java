package com.mycompany.doctecnica.DAO;
import com.mycompany.doctecnica.Model.Responde;

public interface RespondeDAO {
    public boolean guardarRespuesta(Responde res);
}
