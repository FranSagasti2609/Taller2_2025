package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Responde;
import java.sql.SQLException;

public class RespondeDAOImp extends Conexion{
    
    public boolean guardarRespuesta(Responde res){
   
        String sql = "INSERT INTO responde (id_pregunta, ci_usuario, es_correcta) VALUES (?, ?,?)";
        
       try{
           conectar();
           ejecutarSentencia(sql, res.getIdPregunta(), res.getCiUsuario(), res.getEsCorrecta());
           return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            desconectar();
        }
    }
}
