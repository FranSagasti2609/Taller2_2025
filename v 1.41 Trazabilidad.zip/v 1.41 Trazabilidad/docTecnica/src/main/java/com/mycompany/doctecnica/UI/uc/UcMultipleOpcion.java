package com.mycompany.doctecnica.UI.uc;

import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Respuesta;

public class UcMultipleOpcion extends javax.swing.JPanel implements IUcPregunta{
    private Pregunta pregunta;

    public UcMultipleOpcion(Pregunta pregunta) {
        initComponents();
        this.pregunta = pregunta;
        this.cargarOpciones();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup = new javax.swing.ButtonGroup();
        rbOpcion4 = new javax.swing.JRadioButton();
        rbOpcion3 = new javax.swing.JRadioButton();
        rbOpcion1 = new javax.swing.JRadioButton();
        rbOpcion2 = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtEnunciado = new javax.swing.JTextArea();

        buttonGroup.add(rbOpcion4);
        rbOpcion4.setText("Correcta");

        buttonGroup.add(rbOpcion3);
        rbOpcion3.setText("Correcta");

        buttonGroup.add(rbOpcion1);
        rbOpcion1.setText("Correcta");
        rbOpcion1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbOpcion1ActionPerformed(evt);
            }
        });

        buttonGroup.add(rbOpcion2);
        rbOpcion2.setText("Correcta");

        txtEnunciado.setEditable(false);
        txtEnunciado.setBackground(new java.awt.Color(255, 255, 255));
        txtEnunciado.setColumns(20);
        txtEnunciado.setLineWrap(true);
        txtEnunciado.setRows(5);
        jScrollPane1.setViewportView(txtEnunciado);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 638, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbOpcion1)
                            .addComponent(rbOpcion2)
                            .addComponent(rbOpcion3)
                            .addComponent(rbOpcion4))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(rbOpcion1)
                .addGap(9, 9, 9)
                .addComponent(rbOpcion2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbOpcion3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbOpcion4)
                .addContainerGap(13, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void rbOpcion1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbOpcion1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbOpcion1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbOpcion1;
    private javax.swing.JRadioButton rbOpcion2;
    private javax.swing.JRadioButton rbOpcion3;
    private javax.swing.JRadioButton rbOpcion4;
    private javax.swing.JTextArea txtEnunciado;
    // End of variables declaration//GEN-END:variables

    private void cargarOpciones() {
        txtEnunciado.setText(pregunta.getEnunciado());
        int i = 0;
        for (Respuesta r : pregunta.getOpcionesRespuesta()) {
            if (i == 0) { rbOpcion1.setText(r.getTexto()); rbOpcion1.putClientProperty("resp", r);}
            else if (i == 1){ rbOpcion2.setText(r.getTexto()); rbOpcion2.putClientProperty("resp", r);}
            else if (i == 2){ rbOpcion3.setText(r.getTexto()); rbOpcion3.putClientProperty("resp", r);}
            else if (i == 3){ rbOpcion4.setText(r.getTexto()); rbOpcion4.putClientProperty("resp", r);}
            i++;
        }
    }

    @Override
    public Respuesta getRespuesta() {
        if (rbOpcion1.isSelected()) return (Respuesta) rbOpcion1.getClientProperty("resp");
        if (rbOpcion2.isSelected()) return (Respuesta) rbOpcion2.getClientProperty("resp");
        if (rbOpcion3.isSelected()) return (Respuesta) rbOpcion3.getClientProperty("resp");
        if (rbOpcion4.isSelected()) return (Respuesta) rbOpcion4.getClientProperty("resp");
        return null;
    }
}
