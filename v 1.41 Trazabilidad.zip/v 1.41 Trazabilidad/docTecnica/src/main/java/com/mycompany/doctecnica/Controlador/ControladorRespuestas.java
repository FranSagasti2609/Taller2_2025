package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.Model.Responde;
import com.mycompany.doctecnica.DAO.RespondeDAOImp;

public class ControladorRespuestas {
    
    RespondeDAOImp dao = new RespondeDAOImp();
    
    public boolean guardarRespuesta(Responde res){
        return dao.guardarRespuesta(res);
    }
}
