package com.mycompany.doctecnica.UI.uc;

import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Respuesta;

public class UcVerdaderoFalso extends javax.swing.JPanel implements IUcPregunta{
    private Pregunta pregunta;

    public UcVerdaderoFalso(Pregunta pregunta) {
        initComponents();
        this.pregunta = pregunta;
        this.cargarOpciones();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup = new javax.swing.ButtonGroup();
        rbOpcion1 = new javax.swing.JRadioButton();
        rbOpcion2 = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtEnunciado = new javax.swing.JTextArea();

        buttonGroup.add(rbOpcion1);
        rbOpcion1.setText("Verdadero");

        buttonGroup.add(rbOpcion2);
        rbOpcion2.setText("Falso");

        txtEnunciado.setEditable(false);
        txtEnunciado.setBackground(new java.awt.Color(255, 255, 255));
        txtEnunciado.setColumns(20);
        txtEnunciado.setLineWrap(true);
        txtEnunciado.setRows(5);
        jScrollPane1.setViewportView(txtEnunciado);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 638, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rbOpcion1)
                            .addComponent(rbOpcion2))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(15, 15, 15)
                .addComponent(rbOpcion1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(rbOpcion2)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbOpcion1;
    private javax.swing.JRadioButton rbOpcion2;
    private javax.swing.JTextArea txtEnunciado;
    // End of variables declaration//GEN-END:variables

    private void cargarOpciones(){
        Respuesta resp;
        
        this.txtEnunciado.setText(pregunta.getEnunciado());
        //Compruebo que sólo haya dos respuestas para el verdadero falso
        if(pregunta.getOpcionesRespuesta().size() ==2){
            resp = pregunta.getOpcionesRespuesta().get(0);//Obtengo la primera respuesta
            this.rbOpcion1.setText(resp.getTexto()); //Muestro el texto de la respuesta en el radioButton
            this.rbOpcion1.putClientProperty("resp", resp);//Se guarda en el radio butón la respuesta asociada. Se recupera con la llave 'resp'
            
            resp = pregunta.getOpcionesRespuesta().get(1); 
            this.rbOpcion2.setText(resp.getTexto());
            this.rbOpcion2.putClientProperty("resp", resp);
        }
        
    }
    
    @Override
    public Respuesta getRespuesta() {
        if(this.rbOpcion1.isSelected()){
            return (Respuesta)this.rbOpcion1.getClientProperty("resp");
        }
        return (Respuesta)this.rbOpcion2.getClientProperty("resp");
    }
}
