package com.mycompany.doctecnica.Controlador;

import com.mycompany.doctecnica.DAO.CuestionarioDAOImp;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Usuario;
import java.util.List;

public class ControladorCuestionario {
    
    CuestionarioDAOImp dao = new CuestionarioDAOImp();
    
    //Metodo para guardar cuestionario en la base de datos.
    public boolean guardarCuestionario(Cuestionario c){
        return dao.insertar(c);
    }
    
    public boolean borrarCuestionario(int idCuestionario) {
     return dao.eliminar(idCuestionario);
}
    
    public List<Cuestionario> cargarCuestionarios(){
        return dao.obtenerTodos();
    }
    
    public Cuestionario obtenerCuesPorId(int idCuestionario){
        return dao.obtenerPorId(idCuestionario);
        
    }
    
    public boolean actualizarCuestionario(Cuestionario c){
        return dao.actualizar(c);
    }
    
    public boolean asignarCuestionarioVariosEst(int idCuestionario, List<Usuario> estudiantes){
      return dao.asignarCuestionarioVariosEst(idCuestionario, estudiantes);
    }
    
    public List<Cuestionario> obtenerCuestionariosEst(int ci){
        return dao.obtenerCuestionariosAsignados(ci);
    }
    
    
}
