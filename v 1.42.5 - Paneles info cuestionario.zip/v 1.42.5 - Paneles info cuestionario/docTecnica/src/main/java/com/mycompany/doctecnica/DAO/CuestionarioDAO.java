package com.mycompany.doctecnica.DAO;

import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Usuario;
import java.util.List;

public interface CuestionarioDAO {
    public boolean insertar(Cuestionario c);
    public List<Cuestionario> obtenerTodos(); 
    public Cuestionario obtenerPorId (int idCuestionario);
    public boolean actualizar(Cuestionario c);
    public boolean eliminar(int idCuestionario);
    public List<Pregunta> obtenerPreguntasDeCuestionario(int idCuestionario);
    public boolean asignarCuestionarioVariosEst(int idCuestionario, List<Usuario> estudiantes);
    public boolean bajarIntentos(int nuevosIntentos);
    List<Cuestionario> obtenerCuestionariosAsignados(int ciEstudiante);

}
