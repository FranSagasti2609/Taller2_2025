package com.mycompany.doctecnica.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public abstract class Conexion {
    
    protected Connection conn;
    private final String DRIVER ="org.mariadb.jdbc.Driver";
    private final String USER = "evaluauser";
    private final String PASSWORD = "Evalua2025";
    private final String HOST = "localhost";
    private final String DB_NAME="evaluame";

    protected void conectar() throws SQLException {
        conn=null;
        String url = "jdbc:mariadb://" + HOST + ":3306/" + DB_NAME;
        try{
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(url, USER, PASSWORD);
        }
        catch (ClassNotFoundException ex) {
            System.out.print("ERROR: No se pudo encontrar el driver JDBC. Consulte un administrador.");
        }
        catch (SQLException ex) {
            throw new SQLException("ERROR: No se pudo conectar con la base de datos. Consulte un administrador.", ex);
        }  
        
    }
    
    protected void desconectar(){
        try{
            conn.close();
         
        }
        catch (Exception ex) {
            System.out.print("ERROR");
        }
    }
    /**
    *Ejecuta una sentencia de inserción, modificación o eliminación de datos en BBDD.
    * @param sql Sentencia a realizar del tipo INSERT, UPDATE o DELETE
    * @param parametros valores relacionados a la sentencia. 
    */
    protected void ejecutarSentencia(String sql, Object... parametros) throws SQLException{
        try{
            PreparedStatement stmt = conn.prepareStatement(sql);
            for(int i =0; i< parametros.length; i++){
                stmt.setObject(i+1, parametros[i]);
            }
            stmt.executeUpdate();
           
        }
        catch (SQLException ex) {
            throw ex;
        }
        
    }
    
    
    protected ResultSet ejecutarConsulta(String consulta, Object... parametros){
        ResultSet rs = null;
        try{
            PreparedStatement stmt = conn.prepareStatement(consulta);
            for(int i =0; i< parametros.length; i++){
                stmt.setObject(i+1, parametros[i]);
            }
            rs = stmt.executeQuery();
          
            
        }
        catch (Exception ex) {
            System.out.print("ERROR \n" + ex.getMessage());
        }
        return rs;
    }
}
