package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.Model.Nivel;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Responde;
import com.mycompany.doctecnica.Model.Respuesta;
import com.mycompany.doctecnica.Model.TipoPregunta;
import com.mycompany.doctecnica.UI.uc.IUcPregunta;
import com.mycompany.doctecnica.UI.uc.UcPreguntaCuestionario;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Controlador.ControladorRespuestas;
import com.mycompany.doctecnica.Controlador.ControladorPreguntasRespuestas;

import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import java.awt.Color;

public class PanelRealizarCuestionario extends javax.swing.JPanel {

    private Cuestionario cuest;
    private Usuario user;
    private List<Pregunta> preguntas;    
    private ControladorRespuestas controlRes = new ControladorRespuestas();
    ControladorPreguntasRespuestas controlPreg = new ControladorPreguntasRespuestas();
    private final List<IUcPregunta> componentesPregunta = new ArrayList<>();
    
    public PanelRealizarCuestionario(Usuario usuario, Cuestionario c) {
        this.user = usuario;
        this.cuest = c;
        initComponents();
        
        preguntas = cuest.getPreguntas(); //cargo las preguntas del cuest
        construirFormularioPreguntas();
    }

    private void construirFormularioPreguntas() {
    panelContenedorPreguntas.removeAll();
    panelContenedorPreguntas.setBackground(Color.WHITE);

    for (Pregunta p : cuest.getPreguntas()) {
        // Usamos SIEMPRE el UC unificado
        UcPreguntaCuestionario uc = new UcPreguntaCuestionario(p);
        panelContenedorPreguntas.add(uc);
        componentesPregunta.add(uc);   // importante para luego obtener las respuestas
        panelContenedorPreguntas.add(Box.createVerticalStrut(10));
        controlPreg.aumentarCantApariciones(p.getId_Pregunta()); //aumento aparicion
    }

    panelContenedorPreguntas.revalidate();
    panelContenedorPreguntas.repaint();
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        scrollCuestionario = new javax.swing.JScrollPane();
        panelContenedorPreguntas = new javax.swing.JPanel();
        btnFinalizar = new javax.swing.JButton();

        scrollCuestionario.setBackground(new java.awt.Color(255, 255, 255));

        panelContenedorPreguntas.setLayout(new javax.swing.BoxLayout(panelContenedorPreguntas, javax.swing.BoxLayout.Y_AXIS));
        scrollCuestionario.setViewportView(panelContenedorPreguntas);

        btnFinalizar.setBackground(new java.awt.Color(51, 204, 0));
        btnFinalizar.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        btnFinalizar.setForeground(new java.awt.Color(255, 255, 255));
        btnFinalizar.setText("Finalizar");
        btnFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollCuestionario, javax.swing.GroupLayout.PREFERRED_SIZE, 671, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGroup(layout.createSequentialGroup()
                .addGap(277, 277, 277)
                .addComponent(btnFinalizar))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(scrollCuestionario, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFinalizar)
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents


//cuando pulso el boton de finalizar deben almacenarse las respuestas...
    private void btnFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalizarActionPerformed
        // TODO add your handling code here:
        
        for(IUcPregunta com : componentesPregunta){
           Respuesta respuestaElegida = com.getRespuesta();

           if(respuestaElegida==null){
            JOptionPane.showMessageDialog(this, "Debes responder todas las preguntas antes de finalizar.","Pregunta sin responder",JOptionPane.WARNING_MESSAGE);
            return;  // corta la ejecución del botón
           }
           
           //Crear instancia de responde para cada pregunta
            Responde res = new Responde(respuestaElegida.getIdPregunta(), user.getCi(),respuestaElegida.esCorrecta());
            controlRes.guardarRespuesta(res);
            
            //Si la respuesta es correcta aumento en 1 canti_correctas de la pregunta (trazabilidad)
            if(respuestaElegida.esCorrecta()){
                controlPreg.aumentarCantCorrectas(respuestaElegida.getIdPregunta());}     
        }
        
        //Llamar a tabla asigna para bajar un intento y poner estado FINALIZADO

        //Mensaje de confirmacion de finalizacion
        JOptionPane.showMessageDialog(this, "Puedes ver tu nota en devoluciones. Has completado el cuestionario.");
    }//GEN-LAST:event_btnFinalizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFinalizar;
    private javax.swing.JPanel panelContenedorPreguntas;
    private javax.swing.JScrollPane scrollCuestionario;
    // End of variables declaration//GEN-END:variables
}
