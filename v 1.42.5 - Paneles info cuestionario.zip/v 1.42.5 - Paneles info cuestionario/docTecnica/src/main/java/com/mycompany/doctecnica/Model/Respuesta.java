package com.mycompany.doctecnica.Model;

public class Respuesta {
    private int id_Respuesta;
    private String enunciado;       //Ejemplo: "Es un lenguaje de programacion"
    private boolean esCorrecta;
    private int idPregunta; // referencia a la pregunta, es FK
    
    // Constructor vacío
    public Respuesta() {}

    // Constructor con parámetros
    public Respuesta(String texto, boolean esCorrecta, int idPregunta) {
        this.enunciado = texto;
        this.esCorrecta = esCorrecta;
        this.idPregunta = idPregunta;
    }

    // Getters y Setters
    public int getId() {
        return id_Respuesta;
    }

    public String getTexto() {
        return enunciado;
    }

    public void setTexto(String texto) {
        this.enunciado = texto;
    }

    public boolean esCorrecta() {
        return esCorrecta;
    }

    public void setEsCorrecta(boolean esCorrecta) {
        this.esCorrecta = esCorrecta;
    }
    
    public int getIdPregunta() { 
        return idPregunta; 
    }
    public void setIdPregunta(int idPregunta) { 
        this.idPregunta = idPregunta; 
    }
}
