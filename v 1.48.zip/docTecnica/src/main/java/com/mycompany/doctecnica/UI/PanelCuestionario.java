package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Model.Cuestionario;
import com.mycompany.doctecnica.Controlador.ControladorPreguntasRespuestas;
import com.mycompany.doctecnica.Controlador.ControladorCuestionario;
import com.mycompany.doctecnica.Controlador.ControladorPrincipal;
import com.mycompany.doctecnica.Model.Grupo;
import java.util.List;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.*;
import com.mycompany.doctecnica.Model.Pregunta;
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

public class PanelCuestionario extends javax.swing.JPanel {

    private Usuario usuario;
    private ControladorPreguntasRespuestas controlador = new ControladorPreguntasRespuestas();
    private ControladorCuestionario controladorCues = new ControladorCuestionario();
    private ControladorPrincipal controladorMain = new ControladorPrincipal();
    private JFrame parentFrame;
    private Cuestionario cuestionario = new Cuestionario(); //creamos cuestionario (objeto)
    private List<Pregunta> preguntasSeleccionadas = new ArrayList<>();
    private Grupo grupo;
    List<Usuario> seleccionados; //estudiantes sedleccionados en el JDialog
    
    public PanelCuestionario(Usuario user, JFrame parentFrame) {
        initComponents();
        
       TablaModificar.getTableHeader().setOpaque(false);
       TablaModificar.getTableHeader().setBackground(new Color(32,136,203));
       TablaModificar.getTableHeader().setForeground(new Color(255,255,255));
       TablaModificar.setRowHeight(25);
       
       TablaBorrar.getTableHeader().setOpaque(false);
       TablaBorrar.getTableHeader().setBackground(new Color(32,136,203));
       TablaBorrar.getTableHeader().setForeground(new Color(255,255,255));
       TablaBorrar.setRowHeight(25);
       
       TablaAsignar.getTableHeader().setOpaque(false);
       TablaAsignar.getTableHeader().setBackground(new Color(32,136,203));
       TablaAsignar.getTableHeader().setForeground(new Color(255,255,255));
       TablaAsignar.setRowHeight(25);
       
        this.usuario = user;
        this.parentFrame = parentFrame;
        configurarTabla(TablaAsignar);
        configurarTabla(TablaModificar);
        configurarTabla(TablaBorrar);
        cargarTabla(TablaBorrar);
        cargarTabla(TablaModificar);
        cargarTabla(TablaAsignar);
        
        cargarTemasCombo(); //agrego temas random
        
        //Si se selecciona modalidad random aparece el spiner para setear la cantidad de preguntas
    ModalidadComboBox.addActionListener(new java.awt.event.ActionListener() {
    public void actionPerformed(java.awt.event.ActionEvent evt) {
        String modalidad = (String) ModalidadComboBox.getSelectedItem();

        if ("Aleatorio".equals(modalidad)) {
            PreguntasLabel1.setVisible(true);
            SpinnerPreguntas.setVisible(true);
            TemaRandomLabel.setVisible(true);
            TemaComboBox.setVisible(true);
            String temaSeleccionado = (String) TemaComboBox.getSelectedItem();

        } else {
            //Oculto los widgets de la ventana
            TemaRandomLabel.setVisible(false);
            SpinnerPreguntas.setVisible(false);
            PreguntasLabel1.setVisible(false);
            TemaComboBox.setVisible(false);
        }
        
         if ("Estatico".equals(modalidad)) {
            SeleccionPreguntas dialog = new SeleccionPreguntas(parentFrame, true);
            dialog.setVisible(true);
             preguntasSeleccionadas = dialog.getPreguntasSeleccionadas();
             if (preguntasSeleccionadas == null || preguntasSeleccionadas.isEmpty()) {

            JOptionPane.showMessageDialog(parentFrame, "Debe seleccionar al menos una pregunta.");
            return;
            }else{
                 JOptionPane.showMessageDialog(parentFrame, "Has seleccionado correctamente " + preguntasSeleccionadas.size() + " preguntas.");
             }
         cuestionario.setPreguntas(preguntasSeleccionadas);
        } 
    }
});
    }

       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        BackGroundGreen = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        LabelPrincipal = new javax.swing.JLabel();
        TabbedPane = new javax.swing.JTabbedPane();
        CrearCuestionarioPanel = new javax.swing.JPanel();
        PanelCrearScroll = new javax.swing.JScrollPane();
        PanelCrearCuestionario = new javax.swing.JPanel();
        TituloField = new javax.swing.JTextField();
        TituloLabel1 = new javax.swing.JLabel();
        RetroalimentacionLabel = new javax.swing.JLabel();
        SpinnerPreguntas = new javax.swing.JSpinner();
        IntentosLabel1 = new javax.swing.JLabel();
        RetroalimentacionComboBox = new javax.swing.JComboBox<>();
        TemaRandomLabel = new javax.swing.JLabel();
        ModalidadComboBox = new javax.swing.JComboBox<>();
        BotonCrearCuestionario = new javax.swing.JButton();
        SpinnerIntentos = new javax.swing.JSpinner();
        ModalidadLabel2 = new javax.swing.JLabel();
        PreguntasLabel1 = new javax.swing.JLabel();
        TemaComboBox = new javax.swing.JComboBox<>();
        ModificarPanel = new javax.swing.JPanel();
        ModBoton = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        TablaModificar = new javax.swing.JTable();
        BorrarCuestionario = new javax.swing.JPanel();
        BorrarBoton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TablaBorrar = new javax.swing.JTable();
        AsignarCuestionario = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        TablaAsignar = new javax.swing.JTable();
        AsignarBoton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();

        jLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        jLabel1.setText("Listado de estudiantes del sistema");

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Titulo", "Tema", "Tipo"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LabelPrincipal.setFont(new java.awt.Font("Dubai", 0, 20)); // NOI18N
        LabelPrincipal.setForeground(new java.awt.Color(0, 0, 204));
        LabelPrincipal.setText("Apartado de cuestionarios");
        add(LabelPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 2, -1, -1));

        TabbedPane.setBackground(new java.awt.Color(153, 255, 153));
        TabbedPane.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        TabbedPane.setOpaque(true);

        PanelCrearScroll.setBackground(new java.awt.Color(255, 255, 255));

        PanelCrearCuestionario.setBackground(new java.awt.Color(255, 255, 255));
        PanelCrearCuestionario.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TituloField.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        TituloField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        PanelCrearCuestionario.add(TituloField, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 80, 514, -1));

        TituloLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        TituloLabel1.setText("Titulo");
        PanelCrearCuestionario.add(TituloLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 80, -1, -1));

        RetroalimentacionLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        RetroalimentacionLabel.setText("Retroalimentacion");
        PanelCrearCuestionario.add(RetroalimentacionLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, -1, -1));

        SpinnerPreguntas.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        SpinnerPreguntas.setModel(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));
        SpinnerPreguntas.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        SpinnerPreguntas.setValue(1);
        PanelCrearCuestionario.add(SpinnerPreguntas, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 180, 130, -1));
        SpinnerPreguntas.setVisible(false);

        IntentosLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        IntentosLabel1.setText("Cantidad de intentos");
        PanelCrearCuestionario.add(IntentosLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 130, -1, -1));

        RetroalimentacionComboBox.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        RetroalimentacionComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Calificacion numerica", "Detallada" }));
        PanelCrearCuestionario.add(RetroalimentacionComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 230, -1, -1));

        TemaRandomLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        TemaRandomLabel.setText("Tema");
        PanelCrearCuestionario.add(TemaRandomLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 230, -1, -1));
        TemaRandomLabel.setVisible(false);

        ModalidadComboBox.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        ModalidadComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Estatico", "Aleatorio", "Adaptativo" }));
        ModalidadComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModalidadComboBoxActionPerformed(evt);
            }
        });
        PanelCrearCuestionario.add(ModalidadComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 180, -1, -1));

        BotonCrearCuestionario.setBackground(new java.awt.Color(153, 255, 153));
        BotonCrearCuestionario.setFont(new java.awt.Font("Dubai", 1, 14)); // NOI18N
        BotonCrearCuestionario.setText("Crear");
        BotonCrearCuestionario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCrearCuestionarioActionPerformed(evt);
            }
        });
        PanelCrearCuestionario.add(BotonCrearCuestionario, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 300, -1, -1));

        SpinnerIntentos.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        SpinnerIntentos.setModel(new SpinnerNumberModel(1, 1, Integer.MAX_VALUE, 1));
        SpinnerIntentos.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        SpinnerIntentos.setValue(1);
        PanelCrearCuestionario.add(SpinnerIntentos, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 130, 130, -1));

        ModalidadLabel2.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        ModalidadLabel2.setText("Modalidad");
        PanelCrearCuestionario.add(ModalidadLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 180, -1, -1));

        PreguntasLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        PreguntasLabel1.setText("Cantidad preguntas");
        PanelCrearCuestionario.add(PreguntasLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 180, -1, -1));
        PreguntasLabel1.setVisible(false);

        TemaComboBox.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        PanelCrearCuestionario.add(TemaComboBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 230, -1, -1));
        TemaComboBox.setVisible(false);

        PanelCrearScroll.setViewportView(PanelCrearCuestionario);

        javax.swing.GroupLayout CrearCuestionarioPanelLayout = new javax.swing.GroupLayout(CrearCuestionarioPanel);
        CrearCuestionarioPanel.setLayout(CrearCuestionarioPanelLayout);
        CrearCuestionarioPanelLayout.setHorizontalGroup(
            CrearCuestionarioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelCrearScroll, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
        );
        CrearCuestionarioPanelLayout.setVerticalGroup(
            CrearCuestionarioPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelCrearScroll, javax.swing.GroupLayout.DEFAULT_SIZE, 423, Short.MAX_VALUE)
        );

        TabbedPane.addTab("Crear", CrearCuestionarioPanel);

        ModificarPanel.setBackground(new java.awt.Color(255, 255, 255));

        ModBoton.setBackground(new java.awt.Color(51, 204, 0));
        ModBoton.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        ModBoton.setForeground(new java.awt.Color(255, 255, 255));
        ModBoton.setText("Modificar");
        ModBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModBotonActionPerformed(evt);
            }
        });

        TablaModificar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Titulo", "Modalidad", "Retroalimentacion"
            }
        ));
        TablaModificar.setFocusable(false);
        TablaModificar.setRowHeight(25);
        TablaModificar.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaModificar.setSelectionForeground(new java.awt.Color(255, 255, 255));
        jScrollPane3.setViewportView(TablaModificar);

        javax.swing.GroupLayout ModificarPanelLayout = new javax.swing.GroupLayout(ModificarPanel);
        ModificarPanel.setLayout(ModificarPanelLayout);
        ModificarPanelLayout.setHorizontalGroup(
            ModificarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
            .addGroup(ModificarPanelLayout.createSequentialGroup()
                .addGap(294, 294, 294)
                .addComponent(ModBoton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        ModificarPanelLayout.setVerticalGroup(
            ModificarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ModificarPanelLayout.createSequentialGroup()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(ModBoton)
                .addGap(12, 12, 12))
        );

        TabbedPane.addTab("Modificar", ModificarPanel);

        BorrarCuestionario.setBackground(new java.awt.Color(255, 255, 255));

        BorrarBoton.setBackground(new java.awt.Color(255, 102, 102));
        BorrarBoton.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        BorrarBoton.setText("Borrar");
        BorrarBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrarBotonActionPerformed(evt);
            }
        });

        TablaBorrar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Titulo", "Modalidad", "Retroalimentacion"
            }
        ));
        TablaBorrar.setFocusable(false);
        TablaBorrar.setRowHeight(25);
        TablaBorrar.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaBorrar.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaBorrar.setShowVerticalLines(true);
        jScrollPane1.setViewportView(TablaBorrar);

        javax.swing.GroupLayout BorrarCuestionarioLayout = new javax.swing.GroupLayout(BorrarCuestionario);
        BorrarCuestionario.setLayout(BorrarCuestionarioLayout);
        BorrarCuestionarioLayout.setHorizontalGroup(
            BorrarCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
            .addGroup(BorrarCuestionarioLayout.createSequentialGroup()
                .addGap(292, 292, 292)
                .addComponent(BorrarBoton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        BorrarCuestionarioLayout.setVerticalGroup(
            BorrarCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BorrarCuestionarioLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(BorrarBoton)
                .addContainerGap())
        );

        TabbedPane.addTab("Borrar", BorrarCuestionario);

        AsignarCuestionario.setBackground(new java.awt.Color(255, 255, 255));

        TablaAsignar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Titulo", "Modalidad", "Retroalimentacion"
            }
        ));
        TablaAsignar.setFocusable(false);
        TablaAsignar.setRowHeight(25);
        TablaAsignar.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaAsignar.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaAsignar.setShowVerticalLines(true);
        jScrollPane4.setViewportView(TablaAsignar);

        AsignarBoton.setBackground(new java.awt.Color(51, 204, 0));
        AsignarBoton.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N
        AsignarBoton.setForeground(new java.awt.Color(255, 255, 255));
        AsignarBoton.setText("Asignar");
        AsignarBoton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AsignarBotonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout AsignarCuestionarioLayout = new javax.swing.GroupLayout(AsignarCuestionario);
        AsignarCuestionario.setLayout(AsignarCuestionarioLayout);
        AsignarCuestionarioLayout.setHorizontalGroup(
            AsignarCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
            .addGroup(AsignarCuestionarioLayout.createSequentialGroup()
                .addGap(291, 291, 291)
                .addComponent(AsignarBoton)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        AsignarCuestionarioLayout.setVerticalGroup(
            AsignarCuestionarioLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AsignarCuestionarioLayout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 379, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(AsignarBoton)
                .addContainerGap(10, Short.MAX_VALUE))
        );

        TabbedPane.addTab("Asignar", AsignarCuestionario);

        add(TabbedPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 670, 460));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/greenBackSCALED.jpg"))); // NOI18N
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void BorrarBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrarBotonActionPerformed
        // TODO add your handling code here:
        int fila = TablaBorrar.getSelectedRow();
        if (fila == -1) {
        JOptionPane.showMessageDialog(this, "Selecciona un cuestionario de la tabla");
        return;}
        
        //Obtengo el id del cuestionario
        int idCuestionario = Integer.parseInt(TablaBorrar.getValueAt(fila, 0).toString());
        int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar este cuestionario?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirmacion != JOptionPane.YES_OPTION) {
        return;
        }
        
        boolean eliminado = controladorCues.borrarCuestionario(idCuestionario);
        if (eliminado) {
            JOptionPane.showMessageDialog(this, "Cuestionario eliminado correctamente.");
         } else {
        JOptionPane.showMessageDialog(this, "No se pudo eliminar el cuestionario");
         }
        
        //Refrescamos la tablas
        cargarTabla(TablaAsignar);
        cargarTabla(TablaModificar);
        cargarTabla(TablaBorrar);
    
    }//GEN-LAST:event_BorrarBotonActionPerformed

    private DefaultTableModel crearModeloCuestionarios() {
    return new DefaultTableModel(
        new Object[]{"ID", "Titulo", "Modalidad", "Retroalimentacion"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
}
    
      
    private void ModBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModBotonActionPerformed
        // TODO add your handling code here:
        int fila = TablaModificar.getSelectedRow();
        if(fila == -1){
            JOptionPane.showMessageDialog(this, "Selecciona un cuestionario de la tabla.");
        return;
        }
        
        //Obtengo el id del cuestionario y traigo el cuestionario desde la BD
        int idCuestionario = Integer.parseInt(TablaModificar.getValueAt(fila, 0).toString());
        Cuestionario c = controladorCues.obtenerCuesPorId(idCuestionario);
            if (c == null) {
        JOptionPane.showMessageDialog(this, "No se encontró el cuestionario en la BD.");
        return;
        }
            
       // Cargar los datos en el formulario de creación
        TituloField.setText(c.getTitulo());
        //TemaComboBox.setSelectedItem(c.getTema()); 
        ModalidadComboBox.setSelectedItem(c.getModalidad());
        RetroalimentacionComboBox.setSelectedItem(c.getRetroalimentacion());
        SpinnerIntentos.setValue(c.getCantIntentos());
    if ("Aleatorio".equals(c.getModalidad())) {
        TemaRandomLabel.setVisible(true);
        SpinnerPreguntas.setVisible(true);
        TemaRandomLabel.setVisible(true);
        TemaComboBox.setVisible(true);
        SpinnerPreguntas.setValue(c.getCantidadPreguntasAleatorias());
        TemaRandomLabel.setVisible(true);
        TemaComboBox.setVisible(true);
    } else {
            //Oculto los widgets de la ventana
            TemaRandomLabel.setVisible(false);
            SpinnerPreguntas.setVisible(false);
            PreguntasLabel1.setVisible(false);
            TemaComboBox.setVisible(false);
    }

    //Cambiar a la pestaña de Crear
    TabbedPane.setSelectedComponent(CrearCuestionarioPanel);

    // Marcar el botón en modo actualización
    BotonCrearCuestionario.putClientProperty("modo", "update");
    BotonCrearCuestionario.putClientProperty("idCuestionario", idCuestionario);
    BotonCrearCuestionario.setText("Actualizar cuestionario");
        
        cargarTabla(TablaAsignar);
        cargarTabla(TablaModificar);
        cargarTabla(TablaBorrar);
    }//GEN-LAST:event_ModBotonActionPerformed

    private void BotonCrearCuestionarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCrearCuestionarioActionPerformed
        // TODO add your handling code here:
        String tituloCuestionario = TituloField.getText().trim();
        if (tituloCuestionario.isEmpty()) {
            JOptionPane.showMessageDialog(this, "El título es obligatorio.");
            return;
         }
        
        cuestionario.setTitulo(tituloCuestionario);
        cuestionario.setModalidad(ModalidadComboBox.getSelectedItem().toString());
        cuestionario.setCiUsuario(usuario.getCi());
        cuestionario.setRetroalimentacion(RetroalimentacionComboBox.getSelectedItem().toString());
        cuestionario.setCantIntentos((int)SpinnerIntentos.getValue());
        
        
        // Asignar el valor de la cantidad de preguntas aleatorias
        if ("Aleatorio".equals(ModalidadComboBox.getSelectedItem().toString())) {
            cuestionario.setCantidadPreguntasAleatorias((int) SpinnerPreguntas.getValue());
            //Recupero tema, si hay uno electo lo asigno al cuestionario
            int cantidad = (int) SpinnerPreguntas.getValue();
            String temaSeleccionado = TemaComboBox.getSelectedItem().toString();
            
            List<Pregunta> preguntasRandom = controlador.recuperarPreguntasRandom(cantidad, temaSeleccionado);
            if(preguntasRandom.isEmpty() || preguntasRandom == null){ //sino hay preguntas salgo
                return;
            }
            if(!"Todos".equals(TemaComboBox.getSelectedItem().toString())){
                cuestionario.setTemaFiltro(temaSeleccionado);
            }else cuestionario.setTemaFiltro("Todos"); //TEMA DEFAULT todos
            //Asigno las preguntas random al cuestionario
            cuestionario.setPreguntas(preguntasRandom);
            
        } else {
        cuestionario.setCantidadPreguntasAleatorias(0);
         cuestionario.setTemaFiltro(null); //sino es aleatorio dejamos el campo vacio
        }
       
        
        if("Estatico".equals(ModalidadComboBox.getSelectedItem().toString())){
            if (cuestionario.getPreguntas() == null || cuestionario.getPreguntas().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar al menos una pregunta para un cuestionario estático.");
            return;
    }
            cuestionario.setPreguntas(preguntasSeleccionadas);
        }
        
        //Dado que esta ventana se recicla para crear y actualizar usamos un "modo" para saber la operación
        String modo = (String) BotonCrearCuestionario.getClientProperty("modo");
        if ("update".equals(modo)) {
            int id = (int) BotonCrearCuestionario.getClientProperty("idCuestionario");
            cuestionario.setId_Cuestionario(id);
         boolean actualizado = controladorCues.actualizarCuestionario(cuestionario);
         //Mensajes en base al exito o fracaso de la update del cuest.
        if (actualizado) {
            JOptionPane.showMessageDialog(this, "Cuestionario actualizado con éxito.");
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo actualizar el cuestionario.");
        }

        // Resetear botón
        BotonCrearCuestionario.putClientProperty("modo", "create");
        BotonCrearCuestionario.setText("Crear");

    } else {
         boolean creado = controladorCues.guardarCuestionario(cuestionario);
        if (creado) {
            JOptionPane.showMessageDialog(this, "Cuestionario creado con éxito.");
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo crear el cuestionario.");
        }
    }
    
    limpiarFormulario();
    cargarTabla(TablaAsignar);
    cargarTabla(TablaModificar);
    cargarTabla(TablaBorrar);
    }//GEN-LAST:event_BotonCrearCuestionarioActionPerformed

    private void AsignarBotonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AsignarBotonActionPerformed
        // TODO add your handling code here:
        int fila = TablaAsignar.getSelectedRow();
        if(fila == -1){
            JOptionPane.showMessageDialog(this, "Selecciona un cuestionario de la tabla.");
        return;
        }
        
        int idCuestionario = Integer.parseInt(TablaAsignar.getValueAt(fila, 0).toString());
        mostrarGruposDelDocente(idCuestionario); 
           
    }//GEN-LAST:event_AsignarBotonActionPerformed

    private void ModalidadComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModalidadComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ModalidadComboBoxActionPerformed

    private void mostrarGruposDelDocente(int idCuestionario){
     
        JPanel panelGrupos = new JPanel();
        panelGrupos.setLayout(new BoxLayout(panelGrupos, BoxLayout.Y_AXIS));
        panelGrupos.setBackground(Color.WHITE);
        List<Grupo> gruposDocente = controladorMain.obtenerGrupoPorCI(usuario.getCi());
        
        if(gruposDocente.isEmpty()){ //sino tengo grupos muestro un mensaje
        JLabel lbl = new JLabel("No tienes grupos creados.");
        lbl.setAlignmentX(CENTER_ALIGNMENT);
        panelGrupos.add(lbl);
        } else {
            //Agrego un titulo y los botones
                    TituloLabel1 = new javax.swing.JLabel();
                    TituloLabel1.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
                    TituloLabel1.setText("Grupos para asignar el cuestionario");
                    panelGrupos.add(TituloLabel1);

            for (Grupo g : gruposDocente) {
            JButton btn = new JButton(g.getNombre());
            btn.setAlignmentX(CENTER_ALIGNMENT); // para centrarlo en BoxLayout
            
            btn.addActionListener(e -> {//al cliquear un boton pasara que abro el Jdialog con los estudiantes a seleccionar
                SeleccionEstudiantesDialog dialog = new SeleccionEstudiantesDialog(
                        parentFrame, true, g, idCuestionario);
                dialog.setVisible(true);
               // Al volver, obtengo la lista seleccionada
            List<Usuario> seleccionados = dialog.getEstudiantesMarcados();

            Cuestionario cuesti = controladorCues.obtenerCuesPorId(idCuestionario);
        if (seleccionados != null && !seleccionados.isEmpty()) {
            boolean ok = controladorCues.asignarCuestionarioVariosEst(idCuestionario, seleccionados, cuesti);
        if (ok) {
            JOptionPane.showMessageDialog(parentFrame,
                    "Cuestionario asignado a " + seleccionados.size() + " estudiantes.");
        } else {
            JOptionPane.showMessageDialog(parentFrame,
                    "Error al asignar el cuestionario.");
        }
    } else {
        JOptionPane.showMessageDialog(parentFrame,
                "No seleccionaste ningún estudiante para este grupo.");
    }
                        
            });
            //Personalizamos colores del boton
            btn.setForeground(Color.WHITE);
            btn.setBackground(new Color(51, 204, 0));
            
           panelGrupos.add(btn);
            panelGrupos.add(Box.createVerticalStrut(5)); // espacio entre botones
        }
        }
        
        
        jScrollPane4.setViewportView(panelGrupos);
        jScrollPane4.revalidate();
        jScrollPane4.repaint();
    }
    
     private void configurarTabla(JTable tabla) {
    // Configurar modelo
    DefaultTableModel modelo = crearModeloCuestionarios();
    tabla.setModel(modelo);

    // Ocultar la columna de ID
    tabla.getColumnModel().getColumn(0).setMinWidth(0);
    tabla.getColumnModel().getColumn(0).setMaxWidth(0);
    tabla.getColumnModel().getColumn(0).setWidth(0);

    tabla.setAutoCreateRowSorter(true);
}

    private void cargarTabla(JTable tabla) {
    DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
    modelo.setRowCount(0); // limpiar

    List<Cuestionario> cuestionarios = controladorCues.cargarCuestionarios();
    for (Cuestionario c : cuestionarios) {
        modelo.addRow(new Object[]{
            c.getId_Cuestionario(),
            c.getTitulo(),
            c.getModalidad(),
            c.getRetroalimentacion()
        });
    }
}
    private void limpiarFormulario() {
    // Vaciar el campo de título
    TituloField.setText("");

        // Resetear combo de retroalimentación al primero
    if (RetroalimentacionComboBox.getItemCount() > 0) {
        RetroalimentacionComboBox.setSelectedIndex(0);
    }

    // Reiniciar cantidad de intentos a 1
    SpinnerIntentos.setValue(1);

    // Reiniciar cantidad de preguntas aleatorias a 1 y ocultar spinner
    SpinnerPreguntas.setValue(1);
    SpinnerPreguntas.setVisible(false);
    TemaRandomLabel.setVisible(false);
}
    
    private void cargarTemasCombo(){
        List<String> temas = controlador.recuperarTemas();
        TemaComboBox.removeAllItems();
        TemaComboBox.addItem("Todos"); // opción especial
        
        for(String tema : temas){
            TemaComboBox.addItem(tema);
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton AsignarBoton;
    private javax.swing.JPanel AsignarCuestionario;
    private javax.swing.JLabel BackGroundGreen;
    private javax.swing.JButton BorrarBoton;
    private javax.swing.JPanel BorrarCuestionario;
    private javax.swing.JButton BotonCrearCuestionario;
    private javax.swing.JPanel CrearCuestionarioPanel;
    private javax.swing.JLabel IntentosLabel1;
    private javax.swing.JLabel LabelPrincipal;
    private javax.swing.JButton ModBoton;
    private javax.swing.JComboBox<String> ModalidadComboBox;
    private javax.swing.JLabel ModalidadLabel2;
    private javax.swing.JPanel ModificarPanel;
    private javax.swing.JPanel PanelCrearCuestionario;
    private javax.swing.JScrollPane PanelCrearScroll;
    private javax.swing.JLabel PreguntasLabel1;
    private javax.swing.JComboBox<String> RetroalimentacionComboBox;
    private javax.swing.JLabel RetroalimentacionLabel;
    private javax.swing.JSpinner SpinnerIntentos;
    private javax.swing.JSpinner SpinnerPreguntas;
    private javax.swing.JTabbedPane TabbedPane;
    private javax.swing.JTable TablaAsignar;
    private javax.swing.JTable TablaBorrar;
    private javax.swing.JTable TablaModificar;
    private javax.swing.JComboBox<String> TemaComboBox;
    private javax.swing.JLabel TemaRandomLabel;
    private javax.swing.JTextField TituloField;
    private javax.swing.JLabel TituloLabel1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable jTable2;
    // End of variables declaration//GEN-END:variables
}
