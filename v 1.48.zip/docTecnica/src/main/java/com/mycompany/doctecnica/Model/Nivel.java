package com.mycompany.doctecnica.Model;

public enum Nivel {
    //asigno numeros para posterior mapeo con la base de datos, que lo guarda como INT.
    FACIL(0),
    MEDIO(1),
    DIFICIL(2);

    private final int valor;

    Nivel(int valor) {
        this.valor = valor;
    }

    public int getValor() {
        return valor;
    }

    public static Nivel fromInt(int valor) {
        for (Nivel n : values()) {
            if (n.getValor() == valor) return n;
        }
        throw new IllegalArgumentException("Valor inválido para Nivel: " + valor);
    }
    
    public static Nivel fromString(String nombre) {
    switch (nombre.toLowerCase()) {
        case "facil": return FACIL;
        case "medio": return MEDIO;
        case "dificil": return DIFICIL;
        default: throw new IllegalArgumentException("Nombre inválido para Nivel: " + nombre);
    }
    }

}

