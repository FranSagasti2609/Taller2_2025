package com.mycompany.doctecnica.UI;

import com.mycompany.doctecnica.DAO.PreguntaDAOImp;
import com.mycompany.doctecnica.DAO.RespuestaDAOImp;
import com.mycompany.doctecnica.Controlador.ControladorPreguntasRespuestas;

import java.awt.Color;
import javax.swing.*;
import com.mycompany.doctecnica.Model.Usuario;
import com.mycompany.doctecnica.Model.Nivel;
import com.mycompany.doctecnica.Model.TipoPregunta;
import com.mycompany.doctecnica.Model.Pregunta;
import com.mycompany.doctecnica.Model.Respuesta;
import java.util.List;
import java.util.ArrayList;
import java.awt.Component;
import javax.swing.table.DefaultTableModel;

public class PanelPreguntas extends javax.swing.JPanel {

    private ButtonGroup grupoRespuestas;
    private Usuario usuario; //toma el usuario para la cedula, a la hora de guardar preguntas
    private DefaultTableModel modeloTablaBorrar;
    private DefaultTableModel modeloTablaMetricas;
    private DefaultTableModel modeloTablaModificar;
    ControladorPreguntasRespuestas controlador = new ControladorPreguntasRespuestas();

    public PanelPreguntas(Usuario user) {
        initComponents();
        this.usuario = user;
        PanelRespuestas.setLayout(new java.awt.GridLayout(0, 2, 10, 10));

        cargarTemasEnCombo(); //traigo los temas de la BD para implementarlos en el comboBOX
        cargarTipo();
        cargarNivel();

        TablaModificar.getTableHeader().setOpaque(false);
        TablaModificar.getTableHeader().setBackground(new Color(32, 136, 203));
        TablaModificar.getTableHeader().setForeground(new Color(255, 255, 255));
        TablaModificar.setRowHeight(25);

        TablaMetricas.getTableHeader().setOpaque(false);
        TablaMetricas.getTableHeader().setBackground(new Color(32, 136, 203));
        TablaMetricas.getTableHeader().setForeground(new Color(255, 255, 255));
        TablaMetricas.setRowHeight(25);

        TablaBorrar.getTableHeader().setOpaque(false);
        TablaBorrar.getTableHeader().setBackground(new Color(32, 136, 203));
        TablaBorrar.getTableHeader().setForeground(new Color(255, 255, 255));
        TablaBorrar.setRowHeight(25);
        //Le doy forma a la tabla y cargo datos
        configurarTablaBorrar();
        cargarPreguntasBorrar();

        //Damos forma a tabla y cargamos datos a la tabla metricas
        configurarTablaMetricas();
        cargarTablaMetricas();

        //Damos forma a tabla y cargamos datos a la tabla de modificar
        configurarTablaModificar();
        cargarTablaModificar();

        // Listener para cuando cambie el tipo de pregunta
//        TipoComboBox.addActionListener(e -> {
//        String seleccionado = (String) TipoComboBox.getSelectedItem();
//        if ("Verdadero o falso".equals(seleccionado)) {
//            inicializarRespuestas(2);   // solo 2 respuestas
//        } else if ("Multiple opcion".equals(seleccionado)) {
//            inicializarRespuestas(4);   // 4 respuestas
//        }
//    });
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        LabelPrincipal = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        PanelCrearPregunta = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        CrearPregunta = new javax.swing.JPanel();
        TipoLabel = new javax.swing.JLabel();
        TemaLabel = new javax.swing.JLabel();
        EnunciadoLabel = new javax.swing.JLabel();
        NivelLabel = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        TipoComboBox = new javax.swing.JComboBox<>();
        NivelComboBox = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        EnunciadoBox = new javax.swing.JTextArea();
        RespuestaLabel = new javax.swing.JLabel();
        PanelRespuestas = new javax.swing.JPanel();
        BotonCrear = new javax.swing.JButton();
        PanelModPregunta = new javax.swing.JPanel();
        modificarPregunta = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        TablaModificar = new javax.swing.JTable();
        PanelAnalisisPregunta = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        TablaMetricas = new javax.swing.JTable();
        PanelBorrarPregunta = new javax.swing.JPanel();
        BorrarPregunta = new javax.swing.JButton();
        TablaPreguntas = new javax.swing.JScrollPane();
        TablaBorrar = new javax.swing.JTable();
        BackGroundGreen = new javax.swing.JLabel();

        setBackground(new java.awt.Color(255, 255, 255));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        LabelPrincipal.setFont(new java.awt.Font("Dubai", 0, 20)); // NOI18N
        LabelPrincipal.setForeground(new java.awt.Color(0, 0, 204));
        LabelPrincipal.setText("Apartado de preguntas");
        add(LabelPrincipal, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 2, -1, -1));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/preguntaIcono.png"))); // NOI18N
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 10, -1, -1));

        jTabbedPane1.setBackground(new java.awt.Color(153, 255, 153));
        jTabbedPane1.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        jTabbedPane1.setOpaque(true);

        PanelCrearPregunta.setBackground(new java.awt.Color(255, 255, 255));

        CrearPregunta.setBackground(new java.awt.Color(255, 255, 255));

        TipoLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        TipoLabel.setText("Tipo");

        TemaLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        TemaLabel.setText("Tema");

        EnunciadoLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        EnunciadoLabel.setText("Enunciado");

        NivelLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        NivelLabel.setText("Nivel");

        jComboBox1.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        TipoComboBox.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        TipoComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        TipoComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                TipoComboBoxItemStateChanged(evt);
            }
        });

        NivelComboBox.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        NivelComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        EnunciadoBox.setColumns(20);
        EnunciadoBox.setRows(5);
        jScrollPane2.setViewportView(EnunciadoBox);

        RespuestaLabel.setFont(new java.awt.Font("Dubai", 0, 18)); // NOI18N
        RespuestaLabel.setText("Respuestas");

        PanelRespuestas.setBackground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout PanelRespuestasLayout = new javax.swing.GroupLayout(PanelRespuestas);
        PanelRespuestas.setLayout(PanelRespuestasLayout);
        PanelRespuestasLayout.setHorizontalGroup(
            PanelRespuestasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 631, Short.MAX_VALUE)
        );
        PanelRespuestasLayout.setVerticalGroup(
            PanelRespuestasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 345, Short.MAX_VALUE)
        );

        BotonCrear.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        BotonCrear.setText("Crear pregunta");
        BotonCrear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonCrearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout CrearPreguntaLayout = new javax.swing.GroupLayout(CrearPregunta);
        CrearPregunta.setLayout(CrearPreguntaLayout);
        CrearPreguntaLayout.setHorizontalGroup(
            CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CrearPreguntaLayout.createSequentialGroup()
                .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CrearPreguntaLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(PanelRespuestas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(RespuestaLabel)
                                .addGroup(CrearPreguntaLayout.createSequentialGroup()
                                    .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CrearPreguntaLayout.createSequentialGroup()
                                            .addComponent(EnunciadoLabel)
                                            .addGap(54, 54, 54))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CrearPreguntaLayout.createSequentialGroup()
                                            .addComponent(TemaLabel)
                                            .addGap(70, 70, 70))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, CrearPreguntaLayout.createSequentialGroup()
                                            .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(NivelLabel)
                                                .addComponent(TipoLabel))
                                            .addGap(70, 70, 70)))
                                    .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(NivelComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(TipoComboBox, javax.swing.GroupLayout.Alignment.LEADING, 0, 170, Short.MAX_VALUE))
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 401, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(CrearPreguntaLayout.createSequentialGroup()
                        .addGap(255, 255, 255)
                        .addComponent(BotonCrear)))
                .addGap(128, 128, 128))
        );
        CrearPreguntaLayout.setVerticalGroup(
            CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CrearPreguntaLayout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TemaLabel))
                .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(CrearPreguntaLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(EnunciadoLabel))
                    .addGroup(CrearPreguntaLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 27, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TipoLabel)
                    .addComponent(TipoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addGroup(CrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(NivelComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(NivelLabel))
                .addGap(30, 30, 30)
                .addComponent(RespuestaLabel)
                .addGap(18, 18, 18)
                .addComponent(PanelRespuestas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(BotonCrear)
                .addGap(67, 67, 67))
        );

        jScrollPane1.setViewportView(CrearPregunta);

        javax.swing.GroupLayout PanelCrearPreguntaLayout = new javax.swing.GroupLayout(PanelCrearPregunta);
        PanelCrearPregunta.setLayout(PanelCrearPreguntaLayout);
        PanelCrearPreguntaLayout.setHorizontalGroup(
            PanelCrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
        );
        PanelCrearPreguntaLayout.setVerticalGroup(
            PanelCrearPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelCrearPreguntaLayout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 452, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Crear", PanelCrearPregunta);

        PanelModPregunta.setBackground(new java.awt.Color(255, 255, 255));

        modificarPregunta.setBackground(new java.awt.Color(51, 204, 0));
        modificarPregunta.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        modificarPregunta.setForeground(new java.awt.Color(255, 255, 255));
        modificarPregunta.setText("Seleccionar");
        modificarPregunta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarPreguntaActionPerformed(evt);
            }
        });

        jScrollPane4.setBackground(new java.awt.Color(255, 255, 255));
        jScrollPane4.setFocusable(false);
        jScrollPane4.setOpaque(false);

        TablaModificar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Enunciado", "Tema", "Nivel", "Tipo de preg."
            }
        ));
        TablaModificar.setFocusable(false);
        TablaModificar.setRowHeight(25);
        TablaModificar.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaModificar.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaModificar.setShowVerticalLines(true);
        jScrollPane4.setViewportView(TablaModificar);

        javax.swing.GroupLayout PanelModPreguntaLayout = new javax.swing.GroupLayout(PanelModPregunta);
        PanelModPregunta.setLayout(PanelModPreguntaLayout);
        PanelModPreguntaLayout.setHorizontalGroup(
            PanelModPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
            .addGroup(PanelModPreguntaLayout.createSequentialGroup()
                .addGap(288, 288, 288)
                .addComponent(modificarPregunta)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelModPreguntaLayout.setVerticalGroup(
            PanelModPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, PanelModPreguntaLayout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(modificarPregunta)
                .addGap(18, 18, 18))
        );

        jTabbedPane1.addTab("Modificar", PanelModPregunta);

        PanelAnalisisPregunta.setBackground(new java.awt.Color(255, 255, 255));

        TablaMetricas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Enunciado", "Nivel", "Cantidad apariciones", "Cantidad aciertos", "Porcentaje aciertos"
            }
        ));
        TablaMetricas.setFocusable(false);
        TablaMetricas.setRowHeight(25);
        TablaMetricas.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaMetricas.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaMetricas.setShowVerticalLines(true);
        jScrollPane3.setViewportView(TablaMetricas);

        javax.swing.GroupLayout PanelAnalisisPreguntaLayout = new javax.swing.GroupLayout(PanelAnalisisPregunta);
        PanelAnalisisPregunta.setLayout(PanelAnalisisPreguntaLayout);
        PanelAnalisisPreguntaLayout.setHorizontalGroup(
            PanelAnalisisPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
        );
        PanelAnalisisPreguntaLayout.setVerticalGroup(
            PanelAnalisisPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 433, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("Analizar (metricas)", PanelAnalisisPregunta);

        PanelBorrarPregunta.setBackground(new java.awt.Color(255, 255, 255));

        BorrarPregunta.setBackground(new java.awt.Color(255, 102, 102));
        BorrarPregunta.setFont(new java.awt.Font("Dubai", 0, 14)); // NOI18N
        BorrarPregunta.setText("Eliminar");
        BorrarPregunta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrarPreguntaActionPerformed(evt);
            }
        });

        TablaPreguntas.setFont(new java.awt.Font("Dubai", 0, 12)); // NOI18N

        TablaBorrar.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Enunciado", "Tipo", "Nivel"
            }
        ));
        TablaBorrar.setFocusable(false);
        TablaBorrar.setRowHeight(25);
        TablaBorrar.setSelectionBackground(new java.awt.Color(232, 57, 95));
        TablaBorrar.setSelectionForeground(new java.awt.Color(255, 255, 255));
        TablaBorrar.setShowVerticalLines(true);
        TablaPreguntas.setViewportView(TablaBorrar);

        javax.swing.GroupLayout PanelBorrarPreguntaLayout = new javax.swing.GroupLayout(PanelBorrarPregunta);
        PanelBorrarPregunta.setLayout(PanelBorrarPreguntaLayout);
        PanelBorrarPreguntaLayout.setHorizontalGroup(
            PanelBorrarPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(TablaPreguntas, javax.swing.GroupLayout.DEFAULT_SIZE, 670, Short.MAX_VALUE)
            .addGroup(PanelBorrarPreguntaLayout.createSequentialGroup()
                .addGap(293, 293, 293)
                .addComponent(BorrarPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        PanelBorrarPreguntaLayout.setVerticalGroup(
            PanelBorrarPreguntaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(PanelBorrarPreguntaLayout.createSequentialGroup()
                .addComponent(TablaPreguntas, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(BorrarPregunta, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Borrar", PanelBorrarPregunta);

        add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 670, 470));

        BackGroundGreen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/greenBackSCALED.jpg"))); // NOI18N
        add(BackGroundGreen, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -10, 680, 60));
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void BotonCrearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonCrearActionPerformed
        // TODO add your handling code here:
        try {
            //recupero los datos desde la ventana
            String tema = (String) jComboBox1.getSelectedItem();
            String enunciado = EnunciadoBox.getText();
            String tipoStr = (String) TipoComboBox.getSelectedItem();
            String nivelStr = (String) NivelComboBox.getSelectedItem();
            TipoPregunta tipo = TipoPregunta.fromString(tipoStr);
            Nivel nivel = Nivel.fromString(nivelStr);

            Pregunta pregunta = new Pregunta();
            pregunta.setTema(tema);
            pregunta.setEnunciado(enunciado);
            pregunta.setTipo(tipo);
            pregunta.setNivel(nivel);

            PreguntaDAOImp preguntaDAO = new PreguntaDAOImp();
            // Diferenciar entre Insert y Update
            String modo = (String) BotonCrear.getClientProperty("modo");
            if ("update".equals(modo)) {
                //si es update traigo los datos de la pregunta. 
                int idPregunta = (int) BotonCrear.getClientProperty("idPregunta");
                pregunta.setId_Pregunta(idPregunta);
                boolean ok = preguntaDAO.actualizar(pregunta);
                if (!ok) {
                    JOptionPane.showMessageDialog(this, "Error al actualizar la pregunta");
                    return;
                }

                // Eliminar respuestas viejas y reinsertar (más simple)
                controlador.eliminarRespuestas(idPregunta);
                guardarRespuestas(pregunta.getId_Pregunta());

                JOptionPane.showMessageDialog(this, "Pregunta actualizada correctamente");
                BotonCrear.putClientProperty("modo", "insert");
                BotonCrear.setText("Crear pregunta");
            } else {
                boolean ok = preguntaDAO.insertar(pregunta, usuario.getCi());
                if (!ok) {
                    JOptionPane.showMessageDialog(this, "Error al insertar la pregunta");
                    return;
                }
                guardarRespuestas(pregunta.getId_Pregunta());
                JOptionPane.showMessageDialog(this, "Pregunta guardada correctamente");
            }

            // Resetear formulario
            EnunciadoBox.setText("");
            PanelRespuestas.removeAll();
            PanelRespuestas.revalidate();
            PanelRespuestas.repaint();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
        //actualizamos las tablas
        cargarPreguntasBorrar();
        cargarTablaModificar();
        cargarTablaMetricas();
    }//GEN-LAST:event_BotonCrearActionPerformed

    private void BorrarPreguntaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrarPreguntaActionPerformed
        // TODO add your handling code here:
        RespuestaDAOImp respDAO = new RespuestaDAOImp();
        PreguntaDAOImp dao = new PreguntaDAOImp();

        int fila = TablaBorrar.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una pregunta de la tabla.");
            return;
        }
        int idPregunta = Integer.parseInt(TablaBorrar.getValueAt(fila, 0).toString());
        int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar esta pregunta?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirmacion != JOptionPane.YES_OPTION) {
            return;
        }

        //borro pregunta y sus respuestas
        boolean eliminado = controlador.eliminarPreguntaYRespuestas(idPregunta);

        if (eliminado) {
            JOptionPane.showMessageDialog(this, "Pregunta eliminada correctamente.");
            cargarPreguntasBorrar(); // Refrescar la tabla
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar la pregunta.");
        }

        //actualizamos las tablas
        cargarPreguntasBorrar();
        cargarTablaModificar();
        cargarTablaMetricas();
    }//GEN-LAST:event_BorrarPreguntaActionPerformed

    private void modificarPreguntaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarPreguntaActionPerformed
        // TODO add your handling code here:
        //check de que marque una fila
        int fila = TablaModificar.getSelectedRow();
        if (fila == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una pregunta de la tabla.");
            return;
        }

        // Obtener el ID  de la pregunta seleccionada
        int idPregunta = Integer.parseInt(TablaModificar.getValueAt(fila, 0).toString());

        // Buscar la pregunta en BD
        Pregunta p = controlador.recuperarPreguntaPorId(idPregunta);
        if (p == null) {
            JOptionPane.showMessageDialog(this, "No se pudo cargar la pregunta.");
            return;
        }

        // Cargar los datos en el formulario
        jComboBox1.setSelectedItem(p.getTema());
        EnunciadoBox.setText(p.getEnunciado());
        TipoComboBox.setSelectedItem(
                p.getTipo() == TipoPregunta.MULTIPLE_OPCION ? "Multiple opcion" : "Verdadero o falso"
        );
        NivelComboBox.setSelectedItem(
                p.getNivel().toString().charAt(0) + p.getNivel().toString().substring(1).toLowerCase()
        );

        // Inicializar respuestas
        inicializarRespuestas(p.getOpcionesRespuesta().size());
        Component[] comps = PanelRespuestas.getComponents();
        List<Respuesta> respuestas = p.getOpcionesRespuesta();
        for (int i = 0; i < respuestas.size(); i++) {
            JTextField campo = (JTextField) comps[i * 2];
            JRadioButton radio = (JRadioButton) comps[i * 2 + 1];

            campo.setText(respuestas.get(i).getTexto());
            radio.setSelected(respuestas.get(i).esCorrecta());
        }

        // Cambiar pestaña a "Crear"
        jTabbedPane1.setSelectedComponent(PanelCrearPregunta);

        // Guardar el id en el botón para saber si es update o insert
        BotonCrear.putClientProperty("modo", "update");
        BotonCrear.putClientProperty("idPregunta", idPregunta);
        BotonCrear.setText("Actualizar pregunta");

        //actualizamos las tablas
        cargarPreguntasBorrar();
        cargarTablaModificar();
        cargarTablaMetricas();

    }//GEN-LAST:event_modificarPreguntaActionPerformed

    private void TipoComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_TipoComboBoxItemStateChanged
        // TODO add your handling code here:
        String seleccionado = (String) TipoComboBox.getSelectedItem();
        if ("Verdadero o falso".equals(seleccionado)) {
            inicializarRespuestas(2);   // solo 2 respuestas
        } else if ("Multiple opcion".equals(seleccionado)) {
            inicializarRespuestas(4);   // 4 respuestas
        }
    }//GEN-LAST:event_TipoComboBoxItemStateChanged

    private void configurarTablaBorrar() {
        modeloTablaBorrar = new DefaultTableModel(
                new Object[]{"ID", "Enunciado", "Tema", "Nivel"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        TablaBorrar.setModel(modeloTablaBorrar);
        // Ocultar la primera columna (la ID)
        TablaBorrar.getColumnModel().getColumn(0).setMinWidth(0);
        TablaBorrar.getColumnModel().getColumn(0).setMaxWidth(0);
        TablaBorrar.getColumnModel().getColumn(0).setWidth(0);

        TablaBorrar.setAutoCreateRowSorter(true);
    }

    private void cargarPreguntasBorrar() {
        modeloTablaBorrar.setRowCount(0);
        java.util.List<Pregunta> preguntas = controlador.recuperarTodasPreguntas();

        for (Pregunta p : preguntas) {
            modeloTablaBorrar.addRow(new Object[]{
                p.getId_Pregunta(),
                p.getEnunciado(),
                p.getTema(),
                p.getNivel()
            });
        }
    }

    private void configurarTablaMetricas() {
        modeloTablaMetricas = new DefaultTableModel(
                new Object[]{"ID", "Enunciado", "Nivel", "Cantidad apariciones", "Cantidad aciertos", "Porcentaje aciertos"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        TablaMetricas.setModel(modeloTablaMetricas);
        // Ocultar la primera columna (la ID)
        TablaMetricas.getColumnModel().getColumn(0).setMinWidth(0);
        TablaMetricas.getColumnModel().getColumn(0).setMaxWidth(0);
        TablaMetricas.getColumnModel().getColumn(0).setWidth(0);

        TablaMetricas.setAutoCreateRowSorter(true);
    }

    private void cargarTablaMetricas() {
        modeloTablaMetricas.setRowCount(0);
        java.util.List<Pregunta> preguntas = controlador.recuperarTodasPreguntas();

        for (Pregunta p : preguntas) {
            modeloTablaMetricas.addRow(new Object[]{
                p.getId_Pregunta(),
                p.getEnunciado(),
                p.getNivel(),
                p.getCantApariciones(),
                p.getCantRespuestasCorrectas(),
                p.getPorcentajeAciertos()
            });
        }
    }

    private void configurarTablaModificar() {
        modeloTablaModificar = new DefaultTableModel(
                new Object[]{"ID", "Enunciado", "Tema", "Nivel", "Tipo de preg."}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        TablaModificar.setModel(modeloTablaModificar);
        // Ocultar la primera columna (la ID)
        TablaModificar.getColumnModel().getColumn(0).setMinWidth(0);
        TablaModificar.getColumnModel().getColumn(0).setMaxWidth(0);
        TablaModificar.getColumnModel().getColumn(0).setWidth(0);
        TablaModificar.setAutoCreateRowSorter(true);

    }

    private void cargarTablaModificar() {
        modeloTablaModificar.setRowCount(0);
        java.util.List<Pregunta> preguntas = controlador.recuperarTodasPreguntas();
        for (Pregunta p : preguntas) {
            modeloTablaModificar.addRow(new Object[]{
                p.getId_Pregunta(),
                p.getEnunciado(),
                p.getTema(),
                p.getNivel(),
                p.getTipo()
            });
        }

    }

    private void cargarTemasEnCombo() {
        List<String> temas = controlador.recuperarTemas();
        jComboBox1.removeAllItems(); // limpia el combo

        if (temas.isEmpty()) {
            jComboBox1.addItem("No hay temas");
        } else {
            for (String t : temas) { //para cada tema de la lista lo agrego a la comboBOX
                jComboBox1.addItem(t);
            }
        }

        // Opción especial para agregar nuevos temas
        jComboBox1.addItem("<<Agregar nuevo tema>>");
        // Listener para detectar si el usuario quiere crear uno nuevo
        jComboBox1.addActionListener(e -> {
            if ("<<Agregar nuevo tema>>".equals(jComboBox1.getSelectedItem())) {
                String nuevoTema = JOptionPane.showInputDialog(this, "Ingrese el nuevo tema:");
                if (nuevoTema != null && !nuevoTema.trim().isEmpty()) {//garantizamos que haya un tema
                    jComboBox1.insertItemAt(nuevoTema, 0);
                    jComboBox1.setSelectedItem(nuevoTema);
                } else {
                    jComboBox1.setSelectedIndex(0); // vuelve al primero
                }
            }
        }
        );
    }

    //metodo para cargar los tipos de pregunta en el Combobox
    private void cargarTipo() {
        TipoComboBox.removeAllItems();
        String tipo1 = "Multiple opcion";
        String tipo2 = "Verdadero o falso";

        TipoComboBox.addItem(tipo1);
        TipoComboBox.addItem(tipo2);
    }
    //metodo para cargar los niveles de pregunta en el Combobox

    private void cargarNivel() {
        NivelComboBox.removeAllItems();
        String nivel0 = "Facil";
        String nivel1 = "Medio";
        String nivel2 = "Dificil";
        NivelComboBox.addItem(nivel0);
        NivelComboBox.addItem(nivel1);
        NivelComboBox.addItem(nivel2);
    }

    private void inicializarRespuestas(int cantidad) {
        PanelRespuestas.removeAll(); // limpiar por si ya tenía algo
        grupoRespuestas = new ButtonGroup(); // nuevo grupo de botones

        for (int i = 0; i < cantidad; i++) {
            JTextField campo = new JTextField();

            campo.setFont(new java.awt.Font("Dubai", 0, 14));
            campo.setColumns(20);

            JRadioButton opcionCorrecta = new JRadioButton("Correcta");
            opcionCorrecta.setBackground(Color.white);

            if (cantidad == 2) {
                campo.setEnabled(false);
                if (i == 0) {
                    campo.setText("Verdadero");
                } else {
                    campo.setText("Falso");
                }
            }

            grupoRespuestas.add(opcionCorrecta);
            PanelRespuestas.add(campo);
            PanelRespuestas.add(opcionCorrecta);
        }

        PanelRespuestas.revalidate();
        PanelRespuestas.repaint();
    }

    private void guardarRespuestas(int idPregunta) {
        Component[] comps = PanelRespuestas.getComponents();
        List<Respuesta> respuestas = new ArrayList<>();
        boolean tieneCorrecta = false;

        for (int i = 0; i < comps.length; i += 2) {
            JTextField campo = (JTextField) comps[i];
            JRadioButton radio = (JRadioButton) comps[i + 1];

            String texto = campo.getText().trim();
            if (texto.isEmpty()) {
                continue; // no guardar respuestas vacías
            }
            Respuesta r = new Respuesta();
            r.setTexto(texto);
            r.setEsCorrecta(radio.isSelected());
            r.setIdPregunta(idPregunta);

            if (radio.isSelected()) {
                tieneCorrecta = true;
            }

            respuestas.add(r);
        }

        if (!tieneCorrecta) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar al menos una respuesta correcta.");
            return;
        }
        //guardamos las preguntas en la base de datos
        controlador.guardarListaRespuestas(respuestas);

    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel BackGroundGreen;
    private javax.swing.JButton BorrarPregunta;
    private javax.swing.JButton BotonCrear;
    private javax.swing.JPanel CrearPregunta;
    private javax.swing.JTextArea EnunciadoBox;
    private javax.swing.JLabel EnunciadoLabel;
    private javax.swing.JLabel LabelPrincipal;
    private javax.swing.JComboBox<String> NivelComboBox;
    private javax.swing.JLabel NivelLabel;
    private javax.swing.JPanel PanelAnalisisPregunta;
    private javax.swing.JPanel PanelBorrarPregunta;
    private javax.swing.JPanel PanelCrearPregunta;
    private javax.swing.JPanel PanelModPregunta;
    private javax.swing.JPanel PanelRespuestas;
    private javax.swing.JLabel RespuestaLabel;
    private javax.swing.JTable TablaBorrar;
    private javax.swing.JTable TablaMetricas;
    private javax.swing.JTable TablaModificar;
    private javax.swing.JScrollPane TablaPreguntas;
    private javax.swing.JLabel TemaLabel;
    private javax.swing.JComboBox<String> TipoComboBox;
    private javax.swing.JLabel TipoLabel;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JButton modificarPregunta;
    // End of variables declaration//GEN-END:variables
}
